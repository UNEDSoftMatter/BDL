/*
 * Class : Brownian_disks_lab_v1_1.java
 *  Generated using  *  Easy Java/Javascript Simulations Version 5.3, build 180211. Visit http://www.um.es/fem/Ejs
 */ 

package Brownian_Disks_Lab.Brownian_disks_lab_v1_1_pkg;

import org.colos.ejs.library._EjsConstants;

import java.util.*;
import java.text.*;
import java.lang.StringBuffer;
import java.math.*;
import java.nio.charset.StandardCharsets;
import java.nio.file.*;
import java.io.*;
// Imports suggested by Model Elements:
// End of imports from Model Elements

import javax.swing.event.*;
import javax.swing.*;
import java.awt.event.*;
import java.awt.*;
import java.net.*;
import java.util.*;
import java.io.*;
import java.lang.*;

import javax.json.*;

public class Brownian_disks_lab_v1_1 extends org.colos.ejs.library.Model {

  static {
    org.opensourcephysics.tools.ToolForData.setTool(new org.opensourcephysics.tools.ToolForDataFull());
    __translatorUtil = new org.colos.ejs.library.utils.TranslatorResourceUtil("Brownian_Disks_Lab.Brownian_disks_lab_v1_1_pkg.Brownian_disks_lab_v1_1");
  }

  static public boolean _sSwingView = true;

  static public int _sServerPort = -1;
  static public int _getServerPort() { return _sServerPort; }

  public Brownian_disks_lab_v1_1Simulation _simulation=null;
  public Brownian_disks_lab_v1_1View _view=null;
  public Brownian_disks_lab_v1_1 _model=this;

  // -------------------------- 
  // Information on HTML pages
  // -------------------------- 

  static private java.util.Map<String,java.util.Set<org.colos.ejs.library.utils.HtmlPageInfo>> __htmlPagesMap =
    new java.util.HashMap<String,java.util.Set<org.colos.ejs.library.utils.HtmlPageInfo>>();

  /**
   * Adds info about an html on the model
   */
  static public void _addHtmlPageInfo(String _pageName, String _localeStr, String _title, String _link) {
    java.util.Set<org.colos.ejs.library.utils.HtmlPageInfo> pages = __htmlPagesMap.get(_pageName);
    if (pages==null) {
      pages = new java.util.HashSet<org.colos.ejs.library.utils.HtmlPageInfo>();
      __htmlPagesMap.put(_pageName, pages);
    }
    org.colos.ejs.library.utils.LocaleItem item = org.colos.ejs.library.utils.LocaleItem.getLocaleItem(_localeStr);
    if (item!=null) pages.add(new org.colos.ejs.library.utils.HtmlPageInfo(item, _title, _link));
  }

  /**
   * Returns info about an html on the model
   */
  static public org.colos.ejs.library.utils.HtmlPageInfo _getHtmlPageClassInfo(String _pageName, org.colos.ejs.library.utils.LocaleItem _item) {
    java.util.Set<org.colos.ejs.library.utils.HtmlPageInfo> pages = __htmlPagesMap.get(_pageName);
    if (pages==null) return null;
    org.colos.ejs.library.utils.HtmlPageInfo defaultInfo=null;
    for (org.colos.ejs.library.utils.HtmlPageInfo info : pages) {
      if (info.getLocaleItem().isDefaultItem()) defaultInfo = info;
      if (info.getLocaleItem().equals(_item)) return info;
    }
    return defaultInfo;
  }

  public org.colos.ejs.library.utils.HtmlPageInfo _getHtmlPageInfo(String _pageName, org.colos.ejs.library.utils.LocaleItem _item) { return _getHtmlPageClassInfo(_pageName,_item); }

  // -------------------------- 
  // static methods 
  // -------------------------- 

  static public String _getEjsModel() { return "/Brownian_Disks_Lab/Brownian_disks_lab_v1.1.ejs"; }

  static public String _getModelDirectory() { return "Brownian_Disks_Lab/"; }

  static public java.awt.Dimension _getEjsAppletDimension() {
    return new java.awt.Dimension(970,750);
  }

  static public java.util.Set<String> _getEjsResources() {
    java.util.Set<String> list = new java.util.HashSet<String>();
    list.add("/Brownian_Disks_Lab/saveSmall.gif");
    return list;
  };

  static public boolean _common_initialization(String[] _args) {
    String lookAndFeel = null;
    boolean decorated = true;
    if (_args!=null) for (int i=0; i<_args.length; i++) {
      if      (_args[i].equals("-_lookAndFeel"))          lookAndFeel = _args[++i];
      else if (_args[i].equals("-_decorateWindows"))      decorated = true;
      else if (_args[i].equals("-_doNotDecorateWindows")) decorated = false;
      else if (_args[i].equals("-_noSwingView")) _sSwingView = false;
      else if (_args[i].equals("-_serverPort")) try { _sServerPort = Integer.parseInt(_args[++i]); } catch (Exception exc) { _sServerPort = -1; exc.printStackTrace(); } 
    }
    if (lookAndFeel!=null) org.opensourcephysics.display.OSPRuntime.setLookAndFeel(decorated,lookAndFeel);
    org.opensourcephysics.tools.ResourceLoader.addSearchPath("Brownian_Disks_Lab/"); // This is for relative resources
    boolean pathsSet = false, underEjs = false;
    try { // in case of security problems
      if ("true".equals(System.getProperty("org.osp.launcher"))) { // Running under Launcher
        org.opensourcephysics.display.OSPRuntime.setLauncherMode(true);
      }
    }
    catch (Exception _exception) { } // do not complain
    try { // in case of security problems
      if (System.getProperty("osp_ejs")!=null) { // Running under EJS
        underEjs = true;
        org.colos.ejs.library.Simulation.setPathToLibrary("/media/pablo/27DFA02224814BDA/INVESTIGACION/EjsS/EjsS_5.3/bin/config/"); // This is for classes (such as EjsMatlab) which needs to know where the library is
        pathsSet = true;
      }
    }
    catch (Exception _exception) { pathsSet = false; } // maybe an unsigned Web start?
    try { org.colos.ejs.library.control.EjsControl.setDefaultScreen(Integer.parseInt(System.getProperty("screen"))); } // set default screen 
    catch (Exception _exception) { } // Ignore any error here
    if (!pathsSet) {
      org.colos.ejs.library.Simulation.setPathToLibrary("/media/pablo/27DFA02224814BDA/INVESTIGACION/EjsS/EjsS_5.3/bin/config/"); // This is for classes (such as EjsMatlab) which needs to know where the library is
    }
    if (!underEjs) {
    }
    return true; // Everything went ok
  }

  static public void main (String[] _args) {
    if (!_common_initialization(_args)) {
      if (org.opensourcephysics.display.OSPRuntime.isLauncherMode()) return;
      System.exit(-1);
    }

    Brownian_disks_lab_v1_1 __theModel = new Brownian_disks_lab_v1_1 (_args);
  }

  static public javax.swing.JComponent getModelPane(String[] _args, javax.swing.JFrame _parentFrame) {
    if (!_common_initialization(_args)) return null;
    Brownian_disks_lab_v1_1 __theModel = new Brownian_disks_lab_v1_1 ("drawingFrame2",_parentFrame,null,null,_args,true);
    return (javax.swing.JComponent) __theModel._getView().getComponent("drawingFrame2");
  }

  public Brownian_disks_lab_v1_1 () { this (null, null, null,null,null,false); } // slave application

  public Brownian_disks_lab_v1_1 (String[] _args) { this (null, null, null,null,_args,true); }

  public Brownian_disks_lab_v1_1 (String _replaceName, java.awt.Frame _replaceOwnerFrame, java.net.URL _codebase, org.colos.ejs.library.LauncherApplet _anApplet, String[] _args, boolean _allowAutoplay) {
    org.colos.ejs.library.control.swing.ControlWindow.setKeepHidden(true);
    __theArguments = _args;
    __theApplet = _anApplet;
    java.text.NumberFormat _Ejs_format = java.text.NumberFormat.getInstance();
    if (_Ejs_format instanceof java.text.DecimalFormat) {
      ((java.text.DecimalFormat) _Ejs_format).getDecimalFormatSymbols().setDecimalSeparator('.');
    }
    _simulation = new Brownian_disks_lab_v1_1Simulation (this,_replaceName,_replaceOwnerFrame,_codebase,_allowAutoplay);
    _simulation.processArguments(_args);
    if (_sSwingView)       org.colos.ejs.library.control.swing.ControlWindow.setKeepHidden(false);
  }

 // -------------------------------------------
 // Abstract part of Model 
 // -------------------------------------------

  public String _getClassEjsModel() { return _getEjsModel(); }

  public java.util.Set<String> _getClassEjsResources() { return _getEjsResources(); }

  public String _getClassModelDirectory() { return _getModelDirectory(); }

  public org.colos.ejs.library.View _getView() { return _view; }

  public org.colos.ejs.library.Simulation _getSimulation() { return _simulation; }

  public int _getPreferredStepsPerDisplay() { return 1; }

  public void _resetModel () {
    _isEnabled_initialization1 = true; // Reset enabled condition for Model.Initialization.Init
    _isEnabled_evolution1 = true; // Reset enabled condition for Model.Evolution.Movimiento
    _isEnabled_constraints1 = true; // Reset enabled condition for Model.Constraints.Inside
    _isEnabled_constraints2 = true; // Reset enabled condition for Model.Constraints.Cyclic
    _isEnabled_constraints3 = true; // Reset enabled condition for Model.Constraints.Gaussian
    _isEnabled_constraints4 = true; // Reset enabled condition for Model.Constraints.Optical Potential
    _isEnabled_constraints5 = true; // Reset enabled condition for Model.Constraints.Stop
    _isEnabled_constraints6 = true; // Reset enabled condition for Model.Constraints.Save data
    _isEnabled_constraints7 = true; // Reset enabled condition for Model.Constraints.Save data 2
    n = 10; // Variables.Particles:1    n = 10; // Variables.Particles:1
    narray = 5000; // Variables.Particles:2    narray = 5000; // Variables.Particles:2
    diameter_c = 0.1; // Variables.Particles:3    diameter_c = 0.1; // Variables.Particles:3
    d_real = 1.88; // Variables.Particles:4    d_real = 1.88; // Variables.Particles:4
    diameter = new double [n]; // Variables.Particles:5
    for (int _i0=0; _i0<n; _i0++) diameter[_i0] = diameter_c; // Variables.Particles:5
    vx_0 = 0; // Variables.Particles:6    vx_0 = 0; // Variables.Particles:6
    vy_0 = 0; // Variables.Particles:7    vy_0 = 0; // Variables.Particles:7
    x = new double [n]; // Variables.Particles:8
    for (int _i0=0; _i0<n; _i0++) x[_i0] = 0; // Variables.Particles:8
    x_0 = new double [n]; // Variables.Particles:9
    for (int _i0=0; _i0<n; _i0++) x_0[_i0] = 0; // Variables.Particles:9
    x_prev = new double [n]; // Variables.Particles:10
    for (int _i0=0; _i0<n; _i0++) x_prev[_i0] = 0.0; // Variables.Particles:10
    vx = new double [n]; // Variables.Particles:11
    for (int _i0=0; _i0<n; _i0++) vx[_i0] = vx_0; // Variables.Particles:11
    y_0 = new double [n]; // Variables.Particles:12
    for (int _i0=0; _i0<n; _i0++) y_0[_i0] = 0; // Variables.Particles:12
    y_prev = new double [n]; // Variables.Particles:13
    for (int _i0=0; _i0<n; _i0++) y_prev[_i0] = 0.0; // Variables.Particles:13
    y = new double [n]; // Variables.Particles:14
    for (int _i0=0; _i0<n; _i0++) y[_i0] = 0; // Variables.Particles:14
    vy = new double [n]; // Variables.Particles:15
    for (int _i0=0; _i0<n; _i0++) vy[_i0] = vy_0; // Variables.Particles:15
    microns = 1e-6; // Variables.Particles:16    microns = 1e-6; // Variables.Particles:16
    a = diameter_c/2.0; // Variables.Particles:17    a = diameter_c/2.0; // Variables.Particles:17
    a_real = d_real/2.0; // Variables.Particles:18    a_real = d_real/2.0; // Variables.Particles:18
    f_p = a_real/a; // Variables.Particles:19    f_p = a_real/a; // Variables.Particles:19
    if_p = 1/f_p; // Variables.Particles:20    if_p = 1/f_p; // Variables.Particles:20
    eta0 = 0.0013; // Variables.Particles:21    eta0 = 0.0013; // Variables.Particles:21
    eta = eta0*(f_p*microns); // Variables.Particles:22    eta = eta0*(f_p*microns); // Variables.Particles:22
    T = 294.0; // Variables.Particles:23    T = 294.0; // Variables.Particles:23
    K_B = (1.38e-23)/(f_p*f_p*microns*microns); // Variables.Particles:24    K_B = (1.38e-23)/(f_p*f_p*microns*microns); // Variables.Particles:24
    D = K_B*T/(6*3.1416*eta*a); // Variables.Particles:25    D = K_B*T/(6*3.1416*eta*a); // Variables.Particles:25
    chi = 6*3.141592*eta*a; // Variables.Particles:26    chi = 6*3.141592*eta*a; // Variables.Particles:26
    bUseWater = true; // Variables.Particles:27    bUseWater = true; // Variables.Particles:27
    arraylist_Strings = null; // Variables.Particles:28    arraylist_Strings = null; // Variables.Particles:28
    arraylist_StringsStats = null; // Variables.Particles:29    arraylist_StringsStats = null; // Variables.Particles:29
    count_images = 0; // Variables.Particles:30    count_images = 0; // Variables.Particles:30
    count_images_total = 1; // Variables.Particles:31    count_images_total = 1; // Variables.Particles:31
    count_images_dt = 0; // Variables.Particles:32    count_images_dt = 0; // Variables.Particles:32
    count_images_dt_total = 1; // Variables.Particles:33    count_images_dt_total = 1; // Variables.Particles:33
    checker_t = 0; // Variables.Particles:34    checker_t = 0; // Variables.Particles:34
    xmin = -1; // Variables.Common:1    xmin = -1; // Variables.Common:1
    xmax = 1; // Variables.Common:2    xmax = 1; // Variables.Common:2
    ymin = -1; // Variables.Common:3    ymin = -1; // Variables.Common:3
    ymax = 1; // Variables.Common:4    ymax = 1; // Variables.Common:4
    t = 0; // Variables.Common:5    t = 0; // Variables.Common:5
    dt = 0.0010; // Variables.Common:6    dt = 0.0010; // Variables.Common:6
    tmax = 10.00; // Variables.Common:7    tmax = 10.00; // Variables.Common:7
    textra = 0; // Variables.Common:8    textra = 0; // Variables.Common:8
    numberOfSteps = n*tmax/dt; // Variables.Common:9    numberOfSteps = n*tmax/dt; // Variables.Common:9
    limitOfSteps = 5e5; // Variables.Common:10    limitOfSteps = 5e5; // Variables.Common:10
    dMaxTime = 1e4; // Variables.Common:11    dMaxTime = 1e4; // Variables.Common:11
    dTimeMaxImposed = 0.0; // Variables.Common:12    dTimeMaxImposed = 0.0; // Variables.Common:12
    dtInTxt = 0.1; // Variables.Common:13    dtInTxt = 0.1; // Variables.Common:13
    bDtInTxt = false; // Variables.Common:14    bDtInTxt = false; // Variables.Common:14
    bSaveDataAuto = false; // Variables.Common:15    bSaveDataAuto = false; // Variables.Common:15
    iNumLogSave = 1; // Variables.Common:16    iNumLogSave = 1; // Variables.Common:16
    ep = 1.0; // Variables.Common:17    ep = 1.0; // Variables.Common:17
    ed = 0.1; // Variables.Common:18    ed = 0.1; // Variables.Common:18
    sFileName = "FILENAME"; // Variables.Common:19    sFileName = "FILENAME"; // Variables.Common:19
    sDirectoryName = System.getProperty("user.dir")+File.separator;; // Variables.Common:20    sDirectoryName = System.getProperty("user.dir")+File.separator;; // Variables.Common:20
    sInputFileName = "input_"+this.sFileName+".txt";; // Variables.Common:21    sInputFileName = "input_"+this.sFileName+".txt";; // Variables.Common:21
    sReadInputFilePath = this.sDirectoryName+this.sInputFileName;; // Variables.Common:22    sReadInputFilePath = this.sDirectoryName+this.sInputFileName;; // Variables.Common:22
    sReadFilePath = this.sDirectoryName+this.sFileName+".txt";; // Variables.Common:23    sReadFilePath = this.sDirectoryName+this.sFileName+".txt";; // Variables.Common:23
    bexclusion1k = false; // Variables.Common:24    bexclusion1k = false; // Variables.Common:24
    Dreal = D*f_p*f_p; // Variables.Common:25    Dreal = D*f_p*f_p; // Variables.Common:25
    phi_2D = 3.141592*a*a*n/((xmax-xmin)*(ymax-ymin));; // Variables.Common:26    phi_2D = 3.141592*a*a*n/((xmax-xmin)*(ymax-ymin));; // Variables.Common:26
    bIncludeLabelDisk = true; // Variables.Common:27    bIncludeLabelDisk = true; // Variables.Common:27
    TOLERANCE = Double.MIN_VALUE;; // Variables.Events:1    TOLERANCE = Double.MIN_VALUE;; // Variables.Events:1
    bUseCyclicContour = false; // Variables.Events:2    bUseCyclicContour = false; // Variables.Events:2
    bUseWallForces = true; // Variables.Events:3    bUseWallForces = true; // Variables.Events:3
    bUseNoContour = true; // Variables.Events:4    bUseNoContour = true; // Variables.Events:4
    nInside = 0; // Variables.Events:5    nInside = 0; // Variables.Events:5
    tSave = 0; // Variables.Events:6    tSave = 0; // Variables.Events:6
    bSeparateDisks = false; // Variables.Events:7    bSeparateDisks = false; // Variables.Events:7
    bUseDiskForce = true; // Variables.Events:8    bUseDiskForce = true; // Variables.Events:8
    bUseOpticalForce = true; // Variables.Events:9    bUseOpticalForce = true; // Variables.Events:9
    diam_reduction = 0.5; // Variables.Events:10    diam_reduction = 0.5; // Variables.Events:10
    bFreeMode = false; // Variables.Events:11    bFreeMode = false; // Variables.Events:11
    bReadData = false; // Variables.Events:12    bReadData = false; // Variables.Events:12
    binHistoJumps = 200; // Variables.Statistics:1    binHistoJumps = 200; // Variables.Statistics:1
    freqHistoJumps = new double [binHistoJumps]; // Variables.Statistics:2
    for (int _i0=0; _i0<binHistoJumps; _i0++) freqHistoJumps[_i0] = 0.0; // Variables.Statistics:2
    dFreqesp = 0.0; // Variables.Statistics:3    dFreqesp = 0.0; // Variables.Statistics:3
    dFreqespOptPot = 0.0; // Variables.Statistics:4    dFreqespOptPot = 0.0; // Variables.Statistics:4
    countHistoJumpsX = new double [binHistoJumps]; // Variables.Statistics:5
    for (int _i0=0; _i0<binHistoJumps; _i0++) countHistoJumpsX[_i0] = 0.0; // Variables.Statistics:5
    countHistoJumpsY = new double [binHistoJumps]; // Variables.Statistics:6
    for (int _i0=0; _i0<binHistoJumps; _i0++) countHistoJumpsY[_i0] = 0.0; // Variables.Statistics:6
    bDoHistoJumps = true; // Variables.Statistics:7    bDoHistoJumps = true; // Variables.Statistics:7
    DHistoJumpsX = 0.0; // Variables.Statistics:8    DHistoJumpsX = 0.0; // Variables.Statistics:8
    DHistoJumpsY = 0.0; // Variables.Statistics:9    DHistoJumpsY = 0.0; // Variables.Statistics:9
    freqHistoOptPot = new double [binHistoJumps]; // Variables.Statistics:10
    for (int _i0=0; _i0<binHistoJumps; _i0++) freqHistoOptPot[_i0] = 0.0; // Variables.Statistics:10
    countHistoOptPotX = new double [binHistoJumps]; // Variables.Statistics:11
    for (int _i0=0; _i0<binHistoJumps; _i0++) countHistoOptPotX[_i0] = 0.0; // Variables.Statistics:11
    countHistoOptPotY = new double [binHistoJumps]; // Variables.Statistics:12
    for (int _i0=0; _i0<binHistoJumps; _i0++) countHistoOptPotY[_i0] = 0.0; // Variables.Statistics:12
    bDoHistoOptPot = true; // Variables.Statistics:13    bDoHistoOptPot = true; // Variables.Statistics:13
    kHistoOptPotX = 0.0; // Variables.Statistics:14    kHistoOptPotX = 0.0; // Variables.Statistics:14
    kHistoOptPotY = 0.0; // Variables.Statistics:15    kHistoOptPotY = 0.0; // Variables.Statistics:15
    particleXYexample = 0; // Variables.Statistics:16    particleXYexample = 0; // Variables.Statistics:16
    particleXYexample2 = 0; // Variables.Statistics:17    particleXYexample2 = 0; // Variables.Statistics:17
    cte_f_exclusion = 0; // Variables.Potentials:1    cte_f_exclusion = 0; // Variables.Potentials:1
    cte_diffusion = 0; // Variables.Potentials:2    cte_diffusion = 0; // Variables.Potentials:2
    bAOmodel = false; // Variables.Potentials:3    bAOmodel = false; // Variables.Potentials:3
    Rg = 500.0; // Variables.Potentials:4    Rg = 500.0; // Variables.Potentials:4
    cteAOennp = 0.5; // Variables.Potentials:5    cteAOennp = 0.5; // Variables.Potentials:5
    A0 = 0.5/(n); // Variables.Potentials:6    A0 = 0.5/(n); // Variables.Potentials:6
    A = A0; // Variables.Potentials:7    A = A0; // Variables.Potentials:7
    B = 10; // Variables.Potentials:8    B = 10; // Variables.Potentials:8
    bUseExclusionForce = true; // Variables.Potentials:9    bUseExclusionForce = true; // Variables.Potentials:9
    bUseHSn12 = false; // Variables.Potentials:10    bUseHSn12 = false; // Variables.Potentials:10
    bUseHSn36 = false; // Variables.Potentials:11    bUseHSn36 = false; // Variables.Potentials:11
    bUseHSHeyes = true; // Variables.Potentials:12    bUseHSHeyes = true; // Variables.Potentials:12
    cteAHSn12 = 10; // Variables.Potentials:13    cteAHSn12 = 10; // Variables.Potentials:13
    cteAHSn36 = 1; // Variables.Potentials:14    cteAHSn36 = 1; // Variables.Potentials:14
    ctekHSHeyes = 150; // Variables.Potentials:15    ctekHSHeyes = 150; // Variables.Potentials:15
    bUseElecAtracPot = false; // Variables.Potentials:16    bUseElecAtracPot = false; // Variables.Potentials:16
    Zelec = 800; // Variables.Potentials:17    Zelec = 800; // Variables.Potentials:17
    lambdaelec = 0.717; // Variables.Potentials:18    lambdaelec = 0.717; // Variables.Potentials:18
    kappainvelec = 0.150; // Variables.Potentials:19    kappainvelec = 0.150; // Variables.Potentials:19
    qelec = 13; // Variables.Potentials:20    qelec = 13; // Variables.Potentials:20
    k_optics_y = 0.5; // Variables.Potentials:21    k_optics_y = 0.5; // Variables.Potentials:21
    k_optics_x = 0.5; // Variables.Potentials:22    k_optics_x = 0.5; // Variables.Potentials:22
    cabeceraEstadisticas = "X"+"\t"+"Y"+"\t"+"time"+"\t"+"image"; // Variables.Labels:1    cabeceraEstadisticas = "X"+"\t"+"Y"+"\t"+"time"+"\t"+"image"; // Variables.Labels:1
    sLabel = "label"; // Variables.Labels:2    sLabel = "label"; // Variables.Labels:2
    MSG_OPEN_FILE = "Opening file for saving data."; // Variables.Labels:3    MSG_OPEN_FILE = "Opening file for saving data."; // Variables.Labels:3
    MSG_CLOSE_FILE = "Closing text file."; // Variables.Labels:4    MSG_CLOSE_FILE = "Closing text file."; // Variables.Labels:4
    MSG_WRITE_FILE = "Writing data into text file."; // Variables.Labels:5    MSG_WRITE_FILE = "Writing data into text file."; // Variables.Labels:5
    MSG_WRITE_FILE_ERROR = "No data to write into text file."; // Variables.Labels:6    MSG_WRITE_FILE_ERROR = "No data to write into text file."; // Variables.Labels:6
    MSG_SAVING_ARRAY = "Saving remaining data from array."; // Variables.Labels:7    MSG_SAVING_ARRAY = "Saving remaining data from array."; // Variables.Labels:7
    MSG_CLEARING_ARRAY = "Clearing array."; // Variables.Labels:8    MSG_CLEARING_ARRAY = "Clearing array."; // Variables.Labels:8
    TEXT_INPUT_FILE = "File: "; // Variables.Labels:9    TEXT_INPUT_FILE = "File: "; // Variables.Labels:9
    TEXT_INPUT_TIMETOTAL = "Total time (s): "; // Variables.Labels:10    TEXT_INPUT_TIMETOTAL = "Total time (s): "; // Variables.Labels:10
    TEXT_INPUT_DT = "dt (s): "; // Variables.Labels:11    TEXT_INPUT_DT = "dt (s): "; // Variables.Labels:11
    TEXT_INPUT_SEP = "********************"; // Variables.Labels:12    TEXT_INPUT_SEP = "********************"; // Variables.Labels:12
    TEXT_INPUT_N = "Number of particles: "; // Variables.Labels:13    TEXT_INPUT_N = "Number of particles: "; // Variables.Labels:13
    TEXT_INPUT_RDIAM = "Real diameter (microns): "; // Variables.Labels:14    TEXT_INPUT_RDIAM = "Real diameter (microns): "; // Variables.Labels:14
    TEXT_INPUT_DIAM = "Diameter in simulation: "; // Variables.Labels:15    TEXT_INPUT_DIAM = "Diameter in simulation: "; // Variables.Labels:15
    TEXT_INPUT_CAL = "Calibration factor: "; // Variables.Labels:16    TEXT_INPUT_CAL = "Calibration factor: "; // Variables.Labels:16
    TEXT_INPUT_CONC = "Concentration: "; // Variables.Labels:17    TEXT_INPUT_CONC = "Concentration: "; // Variables.Labels:17
    TEXT_INPUT_T = "Temperature (K): "; // Variables.Labels:18    TEXT_INPUT_T = "Temperature (K): "; // Variables.Labels:18
    TEXT_INPUT_VISCO = "Viscosity (Pa.s): "; // Variables.Labels:19    TEXT_INPUT_VISCO = "Viscosity (Pa.s): "; // Variables.Labels:19
    TEXT_INPUT_DIFF = "D simulation: "; // Variables.Labels:20    TEXT_INPUT_DIFF = "D simulation: "; // Variables.Labels:20
    TEXT_INPUT_RDIFF = "D real (microns²/s): "; // Variables.Labels:21    TEXT_INPUT_RDIFF = "D real (microns²/s): "; // Variables.Labels:21
    TEXT_INPUT_BOUNDARIES = "No contour boundaries? "; // Variables.Labels:22    TEXT_INPUT_BOUNDARIES = "No contour boundaries? "; // Variables.Labels:22
    TEXT_INPUT_WALLS = "Walls? "; // Variables.Labels:23    TEXT_INPUT_WALLS = "Walls? "; // Variables.Labels:23
    TEXT_INPUT_CTE = "constant:"; // Variables.Labels:24    TEXT_INPUT_CTE = "constant:"; // Variables.Labels:24
    TEXT_INPUT_CYCLIC = "Cyclic? "; // Variables.Labels:25    TEXT_INPUT_CYCLIC = "Cyclic? "; // Variables.Labels:25
    TEXT_INPUT_DISKFORCE = "Disk forces? "; // Variables.Labels:26    TEXT_INPUT_DISKFORCE = "Disk forces? "; // Variables.Labels:26
    TEXT_INPUT_EXCLUSION = "Exclusion volume force? "; // Variables.Labels:27    TEXT_INPUT_EXCLUSION = "Exclusion volume force? "; // Variables.Labels:27
    TEXT_INPUT_R12 = "Potential r^(-12)?: "; // Variables.Labels:28    TEXT_INPUT_R12 = "Potential r^(-12)?: "; // Variables.Labels:28
    TEXT_INPUT_R36 = "Potential r^(-36)?: "; // Variables.Labels:29    TEXT_INPUT_R36 = "Potential r^(-36)?: "; // Variables.Labels:29
    TEXT_INPUT_HEYES = "Heyes method: "; // Variables.Labels:30    TEXT_INPUT_HEYES = "Heyes method: "; // Variables.Labels:30
    TEXT_INPUT_DTINTXT = "Dif. dt in txt? "; // Variables.Labels:31    TEXT_INPUT_DTINTXT = "Dif. dt in txt? "; // Variables.Labels:31
    TEXT_INPUT_OPTICAL = "Optical trap? "; // Variables.Labels:32    TEXT_INPUT_OPTICAL = "Optical trap? "; // Variables.Labels:32
    TEXT_INPUT_KX = "k_x: "; // Variables.Labels:33    TEXT_INPUT_KX = "k_x: "; // Variables.Labels:33
    TEXT_INPUT_KY = "k_y: "; // Variables.Labels:34    TEXT_INPUT_KY = "k_y: "; // Variables.Labels:34
    TEXT_INPUT_AO = "AO force?: "; // Variables.Labels:35    TEXT_INPUT_AO = "AO force?: "; // Variables.Labels:35
    TEXT_INPUT_RG = "Rg (nm): "; // Variables.Labels:36    TEXT_INPUT_RG = "Rg (nm): "; // Variables.Labels:36
    TEXT_INPUT_LONGAOCTE = "C in np=C*(4/3)Pi/Rge+3Π/KT (1/microns³): "; // Variables.Labels:37    TEXT_INPUT_LONGAOCTE = "C in np=C*(4/3)Pi/Rge+3Π/KT (1/microns³): "; // Variables.Labels:37
    TEXT_INPUT_ELECPOT = "Pot Elec. Atrac? "; // Variables.Labels:38    TEXT_INPUT_ELECPOT = "Pot Elec. Atrac? "; // Variables.Labels:38
    TEXT_INPUT_Z = "Z: "; // Variables.Labels:39    TEXT_INPUT_Z = "Z: "; // Variables.Labels:39
    TEXT_INPUT_LAMBDA = "λB (nm): "; // Variables.Labels:40    TEXT_INPUT_LAMBDA = "λB (nm): "; // Variables.Labels:40
    TEXT_INPUT_KAPPA = "1/κ (microns): "; // Variables.Labels:41    TEXT_INPUT_KAPPA = "1/κ (microns): "; // Variables.Labels:41
    TEXT_INPUT_Q = "q :"; // Variables.Labels:42    TEXT_INPUT_Q = "q :"; // Variables.Labels:42
    MSG_WRITE_INPUT_FILE = "Writing input data file: "; // Variables.Labels:43    MSG_WRITE_INPUT_FILE = "Writing input data file: "; // Variables.Labels:43
    _ODEi_evolution1 = new _ODE_evolution1();
  }

  public void _initializeSolvers () { for (org.opensourcephysics.numerics.ode_solvers.EjsS_ODE __pode : _privateOdesList.values()) __pode.initializeSolver(); }

  public void _initializeModel () {
    __shouldBreak = false;
    boolean _wasEnabled_initialization1 = _isEnabled_initialization1;
    if (_wasEnabled_initialization1) _initialization1 ();
    if (__shouldBreak) return;
    _initializeSolvers();
  }

  public void _automaticResetSolvers() { 
    _ODEi_evolution1.automaticResetSolver();
  }
  public void _resetSolvers() { 
    _ODEi_evolution1.resetSolver();
  }
  public void _stepModel () {
    __shouldBreak = false;
    boolean _wasEnabled_evolution1 = _isEnabled_evolution1;
    if (_wasEnabled_evolution1) _ODEi_evolution1.step();
    if (__shouldBreak) return;
  }

  public void _updateModel () {
    __shouldBreak = false;
    boolean _wasEnabled_constraints1 = _isEnabled_constraints1;
    boolean _wasEnabled_constraints2 = _isEnabled_constraints2;
    boolean _wasEnabled_constraints3 = _isEnabled_constraints3;
    boolean _wasEnabled_constraints4 = _isEnabled_constraints4;
    boolean _wasEnabled_constraints5 = _isEnabled_constraints5;
    boolean _wasEnabled_constraints6 = _isEnabled_constraints6;
    boolean _wasEnabled_constraints7 = _isEnabled_constraints7;
    if (_wasEnabled_constraints1) _constraints1 ();
    if (__shouldBreak) return;
    if (_wasEnabled_constraints2) _constraints2 ();
    if (__shouldBreak) return;
    if (_wasEnabled_constraints3) _constraints3 ();
    if (__shouldBreak) return;
    if (_wasEnabled_constraints4) _constraints4 ();
    if (__shouldBreak) return;
    if (_wasEnabled_constraints5) _constraints5 ();
    if (__shouldBreak) return;
    if (_wasEnabled_constraints6) _constraints6 ();
    if (__shouldBreak) return;
    if (_wasEnabled_constraints7) _constraints7 ();
    if (__shouldBreak) return;
  }

  public void _readFromViewAfterUpdate () {
  }

  public void _freeMemory () {
    getSimulation().setEnded(); // Signal that the simulation ended already
    diameter = null;  // Variables.Particles:5
    x = null;  // Variables.Particles:8
    x_0 = null;  // Variables.Particles:9
    x_prev = null;  // Variables.Particles:10
    vx = null;  // Variables.Particles:11
    y_0 = null;  // Variables.Particles:12
    y_prev = null;  // Variables.Particles:13
    y = null;  // Variables.Particles:14
    vy = null;  // Variables.Particles:15
    freqHistoJumps = null;  // Variables.Statistics:2
    countHistoJumpsX = null;  // Variables.Statistics:5
    countHistoJumpsY = null;  // Variables.Statistics:6
    freqHistoOptPot = null;  // Variables.Statistics:10
    countHistoOptPotX = null;  // Variables.Statistics:11
    countHistoOptPotY = null;  // Variables.Statistics:12
    _ODEi_evolution1=null;
    System.gc(); // Free memory from unused old arrays
  }

 // -------------------------------------------
 // ODEs declaration 
 // -------------------------------------------

  protected java.util.Hashtable<String,org.opensourcephysics.numerics.ode_solvers.EjsS_ODE> _privateOdesList = new java.util.Hashtable<String,org.opensourcephysics.numerics.ode_solvers.EjsS_ODE>();

  public org.opensourcephysics.numerics.ode_solvers.EjsS_ODE _getODE(String _odeName) {
    try { return _privateOdesList.get(_odeName); }
    catch (Exception __exc) { return null; }
  }

  public org.opensourcephysics.numerics.ode_solvers.InterpolatorEventSolver _getEventSolver(String _odeName) {
    try { return _privateOdesList.get(_odeName).getEventSolver(); }
    catch (Exception __exc) { return null; }
  }

  public void _setSolverClass (String _odeName, Class<?> _solverClass) { // Change the solver in run-time
    try { _privateOdesList.get(_odeName).setSolverClass(_solverClass); }
    catch (Exception __exc) { System.err.println ("There is no ODE with this name "+_odeName); }
  }

  public String _setSolverClass (String _odeName, String _solverClassName) { // Change the solver in run-time
    if (_solverClassName==null) { System.err.println ("Null solver class name!"); return null; }
    try { return _privateOdesList.get(_odeName).setSolverClass(_solverClassName); }
    catch (Exception __exc) { System.err.println ("There is no ODE with this name "+_odeName); return null; }
  }

 // -------------------------------------------
 // Variables defined by the user
 // -------------------------------------------

 public int n  = 10; // Variables.Particles:1
 public double narray  = 5000; // Variables.Particles:2
 public double diameter_c  = 0.1; // Variables.Particles:3
 public double d_real  = 1.88; // Variables.Particles:4
 public double diameter []; // Variables.Particles:5
 public double vx_0  = 0; // Variables.Particles:6
 public double vy_0  = 0; // Variables.Particles:7
 public double x []; // Variables.Particles:8
 public double x_0 []; // Variables.Particles:9
 public double x_prev []; // Variables.Particles:10
 public double vx []; // Variables.Particles:11
 public double y_0 []; // Variables.Particles:12
 public double y_prev []; // Variables.Particles:13
 public double y []; // Variables.Particles:14
 public double vy []; // Variables.Particles:15
 public double microns  = 1e-6; // Variables.Particles:16
 public double a  = diameter_c/2.0; // Variables.Particles:17
 public double a_real  = d_real/2.0; // Variables.Particles:18
 public double f_p  = a_real/a; // Variables.Particles:19
 public double if_p  = 1/f_p; // Variables.Particles:20
 public double eta0  = 0.0013; // Variables.Particles:21
 public double eta  = eta0*(f_p*microns); // Variables.Particles:22
 public double T  = 294.0; // Variables.Particles:23
 public double K_B  = (1.38e-23)/(f_p*f_p*microns*microns); // Variables.Particles:24
 public double D  = K_B*T/(6*3.1416*eta*a); // Variables.Particles:25
 public double chi  = 6*3.141592*eta*a; // Variables.Particles:26
 public boolean bUseWater  = true; // Variables.Particles:27
 public ArrayList arraylist_Strings  = null; // Variables.Particles:28
 public ArrayList arraylist_StringsStats  = null; // Variables.Particles:29
 public int count_images  = 0; // Variables.Particles:30
 public int count_images_total  = 1; // Variables.Particles:31
 public int count_images_dt  = 0; // Variables.Particles:32
 public int count_images_dt_total  = 1; // Variables.Particles:33
 public double checker_t  = 0; // Variables.Particles:34
 public double xmin  = -1; // Variables.Common:1
 public double xmax  = 1; // Variables.Common:2
 public double ymin  = -1; // Variables.Common:3
 public double ymax  = 1; // Variables.Common:4
 public double t  = 0; // Variables.Common:5
 public double dt  = 0.0010; // Variables.Common:6
 public double tmax  = 10.00; // Variables.Common:7
 public double textra  = 0; // Variables.Common:8
 public double numberOfSteps  = n*tmax/dt; // Variables.Common:9
 public double limitOfSteps  = 5e5; // Variables.Common:10
 public double dMaxTime  = 1e4; // Variables.Common:11
 public double dTimeMaxImposed  = 0.0; // Variables.Common:12
 public double dtInTxt  = 0.1; // Variables.Common:13
 public boolean bDtInTxt  = false; // Variables.Common:14
 public boolean bSaveDataAuto  = false; // Variables.Common:15
 public int iNumLogSave  = 1; // Variables.Common:16
 public double ep  = 1.0; // Variables.Common:17
 public double ed  = 0.1; // Variables.Common:18
 public String sFileName  = "FILENAME"; // Variables.Common:19
 public String sDirectoryName  = System.getProperty("user.dir")+File.separator;; // Variables.Common:20
 public String sInputFileName  = "input_"+this.sFileName+".txt";; // Variables.Common:21
 public String sReadInputFilePath  = this.sDirectoryName+this.sInputFileName;; // Variables.Common:22
 public String sReadFilePath  = this.sDirectoryName+this.sFileName+".txt";; // Variables.Common:23
 public boolean bexclusion1k  = false; // Variables.Common:24
 public double Dreal  = D*f_p*f_p; // Variables.Common:25
 public double phi_2D  = 3.141592*a*a*n/((xmax-xmin)*(ymax-ymin));; // Variables.Common:26
 public boolean bIncludeLabelDisk  = true; // Variables.Common:27
 public double TOLERANCE  = Double.MIN_VALUE;; // Variables.Events:1
 public boolean bUseCyclicContour  = false; // Variables.Events:2
 public boolean bUseWallForces  = true; // Variables.Events:3
 public boolean bUseNoContour  = true; // Variables.Events:4
 public int nInside  = 0; // Variables.Events:5
 public double tSave  = 0; // Variables.Events:6
 public boolean bSeparateDisks  = false; // Variables.Events:7
 public boolean bUseDiskForce  = true; // Variables.Events:8
 public boolean bUseOpticalForce  = true; // Variables.Events:9
 public double diam_reduction  = 0.5; // Variables.Events:10
 public boolean bFreeMode  = false; // Variables.Events:11
 public boolean bReadData  = false; // Variables.Events:12
 public int binHistoJumps  = 200; // Variables.Statistics:1
 public double freqHistoJumps []; // Variables.Statistics:2
 public double dFreqesp  = 0.0; // Variables.Statistics:3
 public double dFreqespOptPot  = 0.0; // Variables.Statistics:4
 public double countHistoJumpsX []; // Variables.Statistics:5
 public double countHistoJumpsY []; // Variables.Statistics:6
 public boolean bDoHistoJumps  = true; // Variables.Statistics:7
 public double DHistoJumpsX  = 0.0; // Variables.Statistics:8
 public double DHistoJumpsY  = 0.0; // Variables.Statistics:9
 public double freqHistoOptPot []; // Variables.Statistics:10
 public double countHistoOptPotX []; // Variables.Statistics:11
 public double countHistoOptPotY []; // Variables.Statistics:12
 public boolean bDoHistoOptPot  = true; // Variables.Statistics:13
 public double kHistoOptPotX  = 0.0; // Variables.Statistics:14
 public double kHistoOptPotY  = 0.0; // Variables.Statistics:15
 public int particleXYexample  = 0; // Variables.Statistics:16
 public int particleXYexample2  = 0; // Variables.Statistics:17
 public double cte_f_exclusion  = 0; // Variables.Potentials:1
 public double cte_diffusion  = 0; // Variables.Potentials:2
 public boolean bAOmodel  = false; // Variables.Potentials:3
 public double Rg  = 500.0; // Variables.Potentials:4
 public double cteAOennp  = 0.5; // Variables.Potentials:5
 public double A0  = 0.5/(n); // Variables.Potentials:6
 public double A  = A0; // Variables.Potentials:7
 public double B  = 10; // Variables.Potentials:8
 public boolean bUseExclusionForce  = true; // Variables.Potentials:9
 public boolean bUseHSn12  = false; // Variables.Potentials:10
 public boolean bUseHSn36  = false; // Variables.Potentials:11
 public boolean bUseHSHeyes  = true; // Variables.Potentials:12
 public double cteAHSn12  = 10; // Variables.Potentials:13
 public double cteAHSn36  = 1; // Variables.Potentials:14
 public double ctekHSHeyes  = 150; // Variables.Potentials:15
 public boolean bUseElecAtracPot  = false; // Variables.Potentials:16
 public double Zelec  = 800; // Variables.Potentials:17
 public double lambdaelec  = 0.717; // Variables.Potentials:18
 public double kappainvelec  = 0.150; // Variables.Potentials:19
 public double qelec  = 13; // Variables.Potentials:20
 public double k_optics_y  = 0.5; // Variables.Potentials:21
 public double k_optics_x  = 0.5; // Variables.Potentials:22
 public String cabeceraEstadisticas  = "X"+"\t"+"Y"+"\t"+"time"+"\t"+"image"; // Variables.Labels:1
 public String sLabel  = "label"; // Variables.Labels:2
 public String MSG_OPEN_FILE  = "Opening file for saving data."; // Variables.Labels:3
 public String MSG_CLOSE_FILE  = "Closing text file."; // Variables.Labels:4
 public String MSG_WRITE_FILE  = "Writing data into text file."; // Variables.Labels:5
 public String MSG_WRITE_FILE_ERROR  = "No data to write into text file."; // Variables.Labels:6
 public String MSG_SAVING_ARRAY  = "Saving remaining data from array."; // Variables.Labels:7
 public String MSG_CLEARING_ARRAY  = "Clearing array."; // Variables.Labels:8
 public String TEXT_INPUT_FILE  = "File: "; // Variables.Labels:9
 public String TEXT_INPUT_TIMETOTAL  = "Total time (s): "; // Variables.Labels:10
 public String TEXT_INPUT_DT  = "dt (s): "; // Variables.Labels:11
 public String TEXT_INPUT_SEP  = "********************"; // Variables.Labels:12
 public String TEXT_INPUT_N  = "Number of particles: "; // Variables.Labels:13
 public String TEXT_INPUT_RDIAM  = "Real diameter (microns): "; // Variables.Labels:14
 public String TEXT_INPUT_DIAM  = "Diameter in simulation: "; // Variables.Labels:15
 public String TEXT_INPUT_CAL  = "Calibration factor: "; // Variables.Labels:16
 public String TEXT_INPUT_CONC  = "Concentration: "; // Variables.Labels:17
 public String TEXT_INPUT_T  = "Temperature (K): "; // Variables.Labels:18
 public String TEXT_INPUT_VISCO  = "Viscosity (Pa.s): "; // Variables.Labels:19
 public String TEXT_INPUT_DIFF  = "D simulation: "; // Variables.Labels:20
 public String TEXT_INPUT_RDIFF  = "D real (microns²/s): "; // Variables.Labels:21
 public String TEXT_INPUT_BOUNDARIES  = "No contour boundaries? "; // Variables.Labels:22
 public String TEXT_INPUT_WALLS  = "Walls? "; // Variables.Labels:23
 public String TEXT_INPUT_CTE  = "constant:"; // Variables.Labels:24
 public String TEXT_INPUT_CYCLIC  = "Cyclic? "; // Variables.Labels:25
 public String TEXT_INPUT_DISKFORCE  = "Disk forces? "; // Variables.Labels:26
 public String TEXT_INPUT_EXCLUSION  = "Exclusion volume force? "; // Variables.Labels:27
 public String TEXT_INPUT_R12  = "Potential r^(-12)?: "; // Variables.Labels:28
 public String TEXT_INPUT_R36  = "Potential r^(-36)?: "; // Variables.Labels:29
 public String TEXT_INPUT_HEYES  = "Heyes method: "; // Variables.Labels:30
 public String TEXT_INPUT_DTINTXT  = "Dif. dt in txt? "; // Variables.Labels:31
 public String TEXT_INPUT_OPTICAL  = "Optical trap? "; // Variables.Labels:32
 public String TEXT_INPUT_KX  = "k_x: "; // Variables.Labels:33
 public String TEXT_INPUT_KY  = "k_y: "; // Variables.Labels:34
 public String TEXT_INPUT_AO  = "AO force?: "; // Variables.Labels:35
 public String TEXT_INPUT_RG  = "Rg (nm): "; // Variables.Labels:36
 public String TEXT_INPUT_LONGAOCTE  = "C in np=C*(4/3)Pi/Rge+3Π/KT (1/microns³): "; // Variables.Labels:37
 public String TEXT_INPUT_ELECPOT  = "Pot Elec. Atrac? "; // Variables.Labels:38
 public String TEXT_INPUT_Z  = "Z: "; // Variables.Labels:39
 public String TEXT_INPUT_LAMBDA  = "λB (nm): "; // Variables.Labels:40
 public String TEXT_INPUT_KAPPA  = "1/κ (microns): "; // Variables.Labels:41
 public String TEXT_INPUT_Q  = "q :"; // Variables.Labels:42
 public String MSG_WRITE_INPUT_FILE  = "Writing input data file: "; // Variables.Labels:43

 // -------------------------------------------
 // Enabled condition of pages 
 // -------------------------------------------

  private boolean _isEnabled_initialization1 = true; // Enabled condition for Model.Initialization.Init
  private boolean _isEnabled_evolution1 = true; // Enabled condition for Model.Evolution.Movimiento
  private boolean _isEnabled_constraints1 = true; // Enabled condition for Model.Constraints.Inside
  private boolean _isEnabled_constraints2 = true; // Enabled condition for Model.Constraints.Cyclic
  private boolean _isEnabled_constraints3 = true; // Enabled condition for Model.Constraints.Gaussian
  private boolean _isEnabled_constraints4 = true; // Enabled condition for Model.Constraints.Optical Potential
  private boolean _isEnabled_constraints5 = true; // Enabled condition for Model.Constraints.Stop
  private boolean _isEnabled_constraints6 = true; // Enabled condition for Model.Constraints.Save data
  private boolean _isEnabled_constraints7 = true; // Enabled condition for Model.Constraints.Save data 2

  public void _setPageEnabled(String _pageName, boolean _enabled) { // Sets the enabled state of a page
    boolean _pageFound = false;
    if ("Init".equals(_pageName)) { _pageFound = true; _isEnabled_initialization1 = _enabled; } // Change enabled condition for Model.Initialization.Init
    if ("Movimiento".equals(_pageName)) { _pageFound = true; _isEnabled_evolution1 = _enabled; _automaticResetSolvers(); } // Change enabled condition for Model.Evolution.Movimiento
    if ("Inside".equals(_pageName)) { _pageFound = true; _isEnabled_constraints1 = _enabled; } // Change enabled condition for Model.Constraints.Inside
    if ("Cyclic".equals(_pageName)) { _pageFound = true; _isEnabled_constraints2 = _enabled; } // Change enabled condition for Model.Constraints.Cyclic
    if ("Gaussian".equals(_pageName)) { _pageFound = true; _isEnabled_constraints3 = _enabled; } // Change enabled condition for Model.Constraints.Gaussian
    if ("Optical Potential".equals(_pageName)) { _pageFound = true; _isEnabled_constraints4 = _enabled; } // Change enabled condition for Model.Constraints.Optical Potential
    if ("Stop".equals(_pageName)) { _pageFound = true; _isEnabled_constraints5 = _enabled; } // Change enabled condition for Model.Constraints.Stop
    if ("Save data".equals(_pageName)) { _pageFound = true; _isEnabled_constraints6 = _enabled; } // Change enabled condition for Model.Constraints.Save data
    if ("Save data 2".equals(_pageName)) { _pageFound = true; _isEnabled_constraints7 = _enabled; } // Change enabled condition for Model.Constraints.Save data 2
    if (!_pageFound) System.out.println ("_setPageEnabled() warning. Page not found: "+_pageName);
  }

 // -------------------------------------------
 // Methods defined by the user 
 // -------------------------------------------

 // --- Initialization

  public void _initialization1 () { // > Inicialización.Init
    //Clean memory  // > Inicialización.Init:1
    gcComplete();  // > Inicialización.Init:2
    //Clean traces on figures  // > Inicialización.Init:3
    this._view.resetTraces();  // > Inicialización.Init:4
    //Init some constants  // > Inicialización.Init:5
    initConstants();  // > Inicialización.Init:6
    //Init Arrays  // > Inicialización.Init:7
    initArrays();  // > Inicialización.Init:8
    //Make time equal to zero.  // > Inicialización.Init:9
    this.t=0.0;  // > Inicialización.Init:10
    //Move randomly the particles  // > Inicialización.Init:11
    randomParticles();  // > Inicialización.Init:12
    //Separate a little one particle from the other  // > Inicialización.Init:13
    separateDisksALittle();  // > Inicialización.Init:14
    //For Gaussians statistics.  // > Inicialización.Init:15
    if (this.bDoHistoJumps)  // > Inicialización.Init:16
      initHistogramJumps();  // > Inicialización.Init:17
    if ((this.bDoHistoOptPot) && (this.bUseOpticalForce))  // > Inicialización.Init:18
      initHistogramOpticalPotential();  // > Inicialización.Init:19
  }  // > Inicialización.Init

 // --- Evolution

  private _ODE_evolution1 _ODEi_evolution1;


  // ----------- private class for ODE in page Evolución:Movimiento

  private class _ODE_evolution1 implements org.opensourcephysics.numerics.ode_solvers.EjsS_ODE, org.opensourcephysics.numerics.ode_solvers.symplectic.VelocityVerletSavvy, org.opensourcephysics.numerics.ode_solvers.ZenoEffectListener {
    private org.opensourcephysics.numerics.ode_solvers.SolverEngine __solver=null; // The solver engine
    private org.opensourcephysics.numerics.ode_solvers.InterpolatorEventSolver __eventSolver=null; // The event solver
    private Class<?> __solverClass=null; // The solver class
    private double[] __state=null; // Our state array
    private boolean __ignoreErrors=false; // Whether to ignore solver errors
    private boolean __mustInitialize=true; // Be sure to initialize the solver
    private boolean __isEnabled=true; // Whether it is enabled
    private boolean __mustUserReinitialize=false; // Whether the user asked to reset the solver

    // Temporary array variables matching those defined by the user
    private double[] _x;
    private double[] _y;

    _ODE_evolution1() { // Class constructor
      __solverClass = org.opensourcephysics.numerics.ode_solvers.rk.EulerRichardson.class;
      __instantiateSolver();
      _privateOdesList.put("Movimiento",this);
    }

    public org.opensourcephysics.numerics.ode_solvers.InterpolatorEventSolver getEventSolver() { return __eventSolver; } 

    public void setSolverClass (Class<?> __aSolverClass) { // Change the solver in run-time
      this.__solverClass = __aSolverClass;
      __instantiateSolver();
    }

    public String setSolverClass (String _solverClassName) { // Change the solver in run-time
      String _prefix = "org.opensourcephysics.numerics.ode_solvers.";
      _solverClassName = _solverClassName.trim().toLowerCase();
      if (_solverClassName.indexOf("euler")>=0) {
        if (_solverClassName.indexOf("rich")>=0) _solverClassName = _prefix + "rk.EulerRichardson";
        else _solverClassName = _prefix + "rk.Euler";
      }
      else if (_solverClassName.indexOf("verlet")>=0) _solverClassName = _prefix + "symplectic.VelocityVerlet";
      else if (_solverClassName.indexOf("runge")>=0)  _solverClassName = _prefix + "rk.RK4";
      else if (_solverClassName.indexOf("rk4")>=0)    _solverClassName = _prefix + "rk.RK4";
      else if (_solverClassName.indexOf("boga")>=0)  _solverClassName = _prefix + "rk.BogackiShampine23";
      else if (_solverClassName.indexOf("cash")>=0)  _solverClassName = _prefix + "rk.CashKarp45";
      else if (_solverClassName.indexOf("fehl")>=0) {
        if (_solverClassName.indexOf("7")>=0) _solverClassName = _prefix + "rk.Fehlberg78";
        else _solverClassName = _prefix + "rk.Fehlberg8";
      }
      else if (_solverClassName.indexOf("dorm")>=0 || _solverClassName.indexOf("dopri")>=0) {
        if (_solverClassName.indexOf("8")>=0) _solverClassName = _prefix + "rk.Dopri853";
        else _solverClassName = _prefix + "rk.Dopri5";
      }
      else if (_solverClassName.indexOf("radau")>=0) _solverClassName = _prefix + "rk.Radau5";
      else { System.err.println ("There is no solver with this name "+_solverClassName); return null; }
      try { setSolverClass(Class.forName(_solverClassName)); }
      catch (Exception exc) { exc.printStackTrace(); }
      return _solverClassName;
    }

    private void __instantiateSolver () {
      __state = new double[1+x.length+y.length];
      // allocate temporary arrays
      _x = new double[x.length];
      _y = new double[y.length];
      __pushState();
      try { // Create the solver by reflection
        Class<?>[] __c = { };
        Object[] __o = { };
        java.lang.reflect.Constructor<?> __constructor = __solverClass.getDeclaredConstructor(__c);
        __solver = (org.opensourcephysics.numerics.ode_solvers.SolverEngine) __constructor.newInstance(__o);
      } catch (Exception exc) { exc.printStackTrace(); } 
      __eventSolver = new org.opensourcephysics.numerics.ode_solvers.InterpolatorEventSolver(__solver,this);
      __mustInitialize = true;
    }

    public void setEnabled (boolean __enabled) { __isEnabled = __enabled; }

    public double getIndependentVariableValue () { return __eventSolver.getIndependentVariableValue(); }

    public double getInternalStepSize () { return __eventSolver.getInternalStepSize(); }

    public boolean isAccelerationIndependentOfVelocity() { return false; }

    public void initializeSolver () {
      if (__arraysChanged()) { __instantiateSolver(); initializeSolver(); return; }
      __pushState();
      __eventSolver.initialize(dt);
      __eventSolver.setBestInterpolation(false);
      __eventSolver.setMaximumInternalSteps(10000);
      __eventSolver.removeAllEvents();
      __eventSolver.addZenoEffectListener(this);
      __eventSolver.setEstimateFirstStep(false);
      __eventSolver.setEnableExceptions(false);
      __eventSolver.setTolerances(0.00001,0.00001);
      __mustInitialize = false;
    }

    private void __pushState () { // Copy our variables to the state
      // Copy our variables to __state[] 
      int __cIn=0;
      System.arraycopy(x,0,__state,__cIn,x.length); __cIn += x.length;
      System.arraycopy(y,0,__state,__cIn,y.length); __cIn += y.length;
      __state[__cIn++] = t;
    }

    private boolean __arraysChanged () {
      if (x.length != _x.length) return true;
      if (y.length != _y.length) return true;
      return false;
    }

    public void resetSolver () {
      __mustUserReinitialize = true;
    }

    public void automaticResetSolver () {
    }

    private void __errorAction () {
      if (__ignoreErrors) return;
      System.err.println (__eventSolver.getErrorMessage());
      int __option = javax.swing.JOptionPane.showConfirmDialog(_view.getComponent(_simulation.getMainWindow()),org.colos.ejs.library.Simulation.getEjsString("ODEError.Continue"),
        org.colos.ejs.library.Simulation.getEjsString("Error"), javax.swing.JOptionPane.YES_NO_CANCEL_OPTION);
      if (__option==javax.swing.JOptionPane.YES_OPTION) __ignoreErrors = true;
      else if (__option==javax.swing.JOptionPane.CANCEL_OPTION) _pause();
    }

    public double step() { return __privateStep(false); }

    public double solverStep() { return __privateStep(true); }

    private double __privateStep(boolean __takeMaximumStep) {
      if (!__isEnabled) return 0;
      if (dt==0) return 0;
      if (__mustInitialize) initializeSolver();
      if (__arraysChanged()) { __instantiateSolver(); initializeSolver(); }
      __eventSolver.setStepSize(dt);
      __eventSolver.setInternalStepSize(dt);
      __eventSolver.setMaximumInternalSteps(10000);
      __eventSolver.setTolerances(0.00001,0.00001);
      __pushState();
      if (__mustUserReinitialize) { 
        __eventSolver.userReinitialize();
        __mustUserReinitialize = false;
        if (__eventSolver.getErrorCode()!=org.opensourcephysics.numerics.ode_solvers.InterpolatorEventSolver.ERROR.NO_ERROR) __errorAction();
      }
      __eventSolver.reinitialize(); // force synchronization: inefficient!
      if (__eventSolver.getErrorCode()!=org.opensourcephysics.numerics.ode_solvers.InterpolatorEventSolver.ERROR.NO_ERROR) __errorAction();
      double __stepTaken = __takeMaximumStep ? __eventSolver.maxStep() : __eventSolver.step();
      // Extract our variables from __state
      int __cOut=0;
      System.arraycopy(__state,__cOut,x,0,x.length); __cOut+=x.length;
      System.arraycopy(__state,__cOut,y,0,y.length); __cOut+=y.length;
      t = __state[__cOut++];
      // Check for error
      if (__eventSolver.getErrorCode()!=org.opensourcephysics.numerics.ode_solvers.InterpolatorEventSolver.ERROR.NO_ERROR) __errorAction();
      return __stepTaken;
    }

    public double[] getState () { return __state; }

    public void getRate (double[] __aState, double[] __aRate) {
      __aRate[__aRate.length-1] = 0.0; // In case the prelim code returns
      int __index=-1; // so that it can be used in preliminary code
      // Extract our variables from __aState
      int __cOut=0;
      double[] x = _x;
      System.arraycopy(__aState,__cOut,x,0,x.length); __cOut+=x.length;
      double[] y = _y;
      System.arraycopy(__aState,__cOut,y,0,y.length); __cOut+=y.length;
      double t = __aState[__cOut++];
      // Preliminary code: Código a ejecutar antes de evaluar las derivadas de las ecuaciones diferenciales
      // Compute the rate
      int __cRate = 0;
      for (int i=0; i<x.length; i++) __aRate[__cRate++] = force(i,t,x,y, diameter, diameter, vx,vy,true); // Evolución:Movimiento:1
      for (int i=0; i<y.length; i++) __aRate[__cRate++] = force(i,t,x,y, diameter, diameter, vx,vy, false); // Evolución:Movimiento:2
      __aRate[__cRate++] = 1.0; // The independent variable 
    }//end of getRate

    // Implementation of org.opensourcephysics.numerics.ZenoEffectListener
    public boolean zenoEffectAction(Object __anEvent, double[] __aState) {
      // Extract our variables from __aState
      int __cOut=0;
      System.arraycopy(__aState,__cOut,x,0,x.length); __cOut+=x.length;
      System.arraycopy(__aState,__cOut,y,0,y.length); __cOut+=y.length;
      t = __aState[__cOut++];
      // Copy our variables to __aState[] 
      int __cIn=0;
      System.arraycopy(x,0,__aState,__cIn,x.length); __cIn += x.length;
      System.arraycopy(y,0,__aState,__cIn,y.length); __cIn += y.length;
      __aState[__cIn++] = t;
      return false;
    }

  } // End of class _ODE_evolution1

 // --- Constraints

  public void _constraints1 () { // > Relaciones fijas.Inside
    //To count the number of particles inside the box  // > Relaciones fijas.Inside:1
    this.nInside=0;  // > Relaciones fijas.Inside:2
    for (int i=0; i<n; i++)  // > Relaciones fijas.Inside:3
    {   // > Relaciones fijas.Inside:4
        if ((isInsideBox(x[i], y[i])))  // > Relaciones fijas.Inside:5
          this.nInside++;  // > Relaciones fijas.Inside:6
    }  // > Relaciones fijas.Inside:7
  }  // > Relaciones fijas.Inside

  public void _constraints2 () { // > Relaciones fijas.Cyclic
    //In case of cyclic boundary conditions  // > Relaciones fijas.Cyclic:1
    if (this.bUseCyclicContour)  // > Relaciones fijas.Cyclic:2
    {  // > Relaciones fijas.Cyclic:3
      for (int i=0; i<n; i++)  // > Relaciones fijas.Cyclic:4
      {  // > Relaciones fijas.Cyclic:5
        boolean choquepared = isCollisionWithWall(x[i], y[i], vx[i], vy[i] ,diameter[i]);  // > Relaciones fijas.Cyclic:6
        if ((choquepared) && (isInsideBox(x[i], y[i])))  // > Relaciones fijas.Cyclic:7
        {  // > Relaciones fijas.Cyclic:8
          cyclicContour(i);  // > Relaciones fijas.Cyclic:9
          choquepared=false;  // > Relaciones fijas.Cyclic:10
        }  // > Relaciones fijas.Cyclic:11
        // > Relaciones fijas.Cyclic:12
      }  // > Relaciones fijas.Cyclic:13
    }  // > Relaciones fijas.Cyclic:14
  }  // > Relaciones fijas.Cyclic

  public void _constraints3 () { // > Relaciones fijas.Gaussian
    //For calculating Gaussian statistics in every step  // > Relaciones fijas.Gaussian:1
    if (this.bDoHistoJumps)  // > Relaciones fijas.Gaussian:2
    {  // > Relaciones fijas.Gaussian:3
        // > Relaciones fijas.Gaussian:4
       double[] deltaX = new double[this.n];  // > Relaciones fijas.Gaussian:5
       double[] deltaY = new double[this.n];  // > Relaciones fijas.Gaussian:6
       for (int i=0; i<this.n; i++)  // > Relaciones fijas.Gaussian:7
       {  // > Relaciones fijas.Gaussian:8
         deltaX[i] = this.x[i]-this.x_prev[i];  // > Relaciones fijas.Gaussian:9
         deltaY[i] = this.y[i]-this.y_prev[i];  // > Relaciones fijas.Gaussian:10
         this.x_prev[i] = this.x[i];  // > Relaciones fijas.Gaussian:11
         this.y_prev[i] = this.y[i];  // > Relaciones fijas.Gaussian:12
           // > Relaciones fijas.Gaussian:13
          for (int j=0; j<this.binHistoJumps; j++)  // > Relaciones fijas.Gaussian:14
          {  // > Relaciones fijas.Gaussian:15
                if ((deltaX[i]>=(this.freqHistoJumps[j]-this.dFreqesp/2.0)) && (deltaX[i]<(this.freqHistoJumps[j]+this.dFreqesp/2.0)))   // > Relaciones fijas.Gaussian:16
                  this.countHistoJumpsX[j]++;  // > Relaciones fijas.Gaussian:17
                if ((deltaY[i]>=(this.freqHistoJumps[j]-this.dFreqesp/2.0)) && (deltaY[i]<(this.freqHistoJumps[j]+this.dFreqesp/2.0)))   // > Relaciones fijas.Gaussian:18
                  this.countHistoJumpsY[j]++;  // > Relaciones fijas.Gaussian:19
                  // > Relaciones fijas.Gaussian:20
          }  // > Relaciones fijas.Gaussian:21
         // > Relaciones fijas.Gaussian:22
       //Diffusion coefficients from Gaussian fits.  // > Relaciones fijas.Gaussian:23
       double[] diff = getDifCoeffGaussian();  // > Relaciones fijas.Gaussian:24
       this.DHistoJumpsX = diff[0];  // > Relaciones fijas.Gaussian:25
       this.DHistoJumpsY = diff[1];  // > Relaciones fijas.Gaussian:26
        // > Relaciones fijas.Gaussian:27
       }  // > Relaciones fijas.Gaussian:28
         // > Relaciones fijas.Gaussian:29
         // > Relaciones fijas.Gaussian:30
    }      // > Relaciones fijas.Gaussian:31
       // > Relaciones fijas.Gaussian:32
  }  // > Relaciones fijas.Gaussian

  public void _constraints4 () { // > Relaciones fijas.Optical Potential
    //For calculating Boltzmann statistics in every step  // > Relaciones fijas.Optical Potential:1
    if ((this.bDoHistoOptPot) && (this.bUseOpticalForce))  // > Relaciones fijas.Optical Potential:2
    {  // > Relaciones fijas.Optical Potential:3
       double[] deltaX = new double[this.n];  // > Relaciones fijas.Optical Potential:4
       double[] deltaY = new double[this.n];  // > Relaciones fijas.Optical Potential:5
         // > Relaciones fijas.Optical Potential:6
       for (int i=0; i<this.n; i++)  // > Relaciones fijas.Optical Potential:7
       {  // > Relaciones fijas.Optical Potential:8
         deltaX[i] = this.x[i]-this.x_0[i];  // > Relaciones fijas.Optical Potential:9
         deltaY[i] = this.y[i]-this.y_0[i];  // > Relaciones fijas.Optical Potential:10
           // > Relaciones fijas.Optical Potential:11
        for (int j=0; j<this.binHistoJumps; j++)  // > Relaciones fijas.Optical Potential:12
          {  // > Relaciones fijas.Optical Potential:13
                if ((deltaX[i]>=(this.freqHistoOptPot[j]-this.dFreqespOptPot/2.0)) && (deltaX[i]<(this.freqHistoOptPot[j]+this.dFreqespOptPot/2.0)))   // > Relaciones fijas.Optical Potential:14
                  this.countHistoOptPotX[j]++;  // > Relaciones fijas.Optical Potential:15
                if ((deltaY[i]>=(this.freqHistoOptPot[j]-this.dFreqespOptPot/2.0)) && (deltaY[i]<(this.freqHistoOptPot[j]+this.dFreqespOptPot/2.0)))   // > Relaciones fijas.Optical Potential:16
                  this.countHistoOptPotY[j]++;  // > Relaciones fijas.Optical Potential:17
                    // > Relaciones fijas.Optical Potential:18
          }  // > Relaciones fijas.Optical Potential:19
       }  // > Relaciones fijas.Optical Potential:20
         // > Relaciones fijas.Optical Potential:21
       //Stiffnesses from Gaussian fits.  // > Relaciones fijas.Optical Potential:22
       double[] kGauss = getKGaussian();  // > Relaciones fijas.Optical Potential:23
       this.kHistoOptPotX = kGauss[0];  // > Relaciones fijas.Optical Potential:24
       this.kHistoOptPotY = kGauss[1];  // > Relaciones fijas.Optical Potential:25
         // > Relaciones fijas.Optical Potential:26
    }  // > Relaciones fijas.Optical Potential:27
  }  // > Relaciones fijas.Optical Potential

  public void _constraints5 () { // > Relaciones fijas.Stop
    //To pause the simulation in a fixed time      // > Relaciones fijas.Stop:1
    //Seems to pause after an extra step for long times.  // > Relaciones fijas.Stop:2
    if (!(t<tmax))  // > Relaciones fijas.Stop:3
    {  // > Relaciones fijas.Stop:4
       //Pauses simulation  // > Relaciones fijas.Stop:5
       _pause();  // > Relaciones fijas.Stop:6
       //while(t<tmax)  // > Relaciones fijas.Stop:7
       //  this._step();  // > Relaciones fijas.Stop:8
        // > Relaciones fijas.Stop:9
    }  // > Relaciones fijas.Stop:10
  }  // > Relaciones fijas.Stop

  public void _constraints6 () { // > Relaciones fijas.Save data
    //For saving data  // > Relaciones fijas.Save data:1
    //Important: same number of digits for t and dtInText  // > Relaciones fijas.Save data:2
    //For example: t = 0.001 and dtInText = 0.0025 give bad results in the mod op.  // > Relaciones fijas.Save data:3
    //Instead, it has to be t=0.0001 and dtInText = 0.0025.  // > Relaciones fijas.Save data:4
    if (!this.bFreeMode)  // > Relaciones fijas.Save data:5
    {  // > Relaciones fijas.Save data:6
        // > Relaciones fijas.Save data:7
      //Number for rounding methods.  // > Relaciones fijas.Save data:8
      //int m = 1000;  // > Relaciones fijas.Save data:9
      //int numceros = (int)Math.log10(m);  // > Relaciones fijas.Save data:10
      //New method. Uses dt as reference for the number of zeros.  // > Relaciones fijas.Save data:11
      int numceros = (int)Math.log10(1/this.dt);  // > Relaciones fijas.Save data:12
      int m = (int)(Math.pow(10,numceros));  // > Relaciones fijas.Save data:13
        // > Relaciones fijas.Save data:14
      //Extra time for not saving in the initial stages  // > Relaciones fijas.Save data:15
      double textra2 = 0.0;  // > Relaciones fijas.Save data:16
      textra2=this.textra;  // > Relaciones fijas.Save data:17
      //To check t value is increasing  // > Relaciones fijas.Save data:18
      if ((this.checker_t<(float)t) && (t>=textra2))  // > Relaciones fijas.Save data:19
      {  // > Relaciones fijas.Save data:20
        String str= "";  // > Relaciones fijas.Save data:21
        //To save only data for a give lapse of time  // > Relaciones fijas.Save data:22
        if (this.bDtInTxt)  // > Relaciones fijas.Save data:23
        {  // > Relaciones fijas.Save data:24
            // > Relaciones fijas.Save data:25
          double t2d = round(m*t,numceros);  // > Relaciones fijas.Save data:26
          double fdtTxt = round(m*this.dtInTxt,numceros);  // > Relaciones fijas.Save data:27
          //Deleting not required numbers  // > Relaciones fijas.Save data:28
          //this.dtInTxt = fdtTxt/m;  // > Relaciones fijas.Save data:29
            // > Relaciones fijas.Save data:30
          //To check result equal to time lapse  // > Relaciones fijas.Save data:31
          double dMod = 0.0;  // > Relaciones fijas.Save data:32
          boolean igual = (t2d==fdtTxt);  // > Relaciones fijas.Save data:33
          if (igual) dMod = 0.0;  // > Relaciones fijas.Save data:34
          else dMod = (t2d  % fdtTxt );  // > Relaciones fijas.Save data:35
              // > Relaciones fijas.Save data:36
          double fMod = round(dMod,numceros);  // > Relaciones fijas.Save data:37
            // > Relaciones fijas.Save data:38
          //Recovering original values  // > Relaciones fijas.Save data:39
          t2d = t2d/m;  // > Relaciones fijas.Save data:40
          fdtTxt = fdtTxt/m;  // > Relaciones fijas.Save data:41
          // > Relaciones fijas.Save data:42
          //In some cases, decimals appear.   // > Relaciones fijas.Save data:43
          //Instead of using ==0, it is used a tolerance  // > Relaciones fijas.Save data:44
          //value.  // > Relaciones fijas.Save data:45
          //BEFORE: boolean bModZero = (fMod==0.0);  // > Relaciones fijas.Save data:46
          //Now:  // > Relaciones fijas.Save data:47
          boolean bModZero = (fMod<1.0/m);  // > Relaciones fijas.Save data:48
            // > Relaciones fijas.Save data:49
          if (bModZero)  // > Relaciones fijas.Save data:50
          {  // > Relaciones fijas.Save data:51
              // > Relaciones fijas.Save data:52
            //Using td2 instead of t  // > Relaciones fijas.Save data:53
            str = getStringData(this.count_images_dt_total,(t2d), this.dtInTxt, this.x, this.y);  // > Relaciones fijas.Save data:54
            this.checker_t=t2d;  // > Relaciones fijas.Save data:55
            this.count_images_dt++;  // > Relaciones fijas.Save data:56
              // > Relaciones fijas.Save data:57
            this.count_images_dt_total++;  // > Relaciones fijas.Save data:58
            //Writing data to arrayList  // > Relaciones fijas.Save data:59
            ((ArrayList)arraylist_Strings).add(str);    // > Relaciones fijas.Save data:60
          }  // > Relaciones fijas.Save data:61
              // > Relaciones fijas.Save data:62
         }//END of if bDtInTxt  // > Relaciones fijas.Save data:63
         else  // > Relaciones fijas.Save data:64
         {  // > Relaciones fijas.Save data:65
           str = getStringData(this.count_images_total,(t), this.dt, this.x, this.y);    // > Relaciones fijas.Save data:66
           this.checker_t=(float)t;    // > Relaciones fijas.Save data:67
           //Writing data to arrayList  // > Relaciones fijas.Save data:68
          ((ArrayList)arraylist_Strings).add(str);    // > Relaciones fijas.Save data:69
           // > Relaciones fijas.Save data:70
         }  // > Relaciones fijas.Save data:71
          // > Relaciones fijas.Save data:72
         this.count_images++;  // > Relaciones fijas.Save data:73
         this.count_images_total++;  // > Relaciones fijas.Save data:74
          // > Relaciones fijas.Save data:75
         // > Relaciones fijas.Save data:76
      }//if checker  // > Relaciones fijas.Save data:77
        // > Relaciones fijas.Save data:78
    }      // > Relaciones fijas.Save data:79
    	  // > Relaciones fijas.Save data:80
         // > Relaciones fijas.Save data:81
          // > Relaciones fijas.Save data:82
          // > Relaciones fijas.Save data:83
          // > Relaciones fijas.Save data:84
  }  // > Relaciones fijas.Save data

  public void _constraints7 () { // > Relaciones fijas.Save data 2
    if (!this.bFreeMode)  // > Relaciones fijas.Save data 2:1
    {  // > Relaciones fijas.Save data 2:2
      //if we save data automatically every 10^this.iNumLogSave lines  // > Relaciones fijas.Save data 2:3
      if (this.bSaveDataAuto)  // > Relaciones fijas.Save data 2:4
      {      // > Relaciones fijas.Save data 2:5
        boolean bAddData = true;  // > Relaciones fijas.Save data 2:6
          // > Relaciones fijas.Save data 2:7
        //Number of lines if we have limited the interval of time  // > Relaciones fijas.Save data 2:8
        int counting_images = 0;  // > Relaciones fijas.Save data 2:9
        if (this.bDtInTxt)  // > Relaciones fijas.Save data 2:10
          counting_images = this.count_images_dt;  // > Relaciones fijas.Save data 2:11
        else  counting_images = this.count_images;  // > Relaciones fijas.Save data 2:12
          // > Relaciones fijas.Save data 2:13
        if ((int)Math.log10(counting_images)==this.iNumLogSave)  // > Relaciones fijas.Save data 2:14
        {  // > Relaciones fijas.Save data 2:15
           System.out.println("Saving "+(long)Math.pow(10,this.iNumLogSave)+" steps.");  // > Relaciones fijas.Save data 2:16
           System.out.println(this.MSG_CLEARING_ARRAY);  // > Relaciones fijas.Save data 2:17
                // > Relaciones fijas.Save data 2:18
           //open, write, and close every step.   // > Relaciones fijas.Save data 2:19
           //If not doing like that, it will give errors  // > Relaciones fijas.Save data 2:20
           writeDataOnTextFile(bAddData);  // > Relaciones fijas.Save data 2:21
             // > Relaciones fijas.Save data 2:22
           //Clean array of data  // > Relaciones fijas.Save data 2:23
           ((java.util.ArrayList)arraylist_Strings).clear();  // > Relaciones fijas.Save data 2:24
           this.count_images=0;  // > Relaciones fijas.Save data 2:25
           this.count_images_dt=0;  // > Relaciones fijas.Save data 2:26
           // > Relaciones fijas.Save data 2:27
         }  // > Relaciones fijas.Save data 2:28
       }  // > Relaciones fijas.Save data 2:29
    }  // > Relaciones fijas.Save data 2:30
        // > Relaciones fijas.Save data 2:31
  }  // > Relaciones fijas.Save data 2

 // --- Custom

  /**  // > Propio.Initial:1
  Initial values for constants. Instead of making dimensionless quantities,  // > Propio.Initial:2
  the dimensions are given in "screen units" or "ejs units".  // > Propio.Initial:3
  For doing this, the units are converted to microns and then are multiplied by  // > Propio.Initial:4
  if_p = a/a_real.   // > Propio.Initial:5
  Example [eta] = Pa.s = F/m².s = kg.m /m²/s = kg/m.s   // > Propio.Initial:6
  = kg/(s.(um 10e+6)) = kg 10e-6 / s. (ejs a/a_real) =  // > Propio.Initial:7
  = kg 10e-6 * f_p /s .ejm  // > Propio.Initial:8
  Then eta = eta0 * micras * f_p in "ejs" units or "screen units".  // > Propio.Initial:9
  */  // > Propio.Initial:10
  public void initConstants()  // > Propio.Initial:11
  {  // > Propio.Initial:12
    this.diameter_c = 2.0*Math.sqrt(((this.xmax-this.xmin)*(this.ymax-this.ymin)*this.phi_2D)/(Math.PI*this.n));  // > Propio.Initial:13
    this.a=this.diameter_c/2.0;  // > Propio.Initial:14
    this.a_real=this.d_real/2.0;  // > Propio.Initial:15
      // > Propio.Initial:16
    //Conversion factor  // > Propio.Initial:17
    this.f_p = this.a_real/this.a;  // > Propio.Initial:18
    //Conversion microns to units of simulation or "screen units"  // > Propio.Initial:19
    this.if_p=1/this.f_p;  // > Propio.Initial:20
      // > Propio.Initial:21
    //If the fluid is water we know the value of eta  // > Propio.Initial:22
    if (this.bUseWater)  // > Propio.Initial:23
      this.eta0=(1/1000.0)*(0.2727+1.4893*Math.exp((273-this.T)/28.693));  // > Propio.Initial:24
    this.eta=(this.f_p*this.microns)*this.eta0;  // > Propio.Initial:25
      // > Propio.Initial:26
    //In "screen units"  // > Propio.Initial:27
    this.K_B = (1.38e-23)/(this.f_p*this.f_p*this.microns*this.microns);  // > Propio.Initial:28
    this.chi = 6*Math.PI*this.eta*this.a;  // > Propio.Initial:29
    this.D = K_B*T/(this.chi);  // > Propio.Initial:30
      // > Propio.Initial:31
    //In microns units.  // > Propio.Initial:32
    this.Dreal=this.D*this.f_p*this.f_p;    // > Propio.Initial:33
      // > Propio.Initial:34
    this.cte_diffusion = Math.sqrt(2.0*this.D/(dt));    // > Propio.Initial:35
      // > Propio.Initial:36
    this.cte_f_exclusion = 4;  // > Propio.Initial:37
      // > Propio.Initial:38
    //Number of total lines:   // > Propio.Initial:39
    double dift = dt;  // > Propio.Initial:40
    if (this.bDtInTxt) dift = this.dtInTxt;  // > Propio.Initial:41
    this.numberOfSteps = this.n*tmax/dift;  // > Propio.Initial:42
    this.dTimeMaxImposed = this.limitOfSteps*dift/n;  // > Propio.Initial:43
      // > Propio.Initial:44
    //Images or steps counters to zero.  // > Propio.Initial:45
    this.count_images_dt= 0;  // > Propio.Initial:46
    this.count_images_dt_total= 1;  // > Propio.Initial:47
    this.count_images= 0;  // > Propio.Initial:48
    this.count_images_total=1;  // > Propio.Initial:49
    this.checker_t=0.0;  // > Propio.Initial:50
  }  // > Propio.Initial:51
  /**  // > Propio.Initial:52
  Initialize arrays and lists  // > Propio.Initial:53
  */  // > Propio.Initial:54
  public void initArrays()  // > Propio.Initial:55
  {  // > Propio.Initial:56
      // > Propio.Initial:57
    this.arraylist_Strings = new ArrayList();  // > Propio.Initial:58
    this.arraylist_StringsStats  = new ArrayList();  // > Propio.Initial:59
    this.diameter = new double[this.n];  // > Propio.Initial:60
    this.vx = new double[this.n];  // > Propio.Initial:61
    this.vy = new double[this.n];  // > Propio.Initial:62
    this.x = new double[this.n];  // > Propio.Initial:63
    this.y = new double[this.n];  // > Propio.Initial:64
    this.x_0 = new double[this.n];  // > Propio.Initial:65
    this.y_0 = new double[this.n];  // > Propio.Initial:66
    this.x_prev = new double[this.n];  // > Propio.Initial:67
    this.y_prev = new double[this.n];  // > Propio.Initial:68
    for(int i=0; i<n;i++)   // > Propio.Initial:69
    {  // > Propio.Initial:70
      this.diameter[i]=this.diameter_c;  // > Propio.Initial:71
      this.vx[i]=this.vx_0;  // > Propio.Initial:72
      this.vy[i]=this.vy_0;  // > Propio.Initial:73
      this.x[i]=0.0;  // > Propio.Initial:74
      this.y[i]=0.0;  // > Propio.Initial:75
      this.x_0[i]=0.0;  // > Propio.Initial:76
      this.y_0[i]=0.0;    // > Propio.Initial:77
      this.x_prev[i]=0.0;  // > Propio.Initial:78
      this.y_prev[i]=0.0;    // > Propio.Initial:79
    }  // > Propio.Initial:80
  }    // > Propio.Initial:81
  /**  // > Propio.Initial:82
  Initial positions of the particles. They are moved randomly.  // > Propio.Initial:83
  Code simplified from previous version  // > Propio.Initial:84
  */  // > Propio.Initial:85
  public void randomParticles()  // > Propio.Initial:86
  {  // > Propio.Initial:87
    boolean estadoLegal = true;  // > Propio.Initial:88
      // > Propio.Initial:89
    //If there is only one particle, it appears in the center of the image.  // > Propio.Initial:90
    if (n>1)  // > Propio.Initial:91
    {  // > Propio.Initial:92
      int intento= 0;  // > Propio.Initial:93
      // > Propio.Initial:94
      do  // > Propio.Initial:95
      {  // > Propio.Initial:96
        intento++;  // > Propio.Initial:97
        for (int i=0; i<n; i++)  // > Propio.Initial:98
        {  // > Propio.Initial:99
           x[i]=xmin+0.5*diameter[i]+(Math.random()*(xmax-xmin-diameter[i]));  // > Propio.Initial:100
           x_0[i] = x[i];  // > Propio.Initial:101
           vx[i]=vx_0*randomValue(0.2);  // > Propio.Initial:102
         // > Propio.Initial:103
           y[i]=ymin+0.5*diameter[i]+(Math.random()*(ymax-ymin-diameter[i]));  // > Propio.Initial:104
           y_0[i] = y[i];       // > Propio.Initial:105
           vy[i]=vy_0*randomValue(0.2);  // > Propio.Initial:106
        }  // > Propio.Initial:107
        for (int j=0; j<n; j++)  // > Propio.Initial:108
        {  // > Propio.Initial:109
            if (!(isInsideBox(x[j],y[j])))   // > Propio.Initial:110
              { estadoLegal = false; break;}  // > Propio.Initial:111
        }  // > Propio.Initial:112
        // > Propio.Initial:113
      }while((estadoLegal==false) && (intento<200));  // > Propio.Initial:114
      // > Propio.Initial:115
      if (!estadoLegal) _println("Error in the random location of particles!");  // > Propio.Initial:116
    }   // > Propio.Initial:117
     // > Propio.Initial:118
  }    // > Propio.Initial:119
  /**  // > Propio.Initial:120
  After initialization the disks are separated to avoid overlapping.  // > Propio.Initial:121
  Code changed from previous version  // > Propio.Initial:122
  */  // > Propio.Initial:123
  public void separateDisksALittle()  // > Propio.Initial:124
  {  // > Propio.Initial:125
     if (n==1) this.bSeparateDisks = false;  // > Propio.Initial:126
      else this.bSeparateDisks = true;  // > Propio.Initial:127
     if (this.bSeparateDisks)  // > Propio.Initial:128
     {  // > Propio.Initial:129
     // > Propio.Initial:130
       boolean sigo=true;  // > Propio.Initial:131
       do  // > Propio.Initial:132
       {  // > Propio.Initial:133
         for(int i=0; i<n;i++)  // > Propio.Initial:134
         {     // > Propio.Initial:135
            for(int j=0; j<n;j++)  // > Propio.Initial:136
            {  // > Propio.Initial:137
            // > Propio.Initial:138
              if (i!=j)  // > Propio.Initial:139
              {  // > Propio.Initial:140
                double r = twoParticlesDistance(x[i],y[i],x[j],y[j]);  // > Propio.Initial:141
                 //Changed this for high concentration  // > Propio.Initial:142
                 //Particles should not leave the box at the beggining  // > Propio.Initial:143
                 if (r<a/2.0)  // > Propio.Initial:144
                 {  // > Propio.Initial:145
                   double dx = x[j]-x[i];  // > Propio.Initial:146
                   double dy = y[j]-y[i];  // > Propio.Initial:147
                   x[i]=x[i]-2*a*dx/r;y[i]=y[i]-2*a*dy/r;  // > Propio.Initial:148
                   if (!(isInsideBox(x[i],y[i])))   // > Propio.Initial:149
                   {  // > Propio.Initial:150
                     x[i]=x[i]+a*dx/r;y[i]=y[i]+a*dy/r;  // > Propio.Initial:151
                     //Move xj   // > Propio.Initial:152
                     x[j]=x[j]+a*dx/r;y[j]=y[j]+a*dy/r;  // > Propio.Initial:153
                       // > Propio.Initial:154
                     if (!(isInsideBox(x[j],y[j])))  // > Propio.Initial:155
                       x[j]=x[j]-0.5*a*dx/r;y[j]=y[j]-0.5*a*dy/r;  // > Propio.Initial:156
                   }  // > Propio.Initial:157
                 // > Propio.Initial:158
                 }  // > Propio.Initial:159
                 else sigo=false;  // > Propio.Initial:160
               }  // > Propio.Initial:161
             }//for1  // > Propio.Initial:162
           } //for2  // > Propio.Initial:163
        }while(sigo);    // > Propio.Initial:164
      }//if  // > Propio.Initial:165
     // > Propio.Initial:166
  }  // > Propio.Initial:167
  /**  // > Propio.Initial:168
  Initialize data for Gaussian statistics.  // > Propio.Initial:169
  */  // > Propio.Initial:170
  public void initHistogramJumps()  // > Propio.Initial:171
  {  // > Propio.Initial:172
     double meanjump = Math.sqrt(this.dt*this.D);  // > Propio.Initial:173
     double maxDeltaX = meanjump*5;  // > Propio.Initial:174
     double minDeltaX = -meanjump*5;  // > Propio.Initial:175
     int bin = this.binHistoJumps;  // > Propio.Initial:176
      // > Propio.Initial:177
     //We will include two more spaces in the begin and the end.  // > Propio.Initial:178
     double freqesp = (maxDeltaX - minDeltaX)/(double)(bin-2);  // > Propio.Initial:179
     this.dFreqesp = freqesp;  // > Propio.Initial:180
     this.freqHistoJumps[0] = minDeltaX - freqesp/2.0;  // > Propio.Initial:181
     this.countHistoJumpsX[0] = 0.0;  // > Propio.Initial:182
     this.countHistoJumpsY[0] = 0.0;  // > Propio.Initial:183
     this.freqHistoJumps[bin-1] = maxDeltaX + freqesp/2.0;  // > Propio.Initial:184
     this.countHistoJumpsX[bin-1] = 0.0;  // > Propio.Initial:185
     this.countHistoJumpsY[bin-1] = 0.0;  // > Propio.Initial:186
     for (int i=1; i<bin-1; i++)  // > Propio.Initial:187
     {  // > Propio.Initial:188
       this.freqHistoJumps[i] = this.freqHistoJumps[0]+i*freqesp;  // > Propio.Initial:189
       this.countHistoJumpsX[i] = 0.0;  // > Propio.Initial:190
       this.countHistoJumpsY[i] = 0.0;  // > Propio.Initial:191
     }  // > Propio.Initial:192
      // > Propio.Initial:193
  }  // > Propio.Initial:194
  /**  // > Propio.Initial:195
  Initialize data for Boltzmann statistics.  // > Propio.Initial:196
  */  // > Propio.Initial:197
  public void initHistogramOpticalPotential()  // > Propio.Initial:198
  {  // > Propio.Initial:199
     double meank = (this.k_optics_y+this.k_optics_x)/2.0;  // > Propio.Initial:200
     double sigma_estimated = Math.sqrt(K_B*T/(meank*microns));  // > Propio.Initial:201
     double maxDelta = 10*sigma_estimated;  // > Propio.Initial:202
     double minDelta = -maxDelta;  // > Propio.Initial:203
       // > Propio.Initial:204
     int bin = this.binHistoJumps;  // > Propio.Initial:205
     //We include two more spaces in the begin and the end.  // > Propio.Initial:206
     double freqesp = (maxDelta - minDelta)/(double)(bin-2);  // > Propio.Initial:207
     this.dFreqespOptPot = freqesp;  // > Propio.Initial:208
       // > Propio.Initial:209
     this.freqHistoOptPot[0] = minDelta - freqesp/2.0;  // > Propio.Initial:210
     this.countHistoOptPotX[0] = 0.0;  // > Propio.Initial:211
     this.countHistoOptPotY[0] = 0.0;  // > Propio.Initial:212
     this.freqHistoOptPot[bin-1] = maxDelta + freqesp/2.0;  // > Propio.Initial:213
     this.countHistoOptPotX[bin-1] = 0.0;  // > Propio.Initial:214
     this.countHistoOptPotY[bin-1] = 0.0;  // > Propio.Initial:215
     for (int i=1; i<bin-1; i++)  // > Propio.Initial:216
     {  // > Propio.Initial:217
       this.freqHistoOptPot[i] = this.freqHistoOptPot[0]+i*freqesp;  // > Propio.Initial:218
       this.countHistoOptPotX[i] = 0.0;  // > Propio.Initial:219
       this.countHistoOptPotY[i] = 0.0;  // > Propio.Initial:220
     }  // > Propio.Initial:221
  }  // > Propio.Initial:222
  /**  // > Propio.Initial:223
  This method is used for freeing up memory.  // > Propio.Initial:224
  */  // > Propio.Initial:225
  public void gcComplete()  // > Propio.Initial:226
  {  // > Propio.Initial:227
    String MSG_FREEMEMORY_CURRENT = "Current Free Memory: ";  // > Propio.Initial:228
    String MSG_FREEMEMORY_FREEING = "Freeing Up Memory: ";  // > Propio.Initial:229
    Runtime rt = Runtime.getRuntime();  // > Propio.Initial:230
    long estaLibre = rt.freeMemory();  // > Propio.Initial:231
    System.out.println(MSG_FREEMEMORY_CURRENT+estaLibre);  // > Propio.Initial:232
    long estabaLibre;  // > Propio.Initial:233
    do  // > Propio.Initial:234
    {  // > Propio.Initial:235
      estabaLibre = estaLibre;  // > Propio.Initial:236
      System.out.println(MSG_FREEMEMORY_FREEING+estabaLibre);  // > Propio.Initial:237
      rt.runFinalization();  // > Propio.Initial:238
      rt.gc();  // > Propio.Initial:239
      estaLibre = rt.freeMemory();  // > Propio.Initial:240
    }while (estaLibre > estabaLibre);  // > Propio.Initial:241
  	  // > Propio.Initial:242
  }  // > Propio.Initial:243

  /**  // > Propio.Forces:1
  Force to be included in the evolution.   // > Propio.Forces:2
  Velocities are included because of the wall limits.   // > Propio.Forces:3
  and are added like vx = dx/dt = fx y vy= dy/dt = fy in the final line  // > Propio.Forces:4
  of the method.  // > Propio.Forces:5
  @param part Particle in the evolution.  // > Propio.Forces:6
  @param t  Time.  // > Propio.Forces:7
  @param posx Array with positions on x of the particles for a given time t.  // > Propio.Forces:8
  @param posy Array with positions on y of the particles for a given time t.  // > Propio.Forces:9
  @param diam1 Array with x diameters oof the particles for a given time t.  // > Propio.Forces:10
  @param diam1 Array with y diameters oof the particles for a given time t.  // > Propio.Forces:11
  @param posx Array with x velocities of the particles for a given time t.  // > Propio.Forces:12
  @param posy Array with y velocities of the particles for a given time t.  // > Propio.Forces:13
  @param bIsX Boolean true if is x coordinate or false for y coordinate.  // > Propio.Forces:14
  */  // > Propio.Forces:15
  synchronized public double force( int part, double t,  // > Propio.Forces:16
                                    double[] posx,  double[] posy,  // > Propio.Forces:17
                                    double[] diam1, double[] diam2,  // > Propio.Forces:18
                                    double[] velx,  double[] vely,  // > Propio.Forces:19
                                    boolean bIsX)  // > Propio.Forces:20
  {  // > Propio.Forces:21
        // > Propio.Forces:22
      double[] pos_interval = new double[n];  // > Propio.Forces:23
      // > Propio.Forces:24
      double fuerza= 0.0;  // > Propio.Forces:25
      //Array every particle if there is more than one  // > Propio.Forces:26
      if (n>1)  // > Propio.Forces:27
      {  // > Propio.Forces:28
        for (int i=0; i<n; i++)  // > Propio.Forces:29
        {    // > Propio.Forces:30
          if (i==part) continue; //Not using this particle  // > Propio.Forces:31
                // > Propio.Forces:32
          if (this.bUseDiskForce)  // > Propio.Forces:33
          {       // > Propio.Forces:34
            if (isCollision( posx[i],posy[i], posx[part], posy[part],true))  // > Propio.Forces:35
            {  // > Propio.Forces:36
                 // > Propio.Forces:37
               if (bIsX) pos_interval[i] = posx[part]-posx[i];  // > Propio.Forces:38
               else pos_interval[i] = posy[part]-posy[i];  // > Propio.Forces:39
                 // > Propio.Forces:40
               if (this.bUseExclusionForce)  // > Propio.Forces:41
                 fuerza += exclusionVolumeForce(posx[i],posy[i], posx[part], posy[part], diam2[part])*pos_interval[i];  // > Propio.Forces:42
               else if (this.bUseHSn12)    // > Propio.Forces:43
                 fuerza += forceHSn12(posx[i],posy[i], posx[part], posy[part])*pos_interval[i];  // > Propio.Forces:44
               else if (this.bUseHSn36)  // > Propio.Forces:45
                 fuerza += forceHSn36(posx[i],posy[i], posx[part], posy[part])*pos_interval[i];  // > Propio.Forces:46
               else if (this.bUseHSHeyes)   // > Propio.Forces:47
                 fuerza += forceHSHeyes(posx[i],posy[i], posx[part], posy[part])*pos_interval[i];  // > Propio.Forces:48
            }  // > Propio.Forces:49
          // > Propio.Forces:50
          }  // > Propio.Forces:51
          if (bAOmodel)  // > Propio.Forces:52
            if (useAtracForces(posx[i],posy[i],posx[part], posy[part]))  // > Propio.Forces:53
               //These forces have to be divided by chi  // > Propio.Forces:54
              fuerza+=forceModelAO(posx[i],posy[i],posx[part], posy[part], bIsX)/this.chi;  // > Propio.Forces:55
            // > Propio.Forces:56
          if (this.bUseElecAtracPot)  // > Propio.Forces:57
            if (useAtracForces(posx[i],posy[i],posx[part], posy[part]))  // > Propio.Forces:58
              //These forces have to be divided by chi  // > Propio.Forces:59
              fuerza+=forceElecAtrac(posx[i],posy[i],posx[part], posy[part], bIsX)/this.chi;  // > Propio.Forces:60
         // > Propio.Forces:61
        }//for  // > Propio.Forces:62
      }//if  // > Propio.Forces:63
      // > Propio.Forces:64
      //BROWNIAN FORCE  // > Propio.Forces:65
      fuerza +=  brownianForce(bIsX);  // > Propio.Forces:66
            // > Propio.Forces:67
      //OPTICAL TRAP  // > Propio.Forces:68
      if ((n>0) && this.bUseOpticalForce)  // > Propio.Forces:69
        if (bIsX)  // > Propio.Forces:70
          fuerza += opticalForce(posx[part],this.x_0[part], k_optics_x);  // > Propio.Forces:71
        else   // > Propio.Forces:72
          fuerza += opticalForce(posy[part],this.y_0[part], k_optics_y);  // > Propio.Forces:73
            // > Propio.Forces:74
      //FORCES FROM WALLS  // > Propio.Forces:75
      if ((this.bUseWallForces) && (!this.bUseCyclicContour))  // > Propio.Forces:76
          fuerza +=  forceWall(diam1[part], posx[part], posy[part],velx[part], vely[part], bIsX);  // > Propio.Forces:77
        // > Propio.Forces:78
      //IMPORTANT:  // > Propio.Forces:79
      if (bIsX)  // > Propio.Forces:80
        this.vx[part]=fuerza;  // > Propio.Forces:81
      else   // > Propio.Forces:82
        this.vy[part]=fuerza;  // > Propio.Forces:83
       // > Propio.Forces:84
      return fuerza;  // > Propio.Forces:85
  }  // > Propio.Forces:86

  /**  // > Propio.Hard Disk:1
    Says if there is a collision between two disks with coordinates (a1,b1) (a2,b2)  // > Propio.Hard Disk:2
  */  // > Propio.Hard Disk:3
  public boolean isCollision( double a1,  double b1,  // > Propio.Hard Disk:4
                              double a2,  double b2,  // > Propio.Hard Disk:5
                              boolean bUsoDoubleminvalue)  // > Propio.Hard Disk:6
  {  // > Propio.Hard Disk:7
      boolean colision = false;  // > Propio.Hard Disk:8
      double dx=a2-a1, dy=b2-b1, dm=2.0*this.a;  // > Propio.Hard Disk:9
      double r = Math.sqrt(dx*dx+dy*dy);  // > Propio.Hard Disk:10
      double dcuad=r-dm;  // > Propio.Hard Disk:11
      //Tolerance value in the contact  // > Propio.Hard Disk:12
      double tol = this.TOLERANCE;  // > Propio.Hard Disk:13
      if (!bUsoDoubleminvalue)  // > Propio.Hard Disk:14
        tol= 2.0*Math.sqrt(this.dt*D);  // > Propio.Hard Disk:15
          // > Propio.Hard Disk:16
      if (dcuad<=tol)  // > Propio.Hard Disk:17
        colision = true;  // > Propio.Hard Disk:18
      return colision;  // > Propio.Hard Disk:19
  }  // > Propio.Hard Disk:20
  /**  // > Propio.Hard Disk:21
  The exclusion volume force depends on the temporal step. At least dt = 0.01 s for working.  // > Propio.Hard Disk:22
  */  // > Propio.Hard Disk:23
  public double exclusionVolumeForce(  double a1,  double b1,  // > Propio.Hard Disk:24
                                       double a2,  double b2,  // > Propio.Hard Disk:25
                                       double diam)  // > Propio.Hard Disk:26
  {  // > Propio.Hard Disk:27
        // > Propio.Hard Disk:28
      double r2 =(a2-a1)*(a2-a1)+(b2-b1)*(b2-b1);  // > Propio.Hard Disk:29
      double r =Math.sqrt(r2);  // > Propio.Hard Disk:30
      double f = 0.0;  // > Propio.Hard Disk:31
      double f_exc_num1 = Math.exp(-B*(r/(2*a)-1));  // > Propio.Hard Disk:32
      double f_exc_num = A*cte_f_exclusion*f_exc_num1;  // > Propio.Hard Disk:33
      double f_exc_den= Math.max(Math.pow(r,1),Double.MIN_VALUE);  // > Propio.Hard Disk:34
      f = f_exc_num/f_exc_den;  // > Propio.Hard Disk:35
      return f;  // > Propio.Hard Disk:36
        // > Propio.Hard Disk:37
  }  // > Propio.Hard Disk:38
  public double forceHSn12(  double a1,  double b1,  // > Propio.Hard Disk:39
                             double a2,  double b2)  // > Propio.Hard Disk:40
  {  // > Propio.Hard Disk:41
         // > Propio.Hard Disk:42
      double r2 =(a2-a1)*(a2-a1)+(b2-b1)*(b2-b1);  // > Propio.Hard Disk:43
      double r =Math.sqrt(r2);  // > Propio.Hard Disk:44
      double A = this.cteAHSn12;  // > Propio.Hard Disk:45
      double fu = +12*A*K_B*T*Math.pow(2.0*a,12);  // > Propio.Hard Disk:46
      double fd = Math.max(Math.pow(r2,7),Double.MIN_VALUE);  // > Propio.Hard Disk:47
      return fu/fd;  // > Propio.Hard Disk:48
        // > Propio.Hard Disk:49
  }  // > Propio.Hard Disk:50
  public double forceHSn36(   double a1,  double b1,  // > Propio.Hard Disk:51
                              double a2,  double b2)  // > Propio.Hard Disk:52
  {  // > Propio.Hard Disk:53
        // > Propio.Hard Disk:54
      double r2 =(a2-a1)*(a2-a1)+(b2-b1)*(b2-b1);  // > Propio.Hard Disk:55
      double r =Math.sqrt(r2);  // > Propio.Hard Disk:56
      double A = this.cteAHSn36;  // > Propio.Hard Disk:57
      double fu = +36*A*K_B*T*Math.pow(2.0*a,36);  // > Propio.Hard Disk:58
      double fd = Math.max(Math.pow(r2,19),Double.MIN_VALUE);  // > Propio.Hard Disk:59
      return fu/fd;  // > Propio.Hard Disk:60
        // > Propio.Hard Disk:61
  }  // > Propio.Hard Disk:62
  public double forceHSHeyes(   double a1,  double b1,  // > Propio.Hard Disk:63
                                double a2,  double b2)  // > Propio.Hard Disk:64
  {  // > Propio.Hard Disk:65
      // > Propio.Hard Disk:66
      double r2 =(a2-a1)*(a2-a1)+(b2-b1)*(b2-b1);  // > Propio.Hard Disk:67
      double r =Math.sqrt(r2);  // > Propio.Hard Disk:68
      double k = this.ctekHSHeyes;  // > Propio.Hard Disk:69
      double fu = -(r-(2.0*this.a));  // > Propio.Hard Disk:70
      double fd = Math.max(r,Double.MIN_VALUE);  // > Propio.Hard Disk:71
      return k*fu/fd;  // > Propio.Hard Disk:72
        // > Propio.Hard Disk:73
  }  // > Propio.Hard Disk:74

  /**  // > Propio.Walls:1
  Decides if there is a collision with the walls  // > Propio.Walls:2
  */  // > Propio.Walls:3
  public boolean isCollisionWithWall(  double a1,  double b1,  // > Propio.Walls:4
                                       double vx1, double vy1,  // > Propio.Walls:5
                                       double diam)  // > Propio.Walls:6
  {  // > Propio.Walls:7
      boolean choquePared = false;  // > Propio.Walls:8
        // > Propio.Walls:9
      double r = diam/2.0;  // > Propio.Walls:10
        // > Propio.Walls:11
      double d = b1-this.ymin-r;  // > Propio.Walls:12
      if (vy1<0 && d<0) choquePared=true;  // > Propio.Walls:13
        // > Propio.Walls:14
      d = this.ymax-r-b1;  // > Propio.Walls:15
      if (vy1>0 && d<0) choquePared=true;  // > Propio.Walls:16
        // > Propio.Walls:17
      d = a1-this.xmin-r;  // > Propio.Walls:18
      if (vx1<0 && d<0) choquePared=true;  // > Propio.Walls:19
        // > Propio.Walls:20
      d = this.xmax-r-a1;  // > Propio.Walls:21
      if (vx1>0 && d<0)  choquePared=true;  // > Propio.Walls:22
        // > Propio.Walls:23
      return choquePared;  // > Propio.Walls:24
  }  // > Propio.Walls:25
  /**  // > Propio.Walls:26
  Applies the cyclic contour conditions and the disks appear in the opposite wall.  // > Propio.Walls:27
  */  // > Propio.Walls:28
  synchronized public void cyclicContour(int part)  // > Propio.Walls:29
  {  // > Propio.Walls:30
     //diam_reduction is a factor for detecting the wall after crossing it  // > Propio.Walls:31
      //It can be useful for cyclic wall  // > Propio.Walls:32
     double aeff = this.a*(1-this.diam_reduction);  // > Propio.Walls:33
       // > Propio.Walls:34
     double L2 = this.xmax-this.xmin;  // > Propio.Walls:35
     double L = Math.abs(this.xmax);  // > Propio.Walls:36
       // > Propio.Walls:37
       // > Propio.Walls:38
     if(this.x[part]>(L-aeff)) {this.x[part]-=(L2-2*aeff);}  // > Propio.Walls:39
      else if(this.x[part]<(-L+aeff)) this.x[part]+=(L2-2*aeff);  // > Propio.Walls:40
     if(this.y[part]>(L-aeff)) this.y[part]-=(L2-2*aeff);  // > Propio.Walls:41
      else if(this.y[part]<(-L+aeff)) this.y[part]+=(L2-2*aeff);  // > Propio.Walls:42
       // > Propio.Walls:43
        // > Propio.Walls:44
  }  // > Propio.Walls:45
  /**  // > Propio.Walls:46
  Forces from the walls. Probably not enough if disk's velocity is high.  // > Propio.Walls:47
  */  // > Propio.Walls:48
  public double forceWall(  double diam,  // > Propio.Walls:49
                            double posx,  double posy,  // > Propio.Walls:50
                            double velx,  double vely,  // > Propio.Walls:51
                            boolean bIsX)  // > Propio.Walls:52
  {  // > Propio.Walls:53
    double fuerzaPared=0;  // > Propio.Walls:54
    double cte_velocidad = 0.1*Math.sqrt(this.D/this.dt);  // > Propio.Walls:55
    double absvel = 0.0;  // > Propio.Walls:56
    if (bIsX)  // > Propio.Walls:57
      absvel =  Math.abs(velx);  // > Propio.Walls:58
    else  // > Propio.Walls:59
      absvel =  Math.abs(vely);  // > Propio.Walls:60
        // > Propio.Walls:61
    if (isCollisionWithWall(posx, posy, velx, vely ,diam))  // > Propio.Walls:62
    {  // > Propio.Walls:63
      if (bIsX)  fuerzaPared=-ep*velx;  // > Propio.Walls:64
      else fuerzaPared=-ep*vely;  // > Propio.Walls:65
      if (absvel<cte_velocidad) fuerzaPared=0.0;  // > Propio.Walls:66
    }  // > Propio.Walls:67
    return fuerzaPared;  // > Propio.Walls:68
  }  // > Propio.Walls:69
     // > Propio.Walls:70
  /**  // > Propio.Walls:71
  Decides if the disk is inside the box defined by the walls  // > Propio.Walls:72
  */  // > Propio.Walls:73
  public boolean isInsideBox(double x, double y)  // > Propio.Walls:74
  {  // > Propio.Walls:75
     double extra = this.a;  // > Propio.Walls:76
     boolean b1 = Math.abs(x)<=(Math.abs(this.xmax)+extra);  // > Propio.Walls:77
     boolean b2 = Math.abs(y)<=(Math.abs(this.ymax)+extra);  // > Propio.Walls:78
     return (b1 && b2);  // > Propio.Walls:79
       // > Propio.Walls:80
  }  // > Propio.Walls:81

  /**  // > Propio.Other forces:1
  Electrostractic attractive force.  // > Propio.Other forces:2
  */  // > Propio.Other forces:3
  public double forceElecAtrac(  double x1,  double y1,   // > Propio.Other forces:4
                                 double x2,  double y2,   // > Propio.Other forces:5
                                 boolean esX)  // > Propio.Other forces:6
  {  // > Propio.Other forces:7
      double x = x2-x1, y=y2-y1;  // > Propio.Other forces:8
      double r2 =x*x+y*y;  // > Propio.Other forces:9
      double r = Math.sqrt(r2);  // > Propio.Other forces:10
        // > Propio.Other forces:11
      double Z = this.Zelec;  // > Propio.Other forces:12
      double Kinv =this.kappainvelec/f_p;  // > Propio.Other forces:13
      double K = 1.0/Kinv;  // > Propio.Other forces:14
      //lambda expressed in nm, then meters and then microns  // > Propio.Other forces:15
      double lambda = (this.lambdaelec*1e-9)/(f_p*microns);  // > Propio.Other forces:16
      double q = this.qelec;  // > Propio.Other forces:17
      double a = this.a;  // > Propio.Other forces:18
        // > Propio.Other forces:19
      double fuerza = 0.0;  // > Propio.Other forces:20
        // > Propio.Other forces:21
      if (r>(2*a))  // > Propio.Other forces:22
      {  // > Propio.Other forces:23
        if (esX)  // > Propio.Other forces:24
          fuerza = Z * Z * lambda * Math.pow(Math.exp(K * a), 0.2e1) * Math.pow(0.1e1 + K * a, -0.2e1) * K / (x * x + y * y) * x / Math.exp(K * Math.sqrt(x * x + y * y)) + Z * Z * lambda * Math.pow(Math.exp(K * a), 0.2e1) * Math.pow(0.1e1 + K * a, -0.2e1) / Math.exp(K * Math.sqrt(x * x + y * y)) * Math.pow(x * x + y * y, -0.3e1 / 0.2e1) * x - 0.2e1 * Z * lambda * Math.exp(K * a) / (0.1e1 + K * a) * q * K / (x * x + y * y) * x * Math.exp(-K * Math.sqrt(x * x + y * y) / 0.2e1) - 0.4e1 * Z * lambda * Math.exp(K * a) / (0.1e1 + K * a) * q * Math.exp(-K * Math.sqrt(x * x + y * y) / 0.2e1) * Math.pow(x * x + y * y, -0.3e1 / 0.2e1) * x;  // > Propio.Other forces:25
        else   // > Propio.Other forces:26
          fuerza = Z * Z * lambda * Math.pow(Math.exp(K * a), 0.2e1) * Math.pow(0.1e1 + K * a, -0.2e1) * K / (x * x + y * y) * y / Math.exp(K * Math.sqrt(x * x + y * y)) + Z * Z * lambda * Math.pow(Math.exp(K * a), 0.2e1) * Math.pow(0.1e1 + K * a, -0.2e1) / Math.exp(K * Math.sqrt(x * x + y * y)) * Math.pow(x * x + y * y, -0.3e1 / 0.2e1) * y - 0.2e1 * Z * lambda * Math.exp(K * a) / (0.1e1 + K * a) * q * K / (x * x + y * y) * y * Math.exp(-K * Math.sqrt(x * x + y * y) / 0.2e1) - 0.4e1 * Z * lambda * Math.exp(K * a) / (0.1e1 + K * a) * q * Math.exp(-K * Math.sqrt(x * x + y * y) / 0.2e1) * Math.pow(x * x + y * y, -0.3e1 / 0.2e1) * y;  // > Propio.Other forces:27
      }  // > Propio.Other forces:28
      return this.K_B*this.T*fuerza;  // > Propio.Other forces:29
  }  // > Propio.Other forces:30
  /**  // > Propio.Other forces:31
  Method to limit the number of disks used in the attractive potentials.   // > Propio.Other forces:32
  No sense to apply the potential to every particle.  // > Propio.Other forces:33
  It is only applied to particles inside a radius of 10 diameters.  // > Propio.Other forces:34
  */  // > Propio.Other forces:35
  public boolean useAtracForces(  double x1,  double y1,   // > Propio.Other forces:36
                                  double x2,  double y2)  // > Propio.Other forces:37
  {  // > Propio.Other forces:38
       // > Propio.Other forces:39
      double r = twoParticlesDistance(x1,y1,x2,y2);  // > Propio.Other forces:40
      double sigma = 2*this.a;  // > Propio.Other forces:41
      //To meters and then to microns  // > Propio.Other forces:42
      double rg = (this.Rg*1e-9)/(f_p*microns);  // > Propio.Other forces:43
      boolean condicion = (r<=(10*sigma));  // > Propio.Other forces:44
      return condicion;  // > Propio.Other forces:45
  }  // > Propio.Other forces:46
  public double twoParticlesDistance(  double x1,  double y1,   // > Propio.Other forces:47
                                       double x2,  double y2)  // > Propio.Other forces:48
  {  // > Propio.Other forces:49
       // > Propio.Other forces:50
      double Dx = x2-x1, Dy=y2-y1;  // > Propio.Other forces:51
      double r2 =Dx*Dx+Dy*Dy;  // > Propio.Other forces:52
      double r = Math.sqrt(r2);  // > Propio.Other forces:53
      return r;  // > Propio.Other forces:54
  }  // > Propio.Other forces:55
     // > Propio.Other forces:56
      // > Propio.Other forces:57
  public double forceModelAO(  double x1,  double y1,  // > Propio.Other forces:58
                               double x2,  double y2,   // > Propio.Other forces:59
                               boolean bIsX)  // > Propio.Other forces:60
  {  // > Propio.Other forces:61
            // > Propio.Other forces:62
      double fuerza = 0.0;  // > Propio.Other forces:63
      double Dx = x2-x1, Dy=y2-y1;  // > Propio.Other forces:64
      double r2 =Dx*Dx+Dy*Dy;  // > Propio.Other forces:65
      double r = Math.sqrt(r2);  // > Propio.Other forces:66
      double sigma = 2*this.a;  // > Propio.Other forces:67
        // > Propio.Other forces:68
      double rg = (this.Rg*1e-9)/(f_p*microns);  // > Propio.Other forces:69
            // > Propio.Other forces:70
      boolean condicion1 = (r>=(sigma+this.TOLERANCE));  // > Propio.Other forces:71
      boolean condicion2 = (r<=(sigma+2.0*rg));  // > Propio.Other forces:72
      if (condicion1 && condicion2)  // > Propio.Other forces:73
      {  // > Propio.Other forces:74
        //Units of microns^-3 -> Converted to ejs units with fp:  // > Propio.Other forces:75
        double np = (this.cteAOennp)*(Math.pow(f_p,3.0));  // > Propio.Other forces:76
        double A = np*K_B*T*(4*Math.PI/3.0)*(rg*rg*rg);  // > Propio.Other forces:77
        double lam = (2.0*rg/sigma)+1.0;  // > Propio.Other forces:78
        double rden = Math.pow((lam-1),3)*sigma*sigma*sigma*r;  // > Propio.Other forces:79
          // > Propio.Other forces:80
        //For rg=0.5 um, np=0.5 um^3, is obtained A/KT=0.262  // > Propio.Other forces:81
        fuerza = +A*1.5*(r2-sigma*sigma*lam*lam)/rden;  // > Propio.Other forces:82
        if (bIsX) fuerza = fuerza*Dx;  // > Propio.Other forces:83
        else fuerza = fuerza*Dy;  // > Propio.Other forces:84
          // > Propio.Other forces:85
      }  // > Propio.Other forces:86
      return fuerza;  // > Propio.Other forces:87
  }  // > Propio.Other forces:88
  /**  // > Propio.Other forces:89
  Brownian force. No need to divide by chi, it is included in the terms.  // > Propio.Other forces:90
  */  // > Propio.Other forces:91
  public double brownianForce(  boolean bIsX)  // > Propio.Other forces:92
  {  // > Propio.Other forces:93
      double random_a = Math.random();  // > Propio.Other forces:94
      double random_b = Math.random();  // > Propio.Other forces:95
      double c = 1;  // > Propio.Other forces:96
      double c0 = 1;  // > Propio.Other forces:97
      double PI2 = 2.0*3.141592;  // > Propio.Other forces:98
        // > Propio.Other forces:99
      double dBrownian = 0.0;  // > Propio.Other forces:100
      if (bIsX)  // > Propio.Other forces:101
        dBrownian=c0*Math.sqrt(-2*Math.log(random_a))*Math.cos(PI2*random_b);  // > Propio.Other forces:102
      else   // > Propio.Other forces:103
        dBrownian=c0*Math.sqrt(-2*Math.log(random_a))*Math.sin(PI2*random_b);  // > Propio.Other forces:104
        // > Propio.Other forces:105
      double fuerzaBrownian = cte_diffusion*dBrownian;   // > Propio.Other forces:106
      return fuerzaBrownian;  // > Propio.Other forces:107
  }  // > Propio.Other forces:108
  /**  // > Propio.Other forces:109
  Optical force it is needed to be divided by chi.  // > Propio.Other forces:110
  chi is in the order of 10^-8 and no depends of m, and therefore does not depend on calibration.  // > Propio.Other forces:111
  With the trap stifness k is the same since N/m = (kg m /s^2)/m = kg/s^2  // > Propio.Other forces:112
  As a result the optical force is higher than in experiments.   // > Propio.Other forces:113
  This is because the influence of gravity in the experiments.  // > Propio.Other forces:114
  The initial value pos0 is used to center the trap.  // > Propio.Other forces:115
  */  // > Propio.Other forces:116
  public double opticalForce(  double pos,   // > Propio.Other forces:117
                               double pos0,   // > Propio.Other forces:118
                               double k)  // > Propio.Other forces:119
  {  // > Propio.Other forces:120
      double kc = k*this.microns;   // > Propio.Other forces:121
      double fuerza = -kc*(pos-pos0)/this.chi;  // > Propio.Other forces:122
      return fuerza;  // > Propio.Other forces:123
  }  // > Propio.Other forces:124
  /**  // > Propio.Other forces:125
  Method to provide a random value multiplied by factor  // > Propio.Other forces:126
  */  // > Propio.Other forces:127
  public double randomValue(double factor)  // > Propio.Other forces:128
  {  // > Propio.Other forces:129
    double x = Math.random();  // > Propio.Other forces:130
    double y = 0;  // > Propio.Other forces:131
    if (x<0.5) y = -factor*x;  // > Propio.Other forces:132
    else y = factor*x;  // > Propio.Other forces:133
    return y;  // > Propio.Other forces:134
   }  // > Propio.Other forces:135
     // > Propio.Other forces:136

  /**  // > Propio.Stats:1
  Returns the full width at half maximum (FWHM) of a histogram.  // > Propio.Stats:2
  */  // > Propio.Stats:3
  public double getFWHM(double[] x, double[] y)  // > Propio.Stats:4
  {  // > Propio.Stats:5
    double max =  getMaxValueArray(y);  // > Propio.Stats:6
    double maxdiv2 = max/2.0;  // > Propio.Stats:7
    int i = 0;  // > Propio.Stats:8
    while (y[i]<maxdiv2)  // > Propio.Stats:9
      i++;  // > Propio.Stats:10
    return -2*x[i];  // > Propio.Stats:11
      // > Propio.Stats:12
  }  // > Propio.Stats:13
  /**  // > Propio.Stats:14
  Gives the diffusion coefficient from the FWHM from a histogram of position's jumps.  // > Propio.Stats:15
  */  // > Propio.Stats:16
  public double[] getDifCoeffGaussian()  // > Propio.Stats:17
  {  // > Propio.Stats:18
     double[] diff = new double[2];  // > Propio.Stats:19
     double dFWHMx = getFWHM(this.freqHistoJumps, this.countHistoJumpsX);  // > Propio.Stats:20
     double dFWHMy = getFWHM(this.freqHistoJumps, this.countHistoJumpsY);  // > Propio.Stats:21
     double sigmax = dFWHMx/2.355;  // > Propio.Stats:22
     double sigmay = dFWHMy/2.355;  // > Propio.Stats:23
     diff[0] = sigmax*sigmax/(2*this.dt);  // > Propio.Stats:24
     diff[1] = sigmay*sigmay/(2*this.dt);  // > Propio.Stats:25
     return diff;   // > Propio.Stats:26
      // > Propio.Stats:27
  }  // > Propio.Stats:28
  /**  // > Propio.Stats:29
  Gives the trap stiffness from the FWHM from a histogram of x and y positions  // > Propio.Stats:30
  if the optical trap is connected.  // > Propio.Stats:31
  */  // > Propio.Stats:32
  public double[] getKGaussian()  // > Propio.Stats:33
  {  // > Propio.Stats:34
     double[] kopt = new double[2];  // > Propio.Stats:35
     double dFWHMx = getFWHM(this.freqHistoOptPot, this.countHistoOptPotX);  // > Propio.Stats:36
     double dFWHMy = getFWHM(this.freqHistoOptPot, this.countHistoOptPotY);  // > Propio.Stats:37
     double sigmax = dFWHMx/2.355;  // > Propio.Stats:38
     double sigmay = dFWHMy/2.355;  // > Propio.Stats:39
     kopt[0] = K_B*T/(sigmax*sigmax);  // > Propio.Stats:40
     kopt[1] = K_B*T/(sigmay*sigmay);  // > Propio.Stats:41
     return kopt;   // > Propio.Stats:42
      // > Propio.Stats:43
  }  // > Propio.Stats:44
  public double getMaxValueArray(double[] a)  // > Propio.Stats:45
  {  // > Propio.Stats:46
     DoubleSummaryStatistics stat = Arrays.stream(a).summaryStatistics();  // > Propio.Stats:47
     return stat.getMax();    // > Propio.Stats:48
  }  // > Propio.Stats:49
  public double getMinValueArray(double[] a)  // > Propio.Stats:50
  {  // > Propio.Stats:51
     DoubleSummaryStatistics stat = Arrays.stream(a).summaryStatistics();  // > Propio.Stats:52
     return stat.getMin();    // > Propio.Stats:53
  }  // > Propio.Stats:54

  /**  // > Propio.Write txt:1
  Writing disks positions in txt file.  // > Propio.Write txt:2
  Gives issues with more than 10⁶ lines.  // > Propio.Write txt:3
  Method to open the file to save disks positions.  // > Propio.Write txt:4
  bAddInfo=true add info in the file  // > Propio.Write txt:5
  **/  // > Propio.Write txt:6
  public void writeDataOnTextFile(boolean bAddInfo)  // > Propio.Write txt:7
  {  // > Propio.Write txt:8
      String nombreArchivo=this.sFileName+".txt";  // > Propio.Write txt:9
      String saveDirectory= this.sDirectoryName;   // > Propio.Write txt:10
      String nombreArchivoGrabar = saveDirectory+nombreArchivo;  // > Propio.Write txt:11
      java.io.FileWriter fwOut = null;  // > Propio.Write txt:12
      java.io.PrintWriter pwPrint = null;  // > Propio.Write txt:13
           // > Propio.Write txt:14
      //OPen file  // > Propio.Write txt:15
      try  // > Propio.Write txt:16
      {  // > Propio.Write txt:17
        System.out.println(this.MSG_OPEN_FILE);   // > Propio.Write txt:18
        if (bAddInfo)  // > Propio.Write txt:19
          fwOut=new java.io.FileWriter(nombreArchivoGrabar,bAddInfo);  // > Propio.Write txt:20
        else     // > Propio.Write txt:21
          fwOut=new java.io.FileWriter(nombreArchivoGrabar);  // > Propio.Write txt:22
        // > Propio.Write txt:23
        pwPrint = new java.io.PrintWriter((java.io.FileWriter)fwOut);  // > Propio.Write txt:24
        // > Propio.Write txt:25
      } catch (IOException e) {e.printStackTrace();}  // > Propio.Write txt:26
     // > Propio.Write txt:27
      //Obtaining string data and writting   // > Propio.Write txt:28
      StringBuilder str = new StringBuilder();   // > Propio.Write txt:29
      String sarray = "";  // > Propio.Write txt:30
      //Size of the list  // > Propio.Write txt:31
      int n = ((java.util.ArrayList)this.arraylist_Strings).size();  // > Propio.Write txt:32
      // > Propio.Write txt:33
      //Data from arrayList (if not empty) into the file  // > Propio.Write txt:34
      if (!((java.util.ArrayList)this.arraylist_Strings).isEmpty())  // > Propio.Write txt:35
      {  // > Propio.Write txt:36
        int i = 0;  // > Propio.Write txt:37
        while(i<(n-1))  // > Propio.Write txt:38
        {    // > Propio.Write txt:39
            sarray = (String)((java.util.ArrayList)this.arraylist_Strings).get(i);  // > Propio.Write txt:40
            str.append(sarray+"\n");  // > Propio.Write txt:41
            i++;  // > Propio.Write txt:42
        }  // > Propio.Write txt:43
        //Last line.  // > Propio.Write txt:44
        sarray = (String)((java.util.ArrayList)this.arraylist_Strings).get(i);  // > Propio.Write txt:45
        str.append(sarray);  // > Propio.Write txt:46
            // > Propio.Write txt:47
        //Writing to the file  // > Propio.Write txt:48
        ((java.io.PrintWriter)pwPrint).println(str.toString());  // > Propio.Write txt:49
        System.out.println(this.MSG_WRITE_FILE);       // > Propio.Write txt:50
      }  // > Propio.Write txt:51
      else  // > Propio.Write txt:52
        System.out.println(this.MSG_WRITE_FILE_ERROR);  // > Propio.Write txt:53
        // > Propio.Write txt:54
      //Close file  // > Propio.Write txt:55
      try  // > Propio.Write txt:56
      {  // > Propio.Write txt:57
        ((java.io.FileWriter)fwOut).close();  // > Propio.Write txt:58
      }catch (IOException e) {e.printStackTrace();}  // > Propio.Write txt:59
        // > Propio.Write txt:60
      //Clean arrayList   // > Propio.Write txt:61
      ((ArrayList)arraylist_Strings).clear();  // > Propio.Write txt:62
      System.out.println(this.MSG_CLOSE_FILE);  // > Propio.Write txt:63
     // > Propio.Write txt:64
  }  // > Propio.Write txt:65
  public void writeLastStepOnTextFile()  // > Propio.Write txt:66
  {  // > Propio.Write txt:67
    String nombreArchivo= "last_step_"+this.sFileName+".txt";  // > Propio.Write txt:68
    String saveDirectory= this.sDirectoryName;  // > Propio.Write txt:69
    String nombreArchivoGrabar = saveDirectory+nombreArchivo;  // > Propio.Write txt:70
      // > Propio.Write txt:71
    //Last data  // > Propio.Write txt:72
    String data = "";  // > Propio.Write txt:73
    boolean init1 = (this.t==dt);  // > Propio.Write txt:74
    boolean init2 = ((this.textra!=0.0) && (this.t==this.textra));  // > Propio.Write txt:75
    //If header not already written in getStringData  // > Propio.Write txt:76
    if (!(init1 || init2))  // > Propio.Write txt:77
    {  // > Propio.Write txt:78
      data = this.cabeceraEstadisticas;  // > Propio.Write txt:79
      if (this.bIncludeLabelDisk)  // > Propio.Write txt:80
         data = data + "\t"+this.sLabel;  // > Propio.Write txt:81
      data = data + "\n";  // > Propio.Write txt:82
    }  // > Propio.Write txt:83
    data = data +  getStringData(this.count_images_total,(t), this.dt, this.x, this.y);    // > Propio.Write txt:84
      // > Propio.Write txt:85
    try {  // > Propio.Write txt:86
        FileWriter salida=new FileWriter(nombreArchivoGrabar);  // > Propio.Write txt:87
        PrintWriter print = new PrintWriter(salida);  // > Propio.Write txt:88
        print.println(data);  // > Propio.Write txt:89
        salida.close();  // > Propio.Write txt:90
        System.out.println(this.MSG_WRITE_INPUT_FILE+nombreArchivoGrabar);  // > Propio.Write txt:91
  	  // > Propio.Write txt:92
        } catch (IOException e) {e.printStackTrace();}  // > Propio.Write txt:93
      // > Propio.Write txt:94
  }  // > Propio.Write txt:95
  /**  // > Propio.Write txt:96
  Method to generate and save a file with the input data.  // > Propio.Write txt:97
  */  // > Propio.Write txt:98
  public void writeInputOnTextFile()  // > Propio.Write txt:99
  {  // > Propio.Write txt:100
    this.sInputFileName =  "input_"+this.sFileName+".txt";  // > Propio.Write txt:101
    String nombreArchivo=this.sInputFileName;  // > Propio.Write txt:102
    String saveDirectory= this.sDirectoryName;  // > Propio.Write txt:103
    String nombreArchivoGrabar = saveDirectory+nombreArchivo;  // > Propio.Write txt:104
      // > Propio.Write txt:105
    String datos =  // > Propio.Write txt:106
                this.TEXT_INPUT_FILE+"\t"+this.sFileName+"\n"+  // > Propio.Write txt:107
                this.TEXT_INPUT_TIMETOTAL+"\t"+this.tmax+"\n"+  // > Propio.Write txt:108
                this.TEXT_INPUT_DT+"\t"+this.dt+"\n";  // > Propio.Write txt:109
      // > Propio.Write txt:110
    String datossigue =  // > Propio.Write txt:111
                this.TEXT_INPUT_SEP+"\n"+  // > Propio.Write txt:112
                this.TEXT_INPUT_N+"\t"+this.n +"\n"+  // > Propio.Write txt:113
                this.TEXT_INPUT_RDIAM+"\t"+(float)this.d_real +"\n"+  // > Propio.Write txt:114
                this.TEXT_INPUT_DIAM+"\t"+(float)this.diameter_c +"\n"+  // > Propio.Write txt:115
                this.TEXT_INPUT_CAL+"\t"+(float)this.f_p+"\n"+  // > Propio.Write txt:116
                this.TEXT_INPUT_CONC+"\t"+(float)this.phi_2D+"\n"+  // > Propio.Write txt:117
                this.TEXT_INPUT_T+"\t"+(float)this.T+"\n"+  // > Propio.Write txt:118
                //Visco line 10  // > Propio.Write txt:119
                this.TEXT_INPUT_VISCO+"\t"+(float)this.eta0+"\n"+  // > Propio.Write txt:120
                this.TEXT_INPUT_DIFF+"\t"+(float)this.D +"\n"+  // > Propio.Write txt:121
                this.TEXT_INPUT_RDIFF+"\t"+(float)this.Dreal +"\n";  // > Propio.Write txt:122
    String datosparedes =  // > Propio.Write txt:123
                this.TEXT_INPUT_SEP+"\n"+  // > Propio.Write txt:124
                //line 14  // > Propio.Write txt:125
                this.TEXT_INPUT_BOUNDARIES+"\t"+this.bUseNoContour +"\n";  // > Propio.Write txt:126
    String datosparedes2 =              // > Propio.Write txt:127
                this.TEXT_INPUT_WALLS+"\t"+this.bUseWallForces +"\n"+  // > Propio.Write txt:128
                this.TEXT_INPUT_CTE+"\t"+(float)this.ep+"\n"+  // > Propio.Write txt:129
                this.TEXT_INPUT_CYCLIC+"\t"+this.bUseCyclicContour +"\n"+   // > Propio.Write txt:130
                this.TEXT_INPUT_CTE+"\t"+(float)this.diam_reduction+"\n";  // > Propio.Write txt:131
    datosparedes = datosparedes+datosparedes2;  // > Propio.Write txt:132
                  // > Propio.Write txt:133
                  // > Propio.Write txt:134
    String datosHS =  // > Propio.Write txt:135
                this.TEXT_INPUT_SEP+"\n"+  // > Propio.Write txt:136
                //line 20  // > Propio.Write txt:137
                this.TEXT_INPUT_DISKFORCE+"\t"+this.bUseDiskForce+"\n"+  // > Propio.Write txt:138
                this.TEXT_INPUT_EXCLUSION+"\t"+this.bUseExclusionForce+"\n"+  // > Propio.Write txt:139
                this.TEXT_INPUT_CTE+"\t"+(float)cte_f_exclusion+"\n"+  // > Propio.Write txt:140
                this.TEXT_INPUT_R12+"\t"+this.bUseHSn12 + "\n"+  // > Propio.Write txt:141
                this.TEXT_INPUT_CTE+"\t"+(float)this.cteAHSn12+"\n"+   // > Propio.Write txt:142
                this.TEXT_INPUT_R36+"\t"+this.bUseHSn36 +"\n"+  // > Propio.Write txt:143
                this.TEXT_INPUT_CTE+"\t"+(float)this.cteAHSn36+"\n"+   // > Propio.Write txt:144
                this.TEXT_INPUT_HEYES+"\t"+this.bUseHSHeyes +"\n"+  // > Propio.Write txt:145
                this.TEXT_INPUT_CTE+"\t"+(float)this.ctekHSHeyes+"\n";  // > Propio.Write txt:146
                  // > Propio.Write txt:147
      // > Propio.Write txt:148
    String datos1 = datos+datossigue+datosparedes+datosHS;  // > Propio.Write txt:149
      // > Propio.Write txt:150
    String datosDt =   // > Propio.Write txt:151
                this.TEXT_INPUT_SEP+"\n"+  // > Propio.Write txt:152
                TEXT_INPUT_DTINTXT+"\t"+this.bDtInTxt+"\n"+  // > Propio.Write txt:153
                this.TEXT_INPUT_DT+(float)this.dtInTxt+"\n";  // > Propio.Write txt:154
      // > Propio.Write txt:155
    String datosAO=  // > Propio.Write txt:156
                this.TEXT_INPUT_SEP+"\n"+  // > Propio.Write txt:157
                this.TEXT_INPUT_AO+"\t"+this.bAOmodel +"\n"+  // > Propio.Write txt:158
                this.TEXT_INPUT_RG+"\t"+(float)this.Rg +"\n"+  // > Propio.Write txt:159
                this.TEXT_INPUT_LONGAOCTE+"\t"+(float)this.cteAOennp +"\n";  // > Propio.Write txt:160
    String datosVelecAtrac=  // > Propio.Write txt:161
                this.TEXT_INPUT_SEP+"\n"+  // > Propio.Write txt:162
                this.TEXT_INPUT_ELECPOT+"\t"+bUseElecAtracPot+"\n"+  // > Propio.Write txt:163
                this.TEXT_INPUT_Z+"\t"+(float)this.Zelec+"\n"+  // > Propio.Write txt:164
                this.TEXT_INPUT_LAMBDA+"\t"+(float)this.lambdaelec+"\n"+  // > Propio.Write txt:165
                this.TEXT_INPUT_KAPPA+"\t"+(float)this.kappainvelec+"\n"+  // > Propio.Write txt:166
                this.TEXT_INPUT_Q+ "\t"+(float)this.qelec+"\n";  // > Propio.Write txt:167
      // > Propio.Write txt:168
      String datosFO =  // > Propio.Write txt:169
                this.TEXT_INPUT_SEP+"\n"+  // > Propio.Write txt:170
                this.TEXT_INPUT_OPTICAL+"\t"+this.bUseOpticalForce +"\n"+   // > Propio.Write txt:171
                this.TEXT_INPUT_KX+"\t"+(float)this.k_optics_x+"\n"+   // > Propio.Write txt:172
                this.TEXT_INPUT_KY+"\t"+(float)this.k_optics_y+"\n";  // > Propio.Write txt:173
    //All together now  // > Propio.Write txt:174
    String datos2=datos1+datosDt+datosAO+datosVelecAtrac+datosFO;  // > Propio.Write txt:175
      // > Propio.Write txt:176
      // > Propio.Write txt:177
    try {  // > Propio.Write txt:178
        FileWriter salida=new FileWriter(nombreArchivoGrabar);  // > Propio.Write txt:179
        PrintWriter print = new PrintWriter(salida);  // > Propio.Write txt:180
        print.println(datos2);  // > Propio.Write txt:181
        salida.close();  // > Propio.Write txt:182
        System.out.println(this.MSG_WRITE_INPUT_FILE+nombreArchivoGrabar);  // > Propio.Write txt:183
  	  // > Propio.Write txt:184
        } catch (IOException e) {e.printStackTrace();}  // > Propio.Write txt:185
  	  // > Propio.Write txt:186
  }  // > Propio.Write txt:187
  /**  // > Propio.Write txt:188
  Returns a string with the particle's data to save.  // > Propio.Write txt:189
  All data is moved to positive values to avoid negative values,   // > Propio.Write txt:190
  which generate issues in some calculations.  // > Propio.Write txt:191
  */  // > Propio.Write txt:192
  public String getStringData(  int numimagen,  // > Propio.Write txt:193
                                double t,  // > Propio.Write txt:194
                                double dtTXT,  // > Propio.Write txt:195
                                double[] posx,    // > Propio.Write txt:196
                                double[] posy)  // > Propio.Write txt:197
  {  // > Propio.Write txt:198
      // > Propio.Write txt:199
       // > Propio.Write txt:200
     int n = posx.length;  // > Propio.Write txt:201
     StringBuffer str = new StringBuffer();  // > Propio.Write txt:202
       // > Propio.Write txt:203
     //For including headers or not        // > Propio.Write txt:204
     boolean init1 = (this.t==dt);  // > Propio.Write txt:205
     boolean init2 = ((this.textra!=0.0) && (this.t==this.textra));  // > Propio.Write txt:206
     String sHeader = "";  // > Propio.Write txt:207
     if (init1 || init2)  // > Propio.Write txt:208
     {  // > Propio.Write txt:209
        if (this.bIncludeLabelDisk)  // > Propio.Write txt:210
           sHeader = this.cabeceraEstadisticas + "\t"+this.sLabel;  // > Propio.Write txt:211
        str.append(sHeader+"\n");    // > Propio.Write txt:212
      }  // > Propio.Write txt:213
       // > Propio.Write txt:214
     for (int i=0; i<n; i++)  // > Propio.Write txt:215
     {  // > Propio.Write txt:216
          double posicionx = posx[i];  // > Propio.Write txt:217
          double posiciony = posy[i];  // > Propio.Write txt:218
     // > Propio.Write txt:219
          double xstring = posicionx;  // > Propio.Write txt:220
          double ystring = posiciony;  // > Propio.Write txt:221
            // > Propio.Write txt:222
          //All data is moved to positive values to avoid negative values, which generate issues in some calculations.  // > Propio.Write txt:223
          //Box is now between 0 and 2  // > Propio.Write txt:224
          if (this.n > 0)  // > Propio.Write txt:225
          {  // > Propio.Write txt:226
             xstring=(posicionx+this.xmax);  // > Propio.Write txt:227
             ystring=(posiciony+this.ymax);  // > Propio.Write txt:228
               // > Propio.Write txt:229
             //Add positions to string  // > Propio.Write txt:230
             str.append((float)xstring+"\t"+(float)ystring);  // > Propio.Write txt:231
               // > Propio.Write txt:232
             //Add time to string  // > Propio.Write txt:233
             str.append("\t"+(float)t);  // > Propio.Write txt:234
               // > Propio.Write txt:235
             //Add label to string  // > Propio.Write txt:236
             str.append("\t"+numimagen);  // > Propio.Write txt:237
               // > Propio.Write txt:238
             //If including the label of each disk  // > Propio.Write txt:239
             if (this.bIncludeLabelDisk)  // > Propio.Write txt:240
               //Last column is the label of the "image" (temporal step)  // > Propio.Write txt:241
               str.append("\t"+(i+1));  // > Propio.Write txt:242
               // > Propio.Write txt:243
             //Jump of line, except for the last  // > Propio.Write txt:244
             if (i<(n-1)) str.append("\n");    // > Propio.Write txt:245
                 // > Propio.Write txt:246
           }  // > Propio.Write txt:247
          // > Propio.Write txt:248
      }  // > Propio.Write txt:249
     return str.toString();  // > Propio.Write txt:250
  }  // > Propio.Write txt:251
  /**  // > Propio.Write txt:252
  Round double value to double  // > Propio.Write txt:253
  */  // > Propio.Write txt:254
  public double round(double d, int decimalPlace)  // > Propio.Write txt:255
  {  // > Propio.Write txt:256
      BigDecimal bd = new BigDecimal(Double.toString(d));  // > Propio.Write txt:257
      bd = bd.setScale(decimalPlace,BigDecimal.ROUND_HALF_UP);  // > Propio.Write txt:258
      return bd.doubleValue();  // > Propio.Write txt:259
  }  // > Propio.Write txt:260
  /**  // > Propio.Write txt:261
  Round double value to float  // > Propio.Write txt:262
  */  // > Propio.Write txt:263
  public float roundfloat(double d, int decimalPlace)  // > Propio.Write txt:264
  {  // > Propio.Write txt:265
      BigDecimal bd = new BigDecimal(Double.toString(d));  // > Propio.Write txt:266
      bd = bd.setScale(decimalPlace,BigDecimal.ROUND_HALF_UP);  // > Propio.Write txt:267
      return bd.floatValue();  // > Propio.Write txt:268
  }  // > Propio.Write txt:269
  /**  // > Propio.Write txt:270
  Choose a directory with a File Chooser.  // > Propio.Write txt:271
  */  // > Propio.Write txt:272
  public String getDirectoryFromDialog()  // > Propio.Write txt:273
  {  // > Propio.Write txt:274
     javax.swing.JFileChooser f = new javax.swing.JFileChooser();  // > Propio.Write txt:275
     f.setFileSelectionMode(JFileChooser.DIRECTORIES_ONLY);   // > Propio.Write txt:276
     f.showSaveDialog(null);  // > Propio.Write txt:277
     String path = f.getSelectedFile().getPath()+File.separator;  // > Propio.Write txt:278
     //System.out.println(path);  // > Propio.Write txt:279
     return path;  // > Propio.Write txt:280
       // > Propio.Write txt:281
  }  // > Propio.Write txt:282
  /**  // > Propio.Write txt:283
  Choose a file with a File Chooser.  // > Propio.Write txt:284
  */  // > Propio.Write txt:285
  public String getFileFromDialog()  // > Propio.Write txt:286
  {  // > Propio.Write txt:287
     javax.swing.JFileChooser f = new javax.swing.JFileChooser();  // > Propio.Write txt:288
     f.setFileSelectionMode(JFileChooser.FILES_ONLY);   // > Propio.Write txt:289
     f.showSaveDialog(null);  // > Propio.Write txt:290
     String name = f.getSelectedFile().getPath();  // > Propio.Write txt:291
     System.out.println(name);  // > Propio.Write txt:292
     return name;  // > Propio.Write txt:293
       // > Propio.Write txt:294
  }  // > Propio.Write txt:295

  /**  // > Propio.Read txt:1
  Reads a text file (complete path needed) and returns  // > Propio.Read txt:2
  an ArrayList with the strings of every line  // > Propio.Read txt:3
  **/  // > Propio.Read txt:4
  public ArrayList readFileAsArrayList(String filename)  // > Propio.Read txt:5
  {  // > Propio.Read txt:6
     ArrayList alData = new ArrayList();  // > Propio.Read txt:7
       // > Propio.Read txt:8
     System.out.println("Reading file: "+filename);     // > Propio.Read txt:9
       // > Propio.Read txt:10
       Scanner sc = new Scanner(System.in);  // > Propio.Read txt:11
         // > Propio.Read txt:12
       try{  // > Propio.Read txt:13
            File file = new File(filename);  // > Propio.Read txt:14
            sc = new Scanner(file);   // > Propio.Read txt:15
            while(sc.hasNextLine())  // > Propio.Read txt:16
            {  // > Propio.Read txt:17
              ((ArrayList)alData).add(sc.nextLine());  // > Propio.Read txt:18
            }  // > Propio.Read txt:19
            sc.close();   // > Propio.Read txt:20
          // > Propio.Read txt:21
        }catch (IOException e)   // > Propio.Read txt:22
        {      // > Propio.Read txt:23
          System.out.println("ERROR READING FILE: "+filename);     // > Propio.Read txt:24
        }   // > Propio.Read txt:25
       // > Propio.Read txt:26
      return alData;  // > Propio.Read txt:27
          // > Propio.Read txt:28
  }  // > Propio.Read txt:29
      // > Propio.Read txt:30
  public ArrayList readInputFile()  // > Propio.Read txt:31
  {      // > Propio.Read txt:32
      this.sReadInputFilePath = this.sReadInputFilePath.replaceAll("\\s","");  // > Propio.Read txt:33
      ArrayList alData = readFileAsArrayList(this.sReadInputFilePath);  // > Propio.Read txt:34
      int numlineas = ((ArrayList)alData).size();  // > Propio.Read txt:35
      System.out.println("Read input file data ("+numlineas+" lines)");  // > Propio.Read txt:36
      return alData;  // > Propio.Read txt:37
  }    // > Propio.Read txt:38
     // > Propio.Read txt:39
  public void putInputDataIntoInputValues()  // > Propio.Read txt:40
  {  // > Propio.Read txt:41
      ArrayList alData = readInputFile();  // > Propio.Read txt:42
      int alsize = alData.size();  // > Propio.Read txt:43
      boolean alEmpty = ((ArrayList)alData).isEmpty();  // > Propio.Read txt:44
      if (!alEmpty)  // > Propio.Read txt:45
      {     // > Propio.Read txt:46
        //READ TIME MAX  // > Propio.Read txt:47
        this.tmax = readFloatDatafromArrayList(alData, 1, this.TEXT_INPUT_TIMETOTAL);  // > Propio.Read txt:48
        // > Propio.Read txt:49
        //READ DT  // > Propio.Read txt:50
        this.dt= readFloatDatafromArrayList(alData, 2, this.TEXT_INPUT_DT);  // > Propio.Read txt:51
        // > Propio.Read txt:52
        //READ number of particles  // > Propio.Read txt:53
        this.n = readIntDatafromArrayList(alData, 4, this.TEXT_INPUT_N);  // > Propio.Read txt:54
        //Neccesary to work because n define the size of the arrays  // > Propio.Read txt:55
        this._initialize();  // > Propio.Read txt:56
        // > Propio.Read txt:57
        //READ real diameter  // > Propio.Read txt:58
        this.d_real = readFloatDatafromArrayList(alData, 5, this.TEXT_INPUT_RDIAM);  // > Propio.Read txt:59
        //READ concentration  // > Propio.Read txt:60
        this.phi_2D = readFloatDatafromArrayList(alData, 8, this.TEXT_INPUT_CONC);  // > Propio.Read txt:61
        //Read Temperature  // > Propio.Read txt:62
        this.T = readFloatDatafromArrayList(alData, 9, this.TEXT_INPUT_T);  // > Propio.Read txt:63
        //Read viscosity  // > Propio.Read txt:64
        this.eta0 = readFloatDatafromArrayList(alData, 10, this.TEXT_INPUT_VISCO);  // > Propio.Read txt:65
        // > Propio.Read txt:66
        //Read wall conditions  // > Propio.Read txt:67
        this.bUseNoContour = readBooleanDatafromArrayList(alData, 14, TEXT_INPUT_BOUNDARIES);  // > Propio.Read txt:68
        //Any wall  // > Propio.Read txt:69
        if (bUseNoContour)  // > Propio.Read txt:70
        {  // > Propio.Read txt:71
          this.bUseWallForces = false;  // > Propio.Read txt:72
          this.bUseCyclicContour = false;  // > Propio.Read txt:73
        }  // > Propio.Read txt:74
        //If walls are used, read values:  // > Propio.Read txt:75
        else  // > Propio.Read txt:76
        {  // > Propio.Read txt:77
         //Walls   // > Propio.Read txt:78
          this.bUseWallForces = readBooleanDatafromArrayList(alData, 15, this.TEXT_INPUT_WALLS);  // > Propio.Read txt:79
          //Read Wall constant  // > Propio.Read txt:80
          this.ep = readFloatDatafromArrayList(alData, 16, this.TEXT_INPUT_CTE);  // > Propio.Read txt:81
         //Cyclic   // > Propio.Read txt:82
          this.bUseCyclicContour = readBooleanDatafromArrayList(alData, 17, this.TEXT_INPUT_CYCLIC);  // > Propio.Read txt:83
          //Read Wall constant  // > Propio.Read txt:84
          this.diam_reduction = readFloatDatafromArrayList(alData, 18, this.TEXT_INPUT_CTE);  // > Propio.Read txt:85
         }   // > Propio.Read txt:86
         // > Propio.Read txt:87
        //Disk forces  // > Propio.Read txt:88
        this.bUseDiskForce = readBooleanDatafromArrayList(alData, 20, this.TEXT_INPUT_DISKFORCE);  // > Propio.Read txt:89
        if (bUseDiskForce)  // > Propio.Read txt:90
        {  // > Propio.Read txt:91
          this.bUseExclusionForce = readBooleanDatafromArrayList(alData, 21, this.TEXT_INPUT_EXCLUSION);  // > Propio.Read txt:92
          if (bUseExclusionForce)  // > Propio.Read txt:93
            this.cte_f_exclusion = readFloatDatafromArrayList(alData, 22, this.TEXT_INPUT_CTE);  // > Propio.Read txt:94
          this.bUseHSn12 = readBooleanDatafromArrayList(alData, 23, this.TEXT_INPUT_R12);  // > Propio.Read txt:95
          if (bUseHSn12)  // > Propio.Read txt:96
            this.cteAHSn12 = readFloatDatafromArrayList(alData, 24, this.TEXT_INPUT_CTE);  // > Propio.Read txt:97
          this.bUseHSn36 = readBooleanDatafromArrayList(alData, 25, this.TEXT_INPUT_R36);  // > Propio.Read txt:98
          if (bUseHSn36)  // > Propio.Read txt:99
            this.cteAHSn36 = readFloatDatafromArrayList(alData, 26, this.TEXT_INPUT_CTE);  // > Propio.Read txt:100
          this.bUseHSHeyes = readBooleanDatafromArrayList(alData, 27, this.TEXT_INPUT_HEYES);  // > Propio.Read txt:101
          if (bUseHSHeyes)  // > Propio.Read txt:102
            this.ctekHSHeyes = readFloatDatafromArrayList(alData, 28, this.TEXT_INPUT_CTE);  // > Propio.Read txt:103
          // > Propio.Read txt:104
        }  // > Propio.Read txt:105
        //Read dt in txt:  // > Propio.Read txt:106
        this.bDtInTxt = readBooleanDatafromArrayList(alData, 30, this.TEXT_INPUT_DTINTXT);  // > Propio.Read txt:107
        if (this.bDtInTxt)  // > Propio.Read txt:108
          this.dtInTxt = readFloatDatafromArrayList(alData, 31, this.TEXT_INPUT_DT);  // > Propio.Read txt:109
        // > Propio.Read txt:110
        //AO DATA       // > Propio.Read txt:111
        this.bAOmodel =  readBooleanDatafromArrayList(alData, 33, this.TEXT_INPUT_AO);  // > Propio.Read txt:112
        if (this.bAOmodel)  // > Propio.Read txt:113
        {  // > Propio.Read txt:114
          this.Rg = readFloatDatafromArrayList(alData, 34, this.TEXT_INPUT_RG);  // > Propio.Read txt:115
          this.cteAOennp = readFloatDatafromArrayList(alData, 35, this.TEXT_INPUT_LONGAOCTE);  // > Propio.Read txt:116
        }  // > Propio.Read txt:117
        //Elec. potential DATA       // > Propio.Read txt:118
        this.bUseElecAtracPot =  readBooleanDatafromArrayList(alData, 37, this.TEXT_INPUT_ELECPOT);  // > Propio.Read txt:119
        if (this.bUseElecAtracPot)  // > Propio.Read txt:120
        {  // > Propio.Read txt:121
          this.Zelec = readFloatDatafromArrayList(alData, 38, this.TEXT_INPUT_Z);  // > Propio.Read txt:122
          this.lambdaelec = readFloatDatafromArrayList(alData, 39, this.TEXT_INPUT_LAMBDA);  // > Propio.Read txt:123
          this.kappainvelec = readFloatDatafromArrayList(alData, 40, this.TEXT_INPUT_KAPPA);  // > Propio.Read txt:124
          this.qelec = readFloatDatafromArrayList(alData, 41, this.TEXT_INPUT_Q);  // > Propio.Read txt:125
        }  // > Propio.Read txt:126
        // > Propio.Read txt:127
        //Optical forces:  // > Propio.Read txt:128
        this.bUseOpticalForce =  readBooleanDatafromArrayList(alData, 43, this.TEXT_INPUT_OPTICAL);  // > Propio.Read txt:129
        if (this.bUseOpticalForce)  // > Propio.Read txt:130
        {  // > Propio.Read txt:131
          this.k_optics_x = readFloatDatafromArrayList(alData, 44, this.TEXT_INPUT_KX);  // > Propio.Read txt:132
          this.k_optics_y = readFloatDatafromArrayList(alData, 45, this.TEXT_INPUT_KY);  // > Propio.Read txt:133
        }  // > Propio.Read txt:134
        this._initialize();  // > Propio.Read txt:135
        //Clear arraylist  // > Propio.Read txt:136
        ((ArrayList)alData).clear();  // > Propio.Read txt:137
      // > Propio.Read txt:138
    }//end if  // > Propio.Read txt:139
  }  // > Propio.Read txt:140
  public boolean readBooleanDatafromArrayList(ArrayList alData, int line, String text)  // > Propio.Read txt:141
  {  // > Propio.Read txt:142
      // > Propio.Read txt:143
    String sline = ((String)alData.get(line)).replace(text,"");  // > Propio.Read txt:144
    sline= sline.replaceAll("\\s","");  // > Propio.Read txt:145
    return Boolean.parseBoolean(sline);  // > Propio.Read txt:146
      // > Propio.Read txt:147
  }      // > Propio.Read txt:148
  public float readFloatDatafromArrayList(ArrayList alData, int line, String text)  // > Propio.Read txt:149
  {  // > Propio.Read txt:150
      // > Propio.Read txt:151
    String sline = ((String)alData.get(line)).replace(text,"");  // > Propio.Read txt:152
    sline= sline.replaceAll("\\s","");  // > Propio.Read txt:153
    return Float.parseFloat(sline);  // > Propio.Read txt:154
     // > Propio.Read txt:155
  }      // > Propio.Read txt:156
  public int readIntDatafromArrayList(ArrayList alData, int line, String text)  // > Propio.Read txt:157
  {  // > Propio.Read txt:158
      // > Propio.Read txt:159
    String sline = ((String)alData.get(line)).replace(text,"");  // > Propio.Read txt:160
    sline= sline.replaceAll("\\s","");  // > Propio.Read txt:161
    return Integer.parseInt(sline);  // > Propio.Read txt:162
  }      // > Propio.Read txt:163
  public ArrayList readFileXY(int numparticles)  // > Propio.Read txt:164
  {  // > Propio.Read txt:165
      ArrayList alData = new ArrayList();  // > Propio.Read txt:166
      this.sReadFilePath= this.sReadFilePath.replaceAll("\\s","");  // > Propio.Read txt:167
        // > Propio.Read txt:168
      if ((!this.sReadFilePath.isEmpty()) && (this.sReadFilePath !=null))  // > Propio.Read txt:169
      {     // > Propio.Read txt:170
        ArrayList alData0 = readFileAsArrayList(this.sReadFilePath);  // > Propio.Read txt:171
        boolean alEmpty = ((ArrayList)alData0).isEmpty();  // > Propio.Read txt:172
        if (!alEmpty)  // > Propio.Read txt:173
        {  // > Propio.Read txt:174
          int numlineas = ((ArrayList)alData0).size();        // > Propio.Read txt:175
          int readfromline = numlineas-numparticles;  // > Propio.Read txt:176
          for (int i=readfromline; i<numlineas; i++)  // > Propio.Read txt:177
          {  // > Propio.Read txt:178
            String line = (String)alData0.get(i);  // > Propio.Read txt:179
            ((ArrayList)alData).add(line);  // > Propio.Read txt:180
            //System.out.println(line);  // > Propio.Read txt:181
          }  // > Propio.Read txt:182
          ((ArrayList)alData0).clear();  // > Propio.Read txt:183
        }  // > Propio.Read txt:184
        // > Propio.Read txt:185
      }  // > Propio.Read txt:186
        // > Propio.Read txt:187
      return alData;  // > Propio.Read txt:188
  }    // > Propio.Read txt:189
  public void putLastImageIntoInitialXY()  // > Propio.Read txt:190
  {  // > Propio.Read txt:191
       // > Propio.Read txt:192
     //This method reads only last n lines of XY file.  // > Propio.Read txt:193
      ArrayList alData = readFileXY(this.n);  // > Propio.Read txt:194
      int numlineas = ((ArrayList)alData).size();  // > Propio.Read txt:195
        // > Propio.Read txt:196
     //If the path was empty, it is an empty arraylist  // > Propio.Read txt:197
     boolean alEmpty = ((ArrayList)alData).isEmpty();  // > Propio.Read txt:198
     if (!alEmpty)  // > Propio.Read txt:199
     {  // > Propio.Read txt:200
         double[] x_0i = new double[numlineas];  // > Propio.Read txt:201
         double[] y_0i = new double[numlineas];  // > Propio.Read txt:202
          // > Propio.Read txt:203
         //Extract the positions from the arraylist  // > Propio.Read txt:204
         for (int i=0; i<numlineas; i++)  // > Propio.Read txt:205
         {  // > Propio.Read txt:206
       // > Propio.Read txt:207
            String line = (String)alData.get(i);  // > Propio.Read txt:208
            String[] values = line.split("\t");  // > Propio.Read txt:209
               // > Propio.Read txt:210
            x_0i[i] = Double.parseDouble(values[0]);  // > Propio.Read txt:211
            y_0i[i] = Double.parseDouble(values[1]);  // > Propio.Read txt:212
            //Box is for read data is between 0 and 2.  // > Propio.Read txt:213
            //Put back to original ejs coordinates.  // > Propio.Read txt:214
            x_0i[i]=x_0i[i]-this.xmax;  // > Propio.Read txt:215
            y_0i[i]=y_0i[i]-this.ymax;  // > Propio.Read txt:216
           //Put the values into the system  // > Propio.Read txt:217
            this.x_0[i] = x_0i[i];  // > Propio.Read txt:218
            this.x[i] = x_0i[i];  // > Propio.Read txt:219
            this.y_0[i] = y_0i[i];  // > Propio.Read txt:220
            this.y[i] = y_0i[i];  // > Propio.Read txt:221
            //System.out.println(this.x_0[i]+"\t"+this.y_0[i]);  // > Propio.Read txt:222
                 // > Propio.Read txt:223
        }  // > Propio.Read txt:224
     }  // > Propio.Read txt:225
       // > Propio.Read txt:226
     //Init some constants  // > Propio.Read txt:227
     initConstants();  // > Propio.Read txt:228
       // > Propio.Read txt:229
     ((ArrayList)alData).clear();  // > Propio.Read txt:230
       // > Propio.Read txt:231
  }  // > Propio.Read txt:232
  public void putReadFilesIntoData()  // > Propio.Read txt:233
  {  // > Propio.Read txt:234
      putInputDataIntoInputValues();  // > Propio.Read txt:235
      putLastImageIntoInitialXY();  // > Propio.Read txt:236
        // > Propio.Read txt:237
  }  // > Propio.Read txt:238

 // --- Methods for view elements

  public double _method_for_drawingPanel2_minimumY () {
    return ymin+ymin/10;
  }

  public double _method_for_drawingPanel2_maximumY () {
    return ymax-ymin/10;
  }

  public double _method_for_segment_sizeY () {
    return ymax-ymin;
  }

  public double _method_for_segment2_sizeY () {
    return ymax-ymin;
  }

  public double _method_for_segment3_sizeX () {
    return xmax-xmin;
  }

  public double _method_for_segment4_sizeX () {
    return xmax-xmin;
  }

  public void _method_for_playPauseButton_actionOn () {
    if (this.bSaveDataAuto) writeInputOnTextFile();
    _play();
  }
  public void _method_for_playPauseButton_actionOff () {
    _pause();
  }
  public void _method_for_resetbutton_action () {
    _initialize();
  }
  public boolean _method_for_button_write_enabled () {
    return (!bSaveDataAuto) && (!bFreeMode);
  }

  public void _method_for_button_write_action () {
    writeInputOnTextFile();
    writeDataOnTextFile(false);
  }
  public boolean _method_for_button_write2_enabled () {
    return (!bSaveDataAuto);
  }

  public void _method_for_button_write2_action () {
    writeInputOnTextFile();
    writeLastStepOnTextFile();
  }
  public void _method_for_resetbutton2_action () {
    _reset();
  }
  public void _method_for_tmax_action () {
    if (tmax <= 0.0) tmax = dt;
    if (!bFreeMode)
    {
      if (tmax > dMaxTime) tmax = dMaxTime;
      if (tmax > dTimeMaxImposed) tmax = dTimeMaxImposed;
    }
    initConstants();
  }
  public void _method_for_textra_action () {
    initConstants();
  }
  public void _method_for_dt_action () {
    initConstants();
  }
  public void _method_for_num_action () {
    if (this.n>500)
      n = 500;
    else if (this.n<1)
      n = 1;  
    _initialize();
  }
  public void _method_for_dreal_action () {
    _initialize();
  }
  public void _method_for_phi2D_action () {
    if (phi_2D>1) phi_2D = 1.0;
    else if (phi_2D<0) phi_2D = 0.0;
    _initialize();
  }
  public void _method_for_check_water_action () {
    _initialize();
  }
  public void _method_for_temp_action () {
    _initialize();
  }
  public boolean _method_for_visco_editable () {
    return !bUseWater;
  }

  public void _method_for_visco_action () {
    _initialize();
  }
  public void _method_for_noboundary_actionon () {
    bUseWallForces = false;
    bUseCyclicContour = false;
    this._initialize();
  }
  public void _method_for_noboundary_actionoff () {
    bUseWallForces = true;
    bUseCyclicContour = false;
    this._initialize();
  }
  public boolean _method_for_check_walls_enabled () {
    return !bUseNoContour;
  }

  public void _method_for_check_walls_actionon () {
    bUseCyclicContour = false;
  }
  public boolean _method_for_PacMan_enabled () {
    return !bUseNoContour;
  }

  public void _method_for_PacMan_action () {
    bUseWallForces = false;
  }
  public void _method_for_diam_redux_action () {
    if (diam_reduction>1.00)
      diam_reduction = 1.00;
    if (diam_reduction<0.00)
      diam_reduction = 0.00;
  }
  public void _method_for_check_forcedisk_actionon () {
    bUseExclusionForce=false;
    bUseHSn12=false;
    bUseHSn36=false;
    bUseHSHeyes=false;
  }
  public void _method_for_check_exclusionvolumenforce_actionon () {
    bUseHSn12=false;
    bUseHSn36=false;
    bUseHSHeyes=false;
  }
  public void _method_for_check_hsn12_actionon () {
    bUseExclusionForce=false;
    bUseHSn36=false;
    bUseHSHeyes=false;
  }
  public boolean _method_for_hsn12_editable () {
    return bUseHSn12 && bUseDiskForce;
  }

  public void _method_for_check_check_hsn36_actionon () {
    bUseExclusionForce=false;
    bUseHSn12=false;
    bUseHSHeyes=false;
  }
  public boolean _method_for_hsn36_editable () {
    return bUseHSn36 && bUseDiskForce;
  }

  public void _method_for_check_heyes_actionon () {
    bUseExclusionForce=false;
    bUseHSn12=false;
    bUseHSn36=false;
  }
  public boolean _method_for_heyes_editable () {
    return bUseHSHeyes && bUseDiskForce;
  }

  public void _method_for_check_opticaltrap_action () {
    if (this.bUseOpticalForce) this.dt=0.0001;
    _initialize();
  }
  public void _method_for_spring_value_x_action () {
    _initialize();
  }
  public boolean _method_for_checkBox_savedata_enabled () {
    return !bFreeMode;
  }

  public boolean _method_for_checkBox_Deltat_enabled () {
    return !bFreeMode;
  }

  public void _method_for_checkBox_Deltat_actionon () {
    initConstants();
  }
  public boolean _method_for_Deltat_editable () {
    return bDtInTxt && (!bFreeMode);
  }

  public void _method_for_Deltat_action () {
    if (this.dtInTxt < this.dt) 
      this.dtInTxt = this.dt;
    initConstants();
  }
  public boolean _method_for_checkBox_labeldisks_enabled () {
    return !bFreeMode;
  }

  public void _method_for_checkBox_freemode_actionon () {
    bSaveDataAuto=false;
  }
  public boolean _method_for_button_path_enabled () {
    return !bFreeMode;
  }

  public void _method_for_button_path_action () {
    this.sDirectoryName = getDirectoryFromDialog();
  }
  public boolean _method_for_path_editable () {
    return !bFreeMode;
  }

  public boolean _method_for_file_editable () {
    return !bFreeMode;
  }

  public void _method_for_button_input_action () {
    this.sReadInputFilePath = getFileFromDialog();
  }
  public void _method_for_button_filename_action () {
    this.sReadFilePath = getFileFromDialog();
  }
  public void _method_for_boton_read_action () {
    putReadFilesIntoData();
  }
  public void _method_for_n_histo_action () {
    _initialize();
    if (binHistoJumps>200)
      binHistoJumps = 200;
    if (binHistoJumps<10)
      binHistoJumps = 10;
  }
  public double _method_for_DeltaDx_variable () {
    return 100*(DHistoJumpsX-D)/D;
  }

  public double _method_for_DeltaDy_variable () {
    return 100*(DHistoJumpsY-D)/D;
  }

  public void _method_for_n_histo2_action () {
    _initialize();
    if (binHistoJumps>200)
      binHistoJumps = 200;
    if (binHistoJumps<10)
      binHistoJumps = 10;
  }
  public double _method_for_Deltakx_variable () {
    return 100*(1e6*kHistoOptPotX-k_optics_x)/k_optics_x;
  }

  public double _method_for_Deltaky_variable () {
    return 100*(1e6*kHistoOptPotY-k_optics_y)/k_optics_y;
  }

  public void _method_for_particlenumber_action () {
    if (particleXYexample<0)
      particleXYexample=0;
    if (particleXYexample>=this.n)
      particleXYexample=this.n-1;
  }
  public void _method_for_boton_action () {
    this.particleXYexample2=this.particleXYexample;
    this._view.clearData();
  }
  public double _method_for_x_y_x () {
    return x[particleXYexample2];
  }

  public double _method_for_x_y_y () {
    return y[particleXYexample2];
  }

  public double _method_for_Particles_minimumY () {
    return nInside-n/10;
  }

  public double _method_for_Particles_maximumY () {
    return n+n/10;
  }

} // End of class Brownian_disks_lab_v1_1Model

