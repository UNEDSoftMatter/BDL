/*
 * Class : Brownian_disks_lab_v1_1Simulation.java
 *  Generated using  *  Easy Java/Javascript Simulations Version 5.3, build 180211. Visit http://www.um.es/fem/Ejs
 */ 

package Brownian_Disks_Lab.Brownian_disks_lab_v1_1_pkg;

import org.colos.ejs.library._EjsConstants;

import java.util.*;
import java.text.*;
import java.lang.StringBuffer;
import java.math.*;
import java.nio.charset.StandardCharsets;
import java.nio.file.*;
import java.io.*;
// Imports suggested by Model Elements:
// End of imports from Model Elements

class Brownian_disks_lab_v1_1Simulation extends org.colos.ejs.library.Simulation { 

  private Brownian_disks_lab_v1_1View mMainView;

  public Brownian_disks_lab_v1_1Simulation (Brownian_disks_lab_v1_1 _model, String _replaceName, java.awt.Frame _replaceOwnerFrame, java.net.URL _codebase, boolean _allowAutoplay) {
    videoUtil = new org.colos.ejs.library.utils.VideoUtilClass();
    try { setUnderEjs("true".equals(System.getProperty("osp_ejs"))); }
    catch (Exception exc) { setUnderEjs(false); } // in case of applet security
    setCodebase (_codebase);
    setModel (_model);
    _model._simulation = this;
    mMainView = _model._view = new Brownian_disks_lab_v1_1View(this,_replaceName, _replaceOwnerFrame);
    setView (_model._view);
    if (_model._isApplet()) _model._getApplet().captureWindow (_model,"drawingFrame2");
    setFPS(25);
    setStepsPerDisplay(_model._getPreferredStepsPerDisplay()); 
    if (_allowAutoplay) { setAutoplay(false); reset(); }
    else { reset(); setAutoplay(false); }
    recreateDescriptionPanel();
    if (_model._getApplet()!=null && _model._getApplet().getParameter("locale")!=null) {
      setLocaleItem(org.colos.ejs.library.utils.LocaleItem.getLocaleItem(_model._getApplet().getParameter("locale")),false);
    }
    else setLocaleItem(getLocaleItem(),false); // false so that not to reset the model twice at start-up
  }

  public java.util.List<String> getWindowsList() {
    java.util.List<String> windowList = new java.util.ArrayList<String>();
    windowList.add("drawingFrame2");
    return windowList;
  }

  public String getMainWindow() {
    return "drawingFrame2";
  }

  protected void setViewLocale() { // Overwrite its parent's dummy method with real actions 
    mMainView.getConfigurableElement("drawingFrame2")
      .setProperty("title",translateString("View.drawingFrame2.title","\"Frame\""))
      .setProperty("size",translateString("View.drawingFrame2.size","\"970,750\""));
    mMainView.getConfigurableElement("tab")
      .setProperty("size",translateString("View.tab.size","\"900,750\""));
    mMainView.getConfigurableElement("Simulation");
    mMainView.getConfigurableElement("panel_TITLE")
      .setProperty("size",translateString("View.panel_TITLE.size","\"700,40\""));
    mMainView.getConfigurableElement("label_TITLE")
      .setProperty("text",translateString("View.label_TITLE.text","\"BROWNIAN DISKS LAB\""));
    mMainView.getConfigurableElement("drawingPanel2");
    mMainView.getConfigurableElement("conjuntoFormas");
    mMainView.getConfigurableElement("segment");
    mMainView.getConfigurableElement("segment2");
    mMainView.getConfigurableElement("segment3");
    mMainView.getConfigurableElement("segment4");
    mMainView.getConfigurableElement("label_simulation")
      .setProperty("size",translateString("View.label_simulation.size","\"700,100\""));
    mMainView.getConfigurableElement("panel_button")
      .setProperty("size",translateString("View.panel_button.size","\"700,50\""));
    mMainView.getConfigurableElement("playPauseButton")
      .setProperty("size",translateString("View.playPauseButton.size","\"50,20\""))
      .setProperty("imageOn",translateString("View.playPauseButton.imageOn","\"/org/opensourcephysics/resources/controls/images/play.gif\""))
      .setProperty("imageOff",translateString("View.playPauseButton.imageOff","/org/opensourcephysics/resources/controls/images/pause.gif"));
    mMainView.getConfigurableElement("panel_separator_sb1")
      .setProperty("size",translateString("View.panel_separator_sb1.size","\"20,10\""));
    mMainView.getConfigurableElement("resetbutton")
      .setProperty("image",translateString("View.resetbutton.image","\"/org/opensourcephysics/resources/controls/images/reset2.gif\""))
      .setProperty("size",translateString("View.resetbutton.size","\"50,20\""));
    mMainView.getConfigurableElement("panel_separator_sb15")
      .setProperty("size",translateString("View.panel_separator_sb15.size","\"20,10\""));
    mMainView.getConfigurableElement("label_write")
      .setProperty("text",translateString("View.label_write.text","\"Write data: \""));
    mMainView.getConfigurableElement("button_write")
      .setProperty("image",translateString("View.button_write.image","\"./saveSmall.gif\""))
      .setProperty("size",translateString("View.button_write.size","\"50,20\""));
    mMainView.getConfigurableElement("panel_separator_sb22")
      .setProperty("size",translateString("View.panel_separator_sb22.size","\"20,10\""));
    mMainView.getConfigurableElement("label_write2")
      .setProperty("text",translateString("View.label_write2.text","\"Write last step \""));
    mMainView.getConfigurableElement("button_write2")
      .setProperty("image",translateString("View.button_write2.image","\"./saveSmall.gif\""))
      .setProperty("size",translateString("View.button_write2.size","\"50,20\""));
    mMainView.getConfigurableElement("panel_separator_sb2")
      .setProperty("size",translateString("View.panel_separator_sb2.size","\"20,10\""));
    mMainView.getConfigurableElement("label_reset2")
      .setProperty("text",translateString("View.label_reset2.text","\"Reset (default val.): \""));
    mMainView.getConfigurableElement("resetbutton2")
      .setProperty("image",translateString("View.resetbutton2.image","\"/org/opensourcephysics/resources/controls/images/reset.gif\""))
      .setProperty("size",translateString("View.resetbutton2.size","\"50,20\""));
    mMainView.getConfigurableElement("panel_time")
      .setProperty("size",translateString("View.panel_time.size","\"700,30\""));
    mMainView.getConfigurableElement("panel_times");
    mMainView.getConfigurableElement("text_time")
      .setProperty("text",translateString("View.text_time.text","\"Time (s): \""));
    mMainView.getConfigurableElement("time_view")
      .setProperty("size",translateString("View.time_view.size","\"50,20\""));
    mMainView.getConfigurableElement("bar_time")
      .setProperty("size",translateString("View.bar_time.size","\"50,20\""));
    mMainView.getConfigurableElement("panel_separator_sb12")
      .setProperty("size",translateString("View.panel_separator_sb12.size","\"20,10\""));
    mMainView.getConfigurableElement("label_maxtime")
      .setProperty("text",translateString("View.label_maxtime.text","\"Duration of experiment (s): \""));
    mMainView.getConfigurableElement("tmax")
      .setProperty("size",translateString("View.tmax.size","\"60,30\""));
    mMainView.getConfigurableElement("panel_separator_sb13")
      .setProperty("size",translateString("View.panel_separator_sb13.size","\"20,10\""));
    mMainView.getConfigurableElement("text_initialtime")
      .setProperty("text",translateString("View.text_initialtime.text","\"Time initial diffusion (s): \""));
    mMainView.getConfigurableElement("textra")
      .setProperty("format",translateString("View.textra.format","\"00.0\""))
      .setProperty("size",translateString("View.textra.size","\"50,30\""));
    mMainView.getConfigurableElement("panel_separator_sb14")
      .setProperty("size",translateString("View.panel_separator_sb14.size","\"20,10\""));
    mMainView.getConfigurableElement("label_dt")
      .setProperty("text",translateString("View.label_dt.text","\"Temporal step (s): \""));
    mMainView.getConfigurableElement("dt")
      .setProperty("format",translateString("View.dt.format","\"0.0000\""))
      .setProperty("size",translateString("View.dt.size","\"80,30\""));
    mMainView.getConfigurableElement("Input_Data");
    mMainView.getConfigurableElement("panel_particles");
    mMainView.getConfigurableElement("label_panel_particles")
      .setProperty("text",translateString("View.label_panel_particles.text","\"INPUT DATA FOR PARTICLES: \""));
    mMainView.getConfigurableElement("panel_input");
    mMainView.getConfigurableElement("panel_num");
    mMainView.getConfigurableElement("label_explain_num")
      .setProperty("text",translateString("View.label_explain_num.text","\"Number, size and concentration:\""));
    mMainView.getConfigurableElement("panel_separator22")
      .setProperty("size",translateString("View.panel_separator22.size","\"50,10\""));
    mMainView.getConfigurableElement("text_num")
      .setProperty("text",translateString("View.text_num.text","\"N: \""));
    mMainView.getConfigurableElement("num")
      .setProperty("format",translateString("View.num.format","\"#000\""));
    mMainView.getConfigurableElement("panel_separator")
      .setProperty("size",translateString("View.panel_separator.size","\"50,10\""));
    mMainView.getConfigurableElement("text_dreal")
      .setProperty("text",translateString("View.text_dreal.text","\"Diameter (μm): \""));
    mMainView.getConfigurableElement("dreal")
      .setProperty("format",translateString("View.dreal.format","\"0.00\""));
    mMainView.getConfigurableElement("panel_separator2")
      .setProperty("size",translateString("View.panel_separator2.size","\"50,10\""));
    mMainView.getConfigurableElement("text_phi2D")
      .setProperty("text",translateString("View.text_phi2D.text","\"ϕ2D: \""));
    mMainView.getConfigurableElement("phi2D")
      .setProperty("format",translateString("View.phi2D.format","\"0.0000\""));
    mMainView.getConfigurableElement("panel_temp");
    mMainView.getConfigurableElement("label_explain_temp")
      .setProperty("text",translateString("View.label_explain_temp.text","\"Fluid: temperature and viscosity: \""));
    mMainView.getConfigurableElement("check_water")
      .setProperty("text",translateString("View.check_water.text","\"Water?\""));
    mMainView.getConfigurableElement("panel_separator_temp1")
      .setProperty("size",translateString("View.panel_separator_temp1.size","\"30,10\""));
    mMainView.getConfigurableElement("label_temp")
      .setProperty("text",translateString("View.label_temp.text","\"Temp. (K):\""));
    mMainView.getConfigurableElement("temp")
      .setProperty("format",translateString("View.temp.format","\"000.0\""));
    mMainView.getConfigurableElement("panel_separator_temp2")
      .setProperty("size",translateString("View.panel_separator_temp2.size","\"30,10\""));
    mMainView.getConfigurableElement("label_visco")
      .setProperty("text",translateString("View.label_visco.text","\"η (Pa.s): \""));
    mMainView.getConfigurableElement("visco")
      .setProperty("format",translateString("View.visco.format","\"0.0000\""));
    mMainView.getConfigurableElement("panel_separator_temp3")
      .setProperty("size",translateString("View.panel_separator_temp3.size","\"30,10\""));
    mMainView.getConfigurableElement("text_diffreal")
      .setProperty("text",translateString("View.text_diffreal.text","\"D (μm²/s): \""));
    mMainView.getConfigurableElement("diffreal")
      .setProperty("format",translateString("View.diffreal.format","\"0.##E0\""));
    mMainView.getConfigurableElement("panel_conversion");
    mMainView.getConfigurableElement("label_explain_conversion")
      .setProperty("text",translateString("View.label_explain_conversion.text","\"Values in simulation (screen units): \""));
    mMainView.getConfigurableElement("panel_separator_conv1")
      .setProperty("size",translateString("View.panel_separator_conv1.size","\"50,10\""));
    mMainView.getConfigurableElement("text_dsim")
      .setProperty("text",translateString("View.text_dsim.text","\"Diameter: \""));
    mMainView.getConfigurableElement("dsim")
      .setProperty("format",translateString("View.dsim.format","\"0.0000\""));
    mMainView.getConfigurableElement("panel_separator_conv2")
      .setProperty("size",translateString("View.panel_separator_conv2.size","\"30,10\""));
    mMainView.getConfigurableElement("text_factorcal")
      .setProperty("text",translateString("View.text_factorcal.text","\"Cal. factor: \""));
    mMainView.getConfigurableElement("factcal")
      .setProperty("format",translateString("View.factcal.format","\"0.0000\""));
    mMainView.getConfigurableElement("panel_separator_conv3")
      .setProperty("size",translateString("View.panel_separator_conv3.size","\"30,10\""));
    mMainView.getConfigurableElement("text_diffsim")
      .setProperty("text",translateString("View.text_diffsim.text","\"D: \""));
    mMainView.getConfigurableElement("diffsim")
      .setProperty("format",translateString("View.diffsim.format","\"0.##E0\""));
    mMainView.getConfigurableElement("panel_contour");
    mMainView.getConfigurableElement("label_panel_particles2")
      .setProperty("text",translateString("View.label_panel_particles2.text","\"BOUNDARY LIMITS AND HARD-DISK FORCES\""));
    mMainView.getConfigurableElement("label_boundaries");
    mMainView.getConfigurableElement("text_boundary")
      .setProperty("text",translateString("View.text_boundary.text","\"Boundary conditions: \""));
    mMainView.getConfigurableElement("panel_separator_cont1")
      .setProperty("size",translateString("View.panel_separator_cont1.size","\"30,10\""));
    mMainView.getConfigurableElement("noboundary")
      .setProperty("text",translateString("View.noboundary.text","\"No Boundary.\""));
    mMainView.getConfigurableElement("panel_separator_cont2")
      .setProperty("size",translateString("View.panel_separator_cont2.size","\"30,10\""));
    mMainView.getConfigurableElement("check_walls")
      .setProperty("text",translateString("View.check_walls.text","\"Wall force: \""));
    mMainView.getConfigurableElement("wall")
      .setProperty("format",translateString("View.wall.format","\"0.00\""))
      .setProperty("size",translateString("View.wall.size","\"50,20\""));
    mMainView.getConfigurableElement("panel_separator_cont3")
      .setProperty("size",translateString("View.panel_separator_cont3.size","\"30,10\""));
    mMainView.getConfigurableElement("PacMan")
      .setProperty("text",translateString("View.PacMan.text","\"Cyclic.  \""));
    mMainView.getConfigurableElement("diam_redux")
      .setProperty("format",translateString("View.diam_redux.format","\"#0.00\""))
      .setProperty("size",translateString("View.diam_redux.size","\"50,20\""));
    mMainView.getConfigurableElement("label_disks");
    mMainView.getConfigurableElement("check_forcedisk")
      .setProperty("text",translateString("View.check_forcedisk.text","\"Use disk forces: \""));
    mMainView.getConfigurableElement("panel_separator_dsk1")
      .setProperty("size",translateString("View.panel_separator_dsk1.size","\"20,10\""));
    mMainView.getConfigurableElement("check_exclusionvolumenforce")
      .setProperty("text",translateString("View.check_exclusionvolumenforce.text","\"Exclusion volume force\""));
    mMainView.getConfigurableElement("panel_separator_dsk2")
      .setProperty("size",translateString("View.panel_separator_dsk2.size","\"20,10\""));
    mMainView.getConfigurableElement("check_hsn12")
      .setProperty("text",translateString("View.check_hsn12.text","\"HS n=12\""));
    mMainView.getConfigurableElement("hsn12");
    mMainView.getConfigurableElement("panel_separator_dsk3")
      .setProperty("size",translateString("View.panel_separator_dsk3.size","\"20,10\""));
    mMainView.getConfigurableElement("check_check_hsn36")
      .setProperty("text",translateString("View.check_check_hsn36.text","\"HS n=36\""));
    mMainView.getConfigurableElement("hsn36");
    mMainView.getConfigurableElement("panel_separator_dsk4")
      .setProperty("size",translateString("View.panel_separator_dsk4.size","\"20,10\""));
    mMainView.getConfigurableElement("check_heyes")
      .setProperty("text",translateString("View.check_heyes.text","\"Heyes\""));
    mMainView.getConfigurableElement("heyes");
    mMainView.getConfigurableElement("panel_potentials");
    mMainView.getConfigurableElement("label_panel_particles22")
      .setProperty("text",translateString("View.label_panel_particles22.text","\"EXTERNAL POTENTIALS\""));
    mMainView.getConfigurableElement("panel_AO");
    mMainView.getConfigurableElement("check_AO")
      .setProperty("text",translateString("View.check_AO.text","\"AO force\""));
    mMainView.getConfigurableElement("panel_separator_ao1")
      .setProperty("size",translateString("View.panel_separator_ao1.size","\"50,10\""));
    mMainView.getConfigurableElement("text_rg")
      .setProperty("text",translateString("View.text_rg.text","\"Rg(nm): \""));
    mMainView.getConfigurableElement("rg");
    mMainView.getConfigurableElement("panel_separator_ao2")
      .setProperty("size",translateString("View.panel_separator_ao2.size","\"50,10\""));
    mMainView.getConfigurableElement("label_ctenp")
      .setProperty("text",translateString("View.label_ctenp.text","\"Π/KT (μm-³):\""));
    mMainView.getConfigurableElement("ctenp");
    mMainView.getConfigurableElement("panel_atrac_pot");
    mMainView.getConfigurableElement("check_atracpot")
      .setProperty("text",translateString("View.check_atracpot.text","\"Pot Elec. Atrac.\""));
    mMainView.getConfigurableElement("panel_separator_ap1")
      .setProperty("size",translateString("View.panel_separator_ap1.size","\"80,10\""));
    mMainView.getConfigurableElement("text_Z")
      .setProperty("text",translateString("View.text_Z.text","\"Z: \""));
    mMainView.getConfigurableElement("Z");
    mMainView.getConfigurableElement("panel_separator_ap2")
      .setProperty("size",translateString("View.panel_separator_ap2.size","\"20,10\""));
    mMainView.getConfigurableElement("text_lambda")
      .setProperty("text",translateString("View.text_lambda.text","\" λB (nm): \""));
    mMainView.getConfigurableElement("lambda");
    mMainView.getConfigurableElement("panel_separator_ap3")
      .setProperty("size",translateString("View.panel_separator_ap3.size","\"20,10\""));
    mMainView.getConfigurableElement("text_1divk")
      .setProperty("text",translateString("View.text_1divk.text","\" 1/κ (μm): \""));
    mMainView.getConfigurableElement("_divk");
    mMainView.getConfigurableElement("panel_separator_ap4")
      .setProperty("size",translateString("View.panel_separator_ap4.size","\"20,10\""));
    mMainView.getConfigurableElement("text_q")
      .setProperty("text",translateString("View.text_q.text","\" q :\""));
    mMainView.getConfigurableElement("q");
    mMainView.getConfigurableElement("panel_optical_forces");
    mMainView.getConfigurableElement("check_opticaltrap")
      .setProperty("text",translateString("View.check_opticaltrap.text","\"Optical trapping forces\""));
    mMainView.getConfigurableElement("panel_separator_op1")
      .setProperty("size",translateString("View.panel_separator_op1.size","\"50,10\""));
    mMainView.getConfigurableElement("spring_text_x")
      .setProperty("text",translateString("View.spring_text_x.text","\"k_x (μN/m):  \""));
    mMainView.getConfigurableElement("spring_value_x")
      .setProperty("format",translateString("View.spring_value_x.format","\"0.00\""));
    mMainView.getConfigurableElement("panel_separator_op12")
      .setProperty("size",translateString("View.panel_separator_op12.size","\"50,10\""));
    mMainView.getConfigurableElement("spring_text_y")
      .setProperty("text",translateString("View.spring_text_y.text","\"k_y (μN/m):  \""));
    mMainView.getConfigurableElement("spring_value_y")
      .setProperty("format",translateString("View.spring_value_y.format","\"0.00\""));
    mMainView.getConfigurableElement("panel_writereaddata");
    mMainView.getConfigurableElement("text_explain_data")
      .setProperty("text",translateString("View.text_explain_data.text","\"SAVE DATA TO TXT FILE\""));
    mMainView.getConfigurableElement("panel_Deltat");
    mMainView.getConfigurableElement("checkBox_savedata")
      .setProperty("text",translateString("View.checkBox_savedata.text","\"Save data automatically? \""));
    mMainView.getConfigurableElement("panel_separator_Dt12")
      .setProperty("size",translateString("View.panel_separator_Dt12.size","\"20,10\""));
    mMainView.getConfigurableElement("checkBox_Deltat")
      .setProperty("text",translateString("View.checkBox_Deltat.text","\"Δt (s) imposed in txt: \""));
    mMainView.getConfigurableElement("Deltat")
      .setProperty("format",translateString("View.Deltat.format","\"0.0000\""))
      .setProperty("size",translateString("View.Deltat.size","\"100,30\""));
    mMainView.getConfigurableElement("panel_separator_Dt122")
      .setProperty("size",translateString("View.panel_separator_Dt122.size","\"20,10\""));
    mMainView.getConfigurableElement("checkBox_labeldisks")
      .setProperty("text",translateString("View.checkBox_labeldisks.text","\"Include disks' number?\""));
    mMainView.getConfigurableElement("panel_separator_Dt1222")
      .setProperty("size",translateString("View.panel_separator_Dt1222.size","\"20,10\""));
    mMainView.getConfigurableElement("checkBox_freemode")
      .setProperty("text",translateString("View.checkBox_freemode.text","\"Not saving data?\""));
    mMainView.getConfigurableElement("panel_paths");
    mMainView.getConfigurableElement("text_path")
      .setProperty("text",translateString("View.text_path.text","\"Directory to save file: \""));
    mMainView.getConfigurableElement("panel_separator_path1")
      .setProperty("size",translateString("View.panel_separator_path1.size","\"20,10\""));
    mMainView.getConfigurableElement("button_path")
      .setProperty("image",translateString("View.button_path.image","\"/org/opensourcephysics/resources/controls/images/folder.gif\""));
    mMainView.getConfigurableElement("path")
      .setProperty("size",translateString("View.path.size","\"300,30\""));
    mMainView.getConfigurableElement("panel_separator_path2")
      .setProperty("size",translateString("View.panel_separator_path2.size","\"20,10\""));
    mMainView.getConfigurableElement("text_file")
      .setProperty("text",translateString("View.text_file.text","\"Name file.txt: \""));
    mMainView.getConfigurableElement("file")
      .setProperty("size",translateString("View.file.size","\"200,30\""));
    mMainView.getConfigurableElement("text_explain_data2")
      .setProperty("text",translateString("View.text_explain_data2.text","\"READ  INPUT FILE AND INITIAL XY POSITIONS\""));
    mMainView.getConfigurableElement("panel_read");
    mMainView.getConfigurableElement("botonRadio_read")
      .setProperty("text",translateString("View.botonRadio_read.text","\"Read data from files: \""));
    mMainView.getConfigurableElement("panel_separator_path12")
      .setProperty("size",translateString("View.panel_separator_path12.size","\"20,10\""));
    mMainView.getConfigurableElement("etiqueta_inputfile")
      .setProperty("text",translateString("View.etiqueta_inputfile.text","\"Input file: \""));
    mMainView.getConfigurableElement("button_input")
      .setProperty("image",translateString("View.button_input.image","\"/org/opensourcephysics/resources/controls/images/folder.gif\""));
    mMainView.getConfigurableElement("path_inputfile")
      .setProperty("size",translateString("View.path_inputfile.size","\"200,30\""));
    mMainView.getConfigurableElement("etiqueta_filename")
      .setProperty("text",translateString("View.etiqueta_filename.text","\"  XY file: \""));
    mMainView.getConfigurableElement("button_filename")
      .setProperty("image",translateString("View.button_filename.image","\"/org/opensourcephysics/resources/controls/images/folder.gif\""));
    mMainView.getConfigurableElement("path_filename")
      .setProperty("size",translateString("View.path_filename.size","\"200,30\""));
    mMainView.getConfigurableElement("panel_separator_path122")
      .setProperty("size",translateString("View.panel_separator_path122.size","\"20,10\""));
    mMainView.getConfigurableElement("boton_read")
      .setProperty("text",translateString("View.boton_read.text","\"Read\""));
    mMainView.getConfigurableElement("Graphics");
    mMainView.getConfigurableElement("Diffusion_panel");
    mMainView.getConfigurableElement("panel_data_diff");
    mMainView.getConfigurableElement("panel_data_title_label")
      .setProperty("text",translateString("View.panel_data_title_label.text","\"GAUSSIAN DIFFUSION\""));
    mMainView.getConfigurableElement("useGaussian_panel");
    mMainView.getConfigurableElement("useGaussian")
      .setProperty("text",translateString("View.useGaussian.text","\"Calculate Gaussian statistics\""));
    mMainView.getConfigurableElement("n_histo_panel");
    mMainView.getConfigurableElement("n_histo_label")
      .setProperty("text",translateString("View.n_histo_label.text","\"Number of points of histogram (10-200): \""));
    mMainView.getConfigurableElement("n_histo")
      .setProperty("format",translateString("View.n_histo.format","\"000\""))
      .setProperty("size",translateString("View.n_histo.size","\"60,10\""));
    mMainView.getConfigurableElement("DeltaDx_panel");
    mMainView.getConfigurableElement("DeltaDx_label")
      .setProperty("text",translateString("View.DeltaDx_label.text","\"Relative error Dx and calculated (%) :\""));
    mMainView.getConfigurableElement("DeltaDx")
      .setProperty("format",translateString("View.DeltaDx.format","\"0.0\""))
      .setProperty("size",translateString("View.DeltaDx.size","\"60,10\""));
    mMainView.getConfigurableElement("DeltaDy_panel");
    mMainView.getConfigurableElement("DeltaDy_label")
      .setProperty("text",translateString("View.DeltaDy_label.text","\"Relative error Dy and calculated (%) :\""));
    mMainView.getConfigurableElement("DeltaDy")
      .setProperty("format",translateString("View.DeltaDy.format","\"0.0\""))
      .setProperty("size",translateString("View.DeltaDy.size","\"60,10\""));
    mMainView.getConfigurableElement("panel_diff_separator");
    mMainView.getConfigurableElement("panel_graph_diff");
    mMainView.getConfigurableElement("Diffusion")
      .setProperty("title",translateString("View.Diffusion.title","\"Gaussian Diffusion\""))
      .setProperty("titleY",translateString("View.Diffusion.titleY","\"Counts X (blue), Y (red)\""))
      .setProperty("size",translateString("View.Diffusion.size","\"300,200\""));
    mMainView.getConfigurableElement("countx");
    mMainView.getConfigurableElement("county");
    mMainView.getConfigurableElement("Optical_panel");
    mMainView.getConfigurableElement("panel_data_k");
    mMainView.getConfigurableElement("panel_data_k_title")
      .setProperty("text",translateString("View.panel_data_k_title.text","\"BOLTZMANN STATISTICS ON OPTICAL TRAP\""));
    mMainView.getConfigurableElement("usek_panel");
    mMainView.getConfigurableElement("usek")
      .setProperty("text",translateString("View.usek.text","\"Calculate k from Boltzmann statistics\""));
    mMainView.getConfigurableElement("n_histo_k_panel");
    mMainView.getConfigurableElement("n_histo_label2")
      .setProperty("text",translateString("View.n_histo_label2.text","\"Number of points of histogram (10-200): \""));
    mMainView.getConfigurableElement("n_histo2")
      .setProperty("format",translateString("View.n_histo2.format","\"000\""))
      .setProperty("size",translateString("View.n_histo2.size","\"60,10\""));
    mMainView.getConfigurableElement("Deltakx_panel");
    mMainView.getConfigurableElement("Deltakx_label")
      .setProperty("text",translateString("View.Deltakx_label.text","\"Relative error kx and calculated (%) :\""));
    mMainView.getConfigurableElement("Deltakx")
      .setProperty("format",translateString("View.Deltakx.format","\"0.0\""))
      .setProperty("size",translateString("View.Deltakx.size","\"60,10\""));
    mMainView.getConfigurableElement("Deltaky_panel");
    mMainView.getConfigurableElement("Deltaky_label")
      .setProperty("text",translateString("View.Deltaky_label.text","\"Relative error ky and calculated (%) :\""));
    mMainView.getConfigurableElement("Deltaky")
      .setProperty("format",translateString("View.Deltaky.format","\"0.0\""))
      .setProperty("size",translateString("View.Deltaky.size","\"60,10\""));
    mMainView.getConfigurableElement("panel_diff_separator2");
    mMainView.getConfigurableElement("panel_graph_k");
    mMainView.getConfigurableElement("Potential")
      .setProperty("title",translateString("View.Potential.title","\"Boltzmann statistics\""))
      .setProperty("titleY",translateString("View.Potential.titleY","\"Counts X (blue), Y (red)\""))
      .setProperty("size",translateString("View.Potential.size","\"300,200\""));
    mMainView.getConfigurableElement("x");
    mMainView.getConfigurableElement("y");
    mMainView.getConfigurableElement("Particles_panel");
    mMainView.getConfigurableElement("panel_XY");
    mMainView.getConfigurableElement("paneltitle");
    mMainView.getConfigurableElement("particletitle")
      .setProperty("text",translateString("View.particletitle.text","\"Particle's xy position. \""));
    mMainView.getConfigurableElement("sep_panel");
    mMainView.getConfigurableElement("etiqueta")
      .setProperty("text",translateString("View.etiqueta.text","\"Number of the particle:  \""));
    mMainView.getConfigurableElement("particlenumber")
      .setProperty("format",translateString("View.particlenumber.format","\"#0\""))
      .setProperty("size",translateString("View.particlenumber.size","\"5,15\""));
    mMainView.getConfigurableElement("boton")
      .setProperty("text",translateString("View.boton.text","\"Change\""));
    mMainView.getConfigurableElement("one_particle_xy")
      .setProperty("titleX",translateString("View.one_particle_xy.titleX","\"X\""))
      .setProperty("titleY",translateString("View.one_particle_xy.titleY","\"Y\""))
      .setProperty("size",translateString("View.one_particle_xy.size","\"300,200\""));
    mMainView.getConfigurableElement("x_y");
    mMainView.getConfigurableElement("panel_n");
    mMainView.getConfigurableElement("Particles")
      .setProperty("title",translateString("View.Particles.title","\"Number of particles (red) inside the box (blue)\""))
      .setProperty("titleX",translateString("View.Particles.titleX","\"time (s)\""))
      .setProperty("titleY",translateString("View.Particles.titleY","\"Number of particles\""))
      .setProperty("size",translateString("View.Particles.size","\"300,200\""));
    mMainView.getConfigurableElement("n");
    mMainView.getConfigurableElement("ndentro");
    super.setViewLocale();
  }

  public org.colos.ejs.library.LauncherApplet initMoodle () {
    org.colos.ejs.library.LauncherApplet applet = super.initMoodle();
    if (applet!=null && applet.getParameter("moodle_upload_file")!=null &&
        applet.getParameter("ejsapp_id")!=null  && applet.getParameter("user_id")!=null &&
        applet.getParameter("context_id")!=null && applet.getParameter("language")!=null &&
        applet.getParameter("username")!=null)
        moodle = new org.colos.ejs.library.MoodleConnection (applet,this);
    return applet;
  }

} // End of class Brownian_disks_lab_v1_1Simulation

