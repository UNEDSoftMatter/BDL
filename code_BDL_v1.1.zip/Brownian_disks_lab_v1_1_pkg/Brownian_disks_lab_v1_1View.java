/*
 * Class : Brownian_disks_lab_v1_1View.java
 *  Generated using  *  Easy Java/Javascript Simulations Version 5.3, build 180211. Visit http://www.um.es/fem/Ejs
 */ 

package Brownian_Disks_Lab.Brownian_disks_lab_v1_1_pkg;

import org.colos.ejs.library._EjsConstants;

import java.util.*;
import java.text.*;
import java.lang.StringBuffer;
import java.math.*;
import java.nio.charset.StandardCharsets;
import java.nio.file.*;
import java.io.*;
// Imports suggested by Model Elements:
// End of imports from Model Elements

import javax.swing.event.*;
import javax.swing.*;
import java.awt.event.*;
import java.awt.*;
import java.net.*;
import java.util.*;
import java.io.*;
import java.lang.*;

import org.colos.ejs.library.View;

class Brownian_disks_lab_v1_1View extends org.colos.ejs.library.control.EjsControl implements org.colos.ejs.library.View {
  private Brownian_disks_lab_v1_1Simulation _simulation=null;
  private Brownian_disks_lab_v1_1 _model=null;

  // Public variables for wrapped view elements:
  public java.awt.Component drawingFrame2;
  public javax.swing.JTabbedPane tab;
  public javax.swing.JPanel Simulation;
  public javax.swing.JPanel panel_TITLE;
  public javax.swing.JLabel label_TITLE;
  public org.opensourcephysics.drawing2d.DrawingPanel2D drawingPanel2;
  public org.opensourcephysics.drawing2d.Set conjuntoFormas;
  public org.opensourcephysics.drawing2d.ElementSegment segment;
  public org.opensourcephysics.drawing2d.ElementSegment segment2;
  public org.opensourcephysics.drawing2d.ElementSegment segment3;
  public org.opensourcephysics.drawing2d.ElementSegment segment4;
  public javax.swing.JPanel label_simulation;
  public javax.swing.JPanel panel_button;
  public javax.swing.JButton playPauseButton;
  public javax.swing.JPanel panel_separator_sb1;
  public javax.swing.JButton resetbutton;
  public javax.swing.JPanel panel_separator_sb15;
  public javax.swing.JLabel label_write;
  public javax.swing.JButton button_write;
  public javax.swing.JPanel panel_separator_sb22;
  public javax.swing.JLabel label_write2;
  public javax.swing.JButton button_write2;
  public javax.swing.JPanel panel_separator_sb2;
  public javax.swing.JLabel label_reset2;
  public javax.swing.JButton resetbutton2;
  public javax.swing.JPanel panel_time;
  public javax.swing.JPanel panel_times;
  public javax.swing.JLabel text_time;
  public javax.swing.JTextField time_view;
  public org.colos.ejs.library.control.swing.JProgressBarDouble bar_time;
  public javax.swing.JPanel panel_separator_sb12;
  public javax.swing.JLabel label_maxtime;
  public javax.swing.JTextField tmax;
  public javax.swing.JPanel panel_separator_sb13;
  public javax.swing.JLabel text_initialtime;
  public javax.swing.JTextField textra;
  public javax.swing.JPanel panel_separator_sb14;
  public javax.swing.JLabel label_dt;
  public javax.swing.JTextField dt;
  public javax.swing.JPanel Input_Data;
  public javax.swing.JPanel panel_particles;
  public javax.swing.JLabel label_panel_particles;
  public javax.swing.JPanel panel_input;
  public javax.swing.JPanel panel_num;
  public javax.swing.JLabel label_explain_num;
  public javax.swing.JPanel panel_separator22;
  public javax.swing.JLabel text_num;
  public javax.swing.JTextField num;
  public javax.swing.JPanel panel_separator;
  public javax.swing.JLabel text_dreal;
  public javax.swing.JTextField dreal;
  public javax.swing.JPanel panel_separator2;
  public javax.swing.JLabel text_phi2D;
  public javax.swing.JTextField phi2D;
  public javax.swing.JPanel panel_temp;
  public javax.swing.JLabel label_explain_temp;
  public javax.swing.JCheckBox check_water;
  public javax.swing.JPanel panel_separator_temp1;
  public javax.swing.JLabel label_temp;
  public javax.swing.JTextField temp;
  public javax.swing.JPanel panel_separator_temp2;
  public javax.swing.JLabel label_visco;
  public javax.swing.JTextField visco;
  public javax.swing.JPanel panel_separator_temp3;
  public javax.swing.JLabel text_diffreal;
  public javax.swing.JTextField diffreal;
  public javax.swing.JPanel panel_conversion;
  public javax.swing.JLabel label_explain_conversion;
  public javax.swing.JPanel panel_separator_conv1;
  public javax.swing.JLabel text_dsim;
  public javax.swing.JTextField dsim;
  public javax.swing.JPanel panel_separator_conv2;
  public javax.swing.JLabel text_factorcal;
  public javax.swing.JTextField factcal;
  public javax.swing.JPanel panel_separator_conv3;
  public javax.swing.JLabel text_diffsim;
  public javax.swing.JTextField diffsim;
  public javax.swing.JPanel panel_contour;
  public javax.swing.JLabel label_panel_particles2;
  public javax.swing.JPanel label_boundaries;
  public javax.swing.JLabel text_boundary;
  public javax.swing.JPanel panel_separator_cont1;
  public javax.swing.JRadioButton noboundary;
  public javax.swing.JPanel panel_separator_cont2;
  public javax.swing.JRadioButton check_walls;
  public javax.swing.JTextField wall;
  public javax.swing.JPanel panel_separator_cont3;
  public javax.swing.JRadioButton PacMan;
  public javax.swing.JTextField diam_redux;
  public javax.swing.JPanel label_disks;
  public javax.swing.JCheckBox check_forcedisk;
  public javax.swing.JPanel panel_separator_dsk1;
  public javax.swing.JRadioButton check_exclusionvolumenforce;
  public javax.swing.JPanel panel_separator_dsk2;
  public javax.swing.JRadioButton check_hsn12;
  public javax.swing.JTextField hsn12;
  public javax.swing.JPanel panel_separator_dsk3;
  public javax.swing.JRadioButton check_check_hsn36;
  public javax.swing.JTextField hsn36;
  public javax.swing.JPanel panel_separator_dsk4;
  public javax.swing.JRadioButton check_heyes;
  public javax.swing.JTextField heyes;
  public javax.swing.JPanel panel_potentials;
  public javax.swing.JLabel label_panel_particles22;
  public javax.swing.JPanel panel_AO;
  public javax.swing.JRadioButton check_AO;
  public javax.swing.JPanel panel_separator_ao1;
  public javax.swing.JLabel text_rg;
  public javax.swing.JTextField rg;
  public javax.swing.JPanel panel_separator_ao2;
  public javax.swing.JLabel label_ctenp;
  public javax.swing.JTextField ctenp;
  public javax.swing.JPanel panel_atrac_pot;
  public javax.swing.JRadioButton check_atracpot;
  public javax.swing.JPanel panel_separator_ap1;
  public javax.swing.JLabel text_Z;
  public javax.swing.JTextField Z;
  public javax.swing.JPanel panel_separator_ap2;
  public javax.swing.JLabel text_lambda;
  public javax.swing.JTextField lambda;
  public javax.swing.JPanel panel_separator_ap3;
  public javax.swing.JLabel text_1divk;
  public javax.swing.JTextField _divk;
  public javax.swing.JPanel panel_separator_ap4;
  public javax.swing.JLabel text_q;
  public javax.swing.JTextField q;
  public javax.swing.JPanel panel_optical_forces;
  public javax.swing.JRadioButton check_opticaltrap;
  public javax.swing.JPanel panel_separator_op1;
  public javax.swing.JLabel spring_text_x;
  public javax.swing.JTextField spring_value_x;
  public javax.swing.JPanel panel_separator_op12;
  public javax.swing.JLabel spring_text_y;
  public javax.swing.JTextField spring_value_y;
  public javax.swing.JPanel panel_writereaddata;
  public javax.swing.JLabel text_explain_data;
  public javax.swing.JPanel panel_Deltat;
  public javax.swing.JCheckBox checkBox_savedata;
  public javax.swing.JPanel panel_separator_Dt12;
  public javax.swing.JCheckBox checkBox_Deltat;
  public javax.swing.JTextField Deltat;
  public javax.swing.JPanel panel_separator_Dt122;
  public javax.swing.JCheckBox checkBox_labeldisks;
  public javax.swing.JPanel panel_separator_Dt1222;
  public javax.swing.JCheckBox checkBox_freemode;
  public javax.swing.JPanel panel_paths;
  public javax.swing.JLabel text_path;
  public javax.swing.JPanel panel_separator_path1;
  public javax.swing.JButton button_path;
  public javax.swing.JTextField path;
  public javax.swing.JPanel panel_separator_path2;
  public javax.swing.JLabel text_file;
  public javax.swing.JTextField file;
  public javax.swing.JLabel text_explain_data2;
  public javax.swing.JPanel panel_read;
  public javax.swing.JRadioButton botonRadio_read;
  public javax.swing.JPanel panel_separator_path12;
  public javax.swing.JLabel etiqueta_inputfile;
  public javax.swing.JButton button_input;
  public javax.swing.JTextField path_inputfile;
  public javax.swing.JLabel etiqueta_filename;
  public javax.swing.JButton button_filename;
  public javax.swing.JTextField path_filename;
  public javax.swing.JPanel panel_separator_path122;
  public javax.swing.JButton boton_read;
  public javax.swing.JPanel Graphics;
  public javax.swing.JPanel Diffusion_panel;
  public javax.swing.JPanel panel_data_diff;
  public javax.swing.JLabel panel_data_title_label;
  public javax.swing.JPanel useGaussian_panel;
  public javax.swing.JRadioButton useGaussian;
  public javax.swing.JPanel n_histo_panel;
  public javax.swing.JLabel n_histo_label;
  public javax.swing.JTextField n_histo;
  public javax.swing.JPanel DeltaDx_panel;
  public javax.swing.JLabel DeltaDx_label;
  public javax.swing.JTextField DeltaDx;
  public javax.swing.JPanel DeltaDy_panel;
  public javax.swing.JLabel DeltaDy_label;
  public javax.swing.JTextField DeltaDy;
  public javax.swing.JSeparator panel_diff_separator;
  public javax.swing.JPanel panel_graph_diff;
  public org.opensourcephysics.drawing2d.PlottingPanel2D Diffusion;
  public org.opensourcephysics.displayejs.InteractiveTrace countx;
  public org.opensourcephysics.displayejs.InteractiveTrace county;
  public javax.swing.JPanel Optical_panel;
  public javax.swing.JPanel panel_data_k;
  public javax.swing.JLabel panel_data_k_title;
  public javax.swing.JPanel usek_panel;
  public javax.swing.JRadioButton usek;
  public javax.swing.JPanel n_histo_k_panel;
  public javax.swing.JLabel n_histo_label2;
  public javax.swing.JTextField n_histo2;
  public javax.swing.JPanel Deltakx_panel;
  public javax.swing.JLabel Deltakx_label;
  public javax.swing.JTextField Deltakx;
  public javax.swing.JPanel Deltaky_panel;
  public javax.swing.JLabel Deltaky_label;
  public javax.swing.JTextField Deltaky;
  public javax.swing.JSeparator panel_diff_separator2;
  public javax.swing.JPanel panel_graph_k;
  public org.opensourcephysics.drawing2d.PlottingPanel2D Potential;
  public org.opensourcephysics.displayejs.InteractiveTrace x;
  public org.opensourcephysics.displayejs.InteractiveTrace y;
  public javax.swing.JPanel Particles_panel;
  public javax.swing.JPanel panel_XY;
  public javax.swing.JPanel paneltitle;
  public javax.swing.JLabel particletitle;
  public javax.swing.JPanel sep_panel;
  public javax.swing.JLabel etiqueta;
  public javax.swing.JTextField particlenumber;
  public javax.swing.JButton boton;
  public org.opensourcephysics.drawing2d.PlottingPanel2D one_particle_xy;
  public org.opensourcephysics.displayejs.InteractiveTrace x_y;
  public javax.swing.JPanel panel_n;
  public org.opensourcephysics.drawing2d.PlottingPanel2D Particles;
  public org.opensourcephysics.displayejs.InteractiveTrace n;
  public org.opensourcephysics.displayejs.InteractiveTrace ndentro;

  // private variables to block changes in the view variables:
  private boolean __n_canBeChanged__ = true; // Variables.Particles:1
  private boolean __narray_canBeChanged__ = true; // Variables.Particles:2
  private boolean __diameter_c_canBeChanged__ = true; // Variables.Particles:3
  private boolean __d_real_canBeChanged__ = true; // Variables.Particles:4
  private boolean __diameter_canBeChanged__ = true; // Variables.Particles:5
  private boolean __vx_0_canBeChanged__ = true; // Variables.Particles:6
  private boolean __vy_0_canBeChanged__ = true; // Variables.Particles:7
  private boolean __x_canBeChanged__ = true; // Variables.Particles:8
  private boolean __x_0_canBeChanged__ = true; // Variables.Particles:9
  private boolean __x_prev_canBeChanged__ = true; // Variables.Particles:10
  private boolean __vx_canBeChanged__ = true; // Variables.Particles:11
  private boolean __y_0_canBeChanged__ = true; // Variables.Particles:12
  private boolean __y_prev_canBeChanged__ = true; // Variables.Particles:13
  private boolean __y_canBeChanged__ = true; // Variables.Particles:14
  private boolean __vy_canBeChanged__ = true; // Variables.Particles:15
  private boolean __microns_canBeChanged__ = true; // Variables.Particles:16
  private boolean __a_canBeChanged__ = true; // Variables.Particles:17
  private boolean __a_real_canBeChanged__ = true; // Variables.Particles:18
  private boolean __f_p_canBeChanged__ = true; // Variables.Particles:19
  private boolean __if_p_canBeChanged__ = true; // Variables.Particles:20
  private boolean __eta0_canBeChanged__ = true; // Variables.Particles:21
  private boolean __eta_canBeChanged__ = true; // Variables.Particles:22
  private boolean __T_canBeChanged__ = true; // Variables.Particles:23
  private boolean __K_B_canBeChanged__ = true; // Variables.Particles:24
  private boolean __D_canBeChanged__ = true; // Variables.Particles:25
  private boolean __chi_canBeChanged__ = true; // Variables.Particles:26
  private boolean __bUseWater_canBeChanged__ = true; // Variables.Particles:27
  private boolean __arraylist_Strings_canBeChanged__ = true; // Variables.Particles:28
  private boolean __arraylist_StringsStats_canBeChanged__ = true; // Variables.Particles:29
  private boolean __count_images_canBeChanged__ = true; // Variables.Particles:30
  private boolean __count_images_total_canBeChanged__ = true; // Variables.Particles:31
  private boolean __count_images_dt_canBeChanged__ = true; // Variables.Particles:32
  private boolean __count_images_dt_total_canBeChanged__ = true; // Variables.Particles:33
  private boolean __checker_t_canBeChanged__ = true; // Variables.Particles:34
  private boolean __xmin_canBeChanged__ = true; // Variables.Common:1
  private boolean __xmax_canBeChanged__ = true; // Variables.Common:2
  private boolean __ymin_canBeChanged__ = true; // Variables.Common:3
  private boolean __ymax_canBeChanged__ = true; // Variables.Common:4
  private boolean __t_canBeChanged__ = true; // Variables.Common:5
  private boolean __dt_canBeChanged__ = true; // Variables.Common:6
  private boolean __tmax_canBeChanged__ = true; // Variables.Common:7
  private boolean __textra_canBeChanged__ = true; // Variables.Common:8
  private boolean __numberOfSteps_canBeChanged__ = true; // Variables.Common:9
  private boolean __limitOfSteps_canBeChanged__ = true; // Variables.Common:10
  private boolean __dMaxTime_canBeChanged__ = true; // Variables.Common:11
  private boolean __dTimeMaxImposed_canBeChanged__ = true; // Variables.Common:12
  private boolean __dtInTxt_canBeChanged__ = true; // Variables.Common:13
  private boolean __bDtInTxt_canBeChanged__ = true; // Variables.Common:14
  private boolean __bSaveDataAuto_canBeChanged__ = true; // Variables.Common:15
  private boolean __iNumLogSave_canBeChanged__ = true; // Variables.Common:16
  private boolean __ep_canBeChanged__ = true; // Variables.Common:17
  private boolean __ed_canBeChanged__ = true; // Variables.Common:18
  private boolean __sFileName_canBeChanged__ = true; // Variables.Common:19
  private boolean __sDirectoryName_canBeChanged__ = true; // Variables.Common:20
  private boolean __sInputFileName_canBeChanged__ = true; // Variables.Common:21
  private boolean __sReadInputFilePath_canBeChanged__ = true; // Variables.Common:22
  private boolean __sReadFilePath_canBeChanged__ = true; // Variables.Common:23
  private boolean __bexclusion1k_canBeChanged__ = true; // Variables.Common:24
  private boolean __Dreal_canBeChanged__ = true; // Variables.Common:25
  private boolean __phi_2D_canBeChanged__ = true; // Variables.Common:26
  private boolean __bIncludeLabelDisk_canBeChanged__ = true; // Variables.Common:27
  private boolean __TOLERANCE_canBeChanged__ = true; // Variables.Events:1
  private boolean __bUseCyclicContour_canBeChanged__ = true; // Variables.Events:2
  private boolean __bUseWallForces_canBeChanged__ = true; // Variables.Events:3
  private boolean __bUseNoContour_canBeChanged__ = true; // Variables.Events:4
  private boolean __nInside_canBeChanged__ = true; // Variables.Events:5
  private boolean __tSave_canBeChanged__ = true; // Variables.Events:6
  private boolean __bSeparateDisks_canBeChanged__ = true; // Variables.Events:7
  private boolean __bUseDiskForce_canBeChanged__ = true; // Variables.Events:8
  private boolean __bUseOpticalForce_canBeChanged__ = true; // Variables.Events:9
  private boolean __diam_reduction_canBeChanged__ = true; // Variables.Events:10
  private boolean __bFreeMode_canBeChanged__ = true; // Variables.Events:11
  private boolean __bReadData_canBeChanged__ = true; // Variables.Events:12
  private boolean __binHistoJumps_canBeChanged__ = true; // Variables.Statistics:1
  private boolean __freqHistoJumps_canBeChanged__ = true; // Variables.Statistics:2
  private boolean __dFreqesp_canBeChanged__ = true; // Variables.Statistics:3
  private boolean __dFreqespOptPot_canBeChanged__ = true; // Variables.Statistics:4
  private boolean __countHistoJumpsX_canBeChanged__ = true; // Variables.Statistics:5
  private boolean __countHistoJumpsY_canBeChanged__ = true; // Variables.Statistics:6
  private boolean __bDoHistoJumps_canBeChanged__ = true; // Variables.Statistics:7
  private boolean __DHistoJumpsX_canBeChanged__ = true; // Variables.Statistics:8
  private boolean __DHistoJumpsY_canBeChanged__ = true; // Variables.Statistics:9
  private boolean __freqHistoOptPot_canBeChanged__ = true; // Variables.Statistics:10
  private boolean __countHistoOptPotX_canBeChanged__ = true; // Variables.Statistics:11
  private boolean __countHistoOptPotY_canBeChanged__ = true; // Variables.Statistics:12
  private boolean __bDoHistoOptPot_canBeChanged__ = true; // Variables.Statistics:13
  private boolean __kHistoOptPotX_canBeChanged__ = true; // Variables.Statistics:14
  private boolean __kHistoOptPotY_canBeChanged__ = true; // Variables.Statistics:15
  private boolean __particleXYexample_canBeChanged__ = true; // Variables.Statistics:16
  private boolean __particleXYexample2_canBeChanged__ = true; // Variables.Statistics:17
  private boolean __cte_f_exclusion_canBeChanged__ = true; // Variables.Potentials:1
  private boolean __cte_diffusion_canBeChanged__ = true; // Variables.Potentials:2
  private boolean __bAOmodel_canBeChanged__ = true; // Variables.Potentials:3
  private boolean __Rg_canBeChanged__ = true; // Variables.Potentials:4
  private boolean __cteAOennp_canBeChanged__ = true; // Variables.Potentials:5
  private boolean __A0_canBeChanged__ = true; // Variables.Potentials:6
  private boolean __A_canBeChanged__ = true; // Variables.Potentials:7
  private boolean __B_canBeChanged__ = true; // Variables.Potentials:8
  private boolean __bUseExclusionForce_canBeChanged__ = true; // Variables.Potentials:9
  private boolean __bUseHSn12_canBeChanged__ = true; // Variables.Potentials:10
  private boolean __bUseHSn36_canBeChanged__ = true; // Variables.Potentials:11
  private boolean __bUseHSHeyes_canBeChanged__ = true; // Variables.Potentials:12
  private boolean __cteAHSn12_canBeChanged__ = true; // Variables.Potentials:13
  private boolean __cteAHSn36_canBeChanged__ = true; // Variables.Potentials:14
  private boolean __ctekHSHeyes_canBeChanged__ = true; // Variables.Potentials:15
  private boolean __bUseElecAtracPot_canBeChanged__ = true; // Variables.Potentials:16
  private boolean __Zelec_canBeChanged__ = true; // Variables.Potentials:17
  private boolean __lambdaelec_canBeChanged__ = true; // Variables.Potentials:18
  private boolean __kappainvelec_canBeChanged__ = true; // Variables.Potentials:19
  private boolean __qelec_canBeChanged__ = true; // Variables.Potentials:20
  private boolean __k_optics_y_canBeChanged__ = true; // Variables.Potentials:21
  private boolean __k_optics_x_canBeChanged__ = true; // Variables.Potentials:22
  private boolean __cabeceraEstadisticas_canBeChanged__ = true; // Variables.Labels:1
  private boolean __sLabel_canBeChanged__ = true; // Variables.Labels:2
  private boolean __MSG_OPEN_FILE_canBeChanged__ = true; // Variables.Labels:3
  private boolean __MSG_CLOSE_FILE_canBeChanged__ = true; // Variables.Labels:4
  private boolean __MSG_WRITE_FILE_canBeChanged__ = true; // Variables.Labels:5
  private boolean __MSG_WRITE_FILE_ERROR_canBeChanged__ = true; // Variables.Labels:6
  private boolean __MSG_SAVING_ARRAY_canBeChanged__ = true; // Variables.Labels:7
  private boolean __MSG_CLEARING_ARRAY_canBeChanged__ = true; // Variables.Labels:8
  private boolean __TEXT_INPUT_FILE_canBeChanged__ = true; // Variables.Labels:9
  private boolean __TEXT_INPUT_TIMETOTAL_canBeChanged__ = true; // Variables.Labels:10
  private boolean __TEXT_INPUT_DT_canBeChanged__ = true; // Variables.Labels:11
  private boolean __TEXT_INPUT_SEP_canBeChanged__ = true; // Variables.Labels:12
  private boolean __TEXT_INPUT_N_canBeChanged__ = true; // Variables.Labels:13
  private boolean __TEXT_INPUT_RDIAM_canBeChanged__ = true; // Variables.Labels:14
  private boolean __TEXT_INPUT_DIAM_canBeChanged__ = true; // Variables.Labels:15
  private boolean __TEXT_INPUT_CAL_canBeChanged__ = true; // Variables.Labels:16
  private boolean __TEXT_INPUT_CONC_canBeChanged__ = true; // Variables.Labels:17
  private boolean __TEXT_INPUT_T_canBeChanged__ = true; // Variables.Labels:18
  private boolean __TEXT_INPUT_VISCO_canBeChanged__ = true; // Variables.Labels:19
  private boolean __TEXT_INPUT_DIFF_canBeChanged__ = true; // Variables.Labels:20
  private boolean __TEXT_INPUT_RDIFF_canBeChanged__ = true; // Variables.Labels:21
  private boolean __TEXT_INPUT_BOUNDARIES_canBeChanged__ = true; // Variables.Labels:22
  private boolean __TEXT_INPUT_WALLS_canBeChanged__ = true; // Variables.Labels:23
  private boolean __TEXT_INPUT_CTE_canBeChanged__ = true; // Variables.Labels:24
  private boolean __TEXT_INPUT_CYCLIC_canBeChanged__ = true; // Variables.Labels:25
  private boolean __TEXT_INPUT_DISKFORCE_canBeChanged__ = true; // Variables.Labels:26
  private boolean __TEXT_INPUT_EXCLUSION_canBeChanged__ = true; // Variables.Labels:27
  private boolean __TEXT_INPUT_R12_canBeChanged__ = true; // Variables.Labels:28
  private boolean __TEXT_INPUT_R36_canBeChanged__ = true; // Variables.Labels:29
  private boolean __TEXT_INPUT_HEYES_canBeChanged__ = true; // Variables.Labels:30
  private boolean __TEXT_INPUT_DTINTXT_canBeChanged__ = true; // Variables.Labels:31
  private boolean __TEXT_INPUT_OPTICAL_canBeChanged__ = true; // Variables.Labels:32
  private boolean __TEXT_INPUT_KX_canBeChanged__ = true; // Variables.Labels:33
  private boolean __TEXT_INPUT_KY_canBeChanged__ = true; // Variables.Labels:34
  private boolean __TEXT_INPUT_AO_canBeChanged__ = true; // Variables.Labels:35
  private boolean __TEXT_INPUT_RG_canBeChanged__ = true; // Variables.Labels:36
  private boolean __TEXT_INPUT_LONGAOCTE_canBeChanged__ = true; // Variables.Labels:37
  private boolean __TEXT_INPUT_ELECPOT_canBeChanged__ = true; // Variables.Labels:38
  private boolean __TEXT_INPUT_Z_canBeChanged__ = true; // Variables.Labels:39
  private boolean __TEXT_INPUT_LAMBDA_canBeChanged__ = true; // Variables.Labels:40
  private boolean __TEXT_INPUT_KAPPA_canBeChanged__ = true; // Variables.Labels:41
  private boolean __TEXT_INPUT_Q_canBeChanged__ = true; // Variables.Labels:42
  private boolean __MSG_WRITE_INPUT_FILE_canBeChanged__ = true; // Variables.Labels:43

// ---------- Class constructor -------------------

  public Brownian_disks_lab_v1_1View (Brownian_disks_lab_v1_1Simulation _sim, String _replaceName, java.awt.Frame _replaceOwnerFrame) {
    super(_sim,_replaceName,_replaceOwnerFrame);
    _simulation = _sim;
    _model = (Brownian_disks_lab_v1_1) _sim.getModel();
    _model._view = this;
    addTarget("_simulation",_simulation);
    addTarget("_model",_model);
    _model._resetModel();
    initialize();
    setUpdateSimulation(false);
    // The following is used by the JNLP file for the simulation to help find resources
    try { setUserCodebase(new java.net.URL(System.getProperty("jnlp.codebase"))); }
    catch (Exception exc) { } // Do nothing and keep quiet if it fails
    update();
    if (javax.swing.SwingUtilities.isEventDispatchThread()) createControl();
    else try {
      javax.swing.SwingUtilities.invokeAndWait(new Runnable() {
        public void run () { 
          createControl();
        }
      });
    } catch (java.lang.reflect.InvocationTargetException it_exc) { it_exc.printStackTrace(); 
    } catch (InterruptedException i_exc) { i_exc.printStackTrace(); };
    addElementsMenuEntries();
    update();
    setUpdateSimulation(true);
    addListener("n"); // Variables.Particles:1
    addListener("narray"); // Variables.Particles:2
    addListener("diameter_c"); // Variables.Particles:3
    addListener("d_real"); // Variables.Particles:4
    addListener("diameter"); // Variables.Particles:5
    addListener("vx_0"); // Variables.Particles:6
    addListener("vy_0"); // Variables.Particles:7
    addListener("x"); // Variables.Particles:8
    addListener("x_0"); // Variables.Particles:9
    addListener("x_prev"); // Variables.Particles:10
    addListener("vx"); // Variables.Particles:11
    addListener("y_0"); // Variables.Particles:12
    addListener("y_prev"); // Variables.Particles:13
    addListener("y"); // Variables.Particles:14
    addListener("vy"); // Variables.Particles:15
    addListener("microns"); // Variables.Particles:16
    addListener("a"); // Variables.Particles:17
    addListener("a_real"); // Variables.Particles:18
    addListener("f_p"); // Variables.Particles:19
    addListener("if_p"); // Variables.Particles:20
    addListener("eta0"); // Variables.Particles:21
    addListener("eta"); // Variables.Particles:22
    addListener("T"); // Variables.Particles:23
    addListener("K_B"); // Variables.Particles:24
    addListener("D"); // Variables.Particles:25
    addListener("chi"); // Variables.Particles:26
    addListener("bUseWater"); // Variables.Particles:27
    addListener("arraylist_Strings"); // Variables.Particles:28
    addListener("arraylist_StringsStats"); // Variables.Particles:29
    addListener("count_images"); // Variables.Particles:30
    addListener("count_images_total"); // Variables.Particles:31
    addListener("count_images_dt"); // Variables.Particles:32
    addListener("count_images_dt_total"); // Variables.Particles:33
    addListener("checker_t"); // Variables.Particles:34
    addListener("xmin"); // Variables.Common:1
    addListener("xmax"); // Variables.Common:2
    addListener("ymin"); // Variables.Common:3
    addListener("ymax"); // Variables.Common:4
    addListener("t"); // Variables.Common:5
    addListener("dt"); // Variables.Common:6
    addListener("tmax"); // Variables.Common:7
    addListener("textra"); // Variables.Common:8
    addListener("numberOfSteps"); // Variables.Common:9
    addListener("limitOfSteps"); // Variables.Common:10
    addListener("dMaxTime"); // Variables.Common:11
    addListener("dTimeMaxImposed"); // Variables.Common:12
    addListener("dtInTxt"); // Variables.Common:13
    addListener("bDtInTxt"); // Variables.Common:14
    addListener("bSaveDataAuto"); // Variables.Common:15
    addListener("iNumLogSave"); // Variables.Common:16
    addListener("ep"); // Variables.Common:17
    addListener("ed"); // Variables.Common:18
    addListener("sFileName"); // Variables.Common:19
    addListener("sDirectoryName"); // Variables.Common:20
    addListener("sInputFileName"); // Variables.Common:21
    addListener("sReadInputFilePath"); // Variables.Common:22
    addListener("sReadFilePath"); // Variables.Common:23
    addListener("bexclusion1k"); // Variables.Common:24
    addListener("Dreal"); // Variables.Common:25
    addListener("phi_2D"); // Variables.Common:26
    addListener("bIncludeLabelDisk"); // Variables.Common:27
    addListener("TOLERANCE"); // Variables.Events:1
    addListener("bUseCyclicContour"); // Variables.Events:2
    addListener("bUseWallForces"); // Variables.Events:3
    addListener("bUseNoContour"); // Variables.Events:4
    addListener("nInside"); // Variables.Events:5
    addListener("tSave"); // Variables.Events:6
    addListener("bSeparateDisks"); // Variables.Events:7
    addListener("bUseDiskForce"); // Variables.Events:8
    addListener("bUseOpticalForce"); // Variables.Events:9
    addListener("diam_reduction"); // Variables.Events:10
    addListener("bFreeMode"); // Variables.Events:11
    addListener("bReadData"); // Variables.Events:12
    addListener("binHistoJumps"); // Variables.Statistics:1
    addListener("freqHistoJumps"); // Variables.Statistics:2
    addListener("dFreqesp"); // Variables.Statistics:3
    addListener("dFreqespOptPot"); // Variables.Statistics:4
    addListener("countHistoJumpsX"); // Variables.Statistics:5
    addListener("countHistoJumpsY"); // Variables.Statistics:6
    addListener("bDoHistoJumps"); // Variables.Statistics:7
    addListener("DHistoJumpsX"); // Variables.Statistics:8
    addListener("DHistoJumpsY"); // Variables.Statistics:9
    addListener("freqHistoOptPot"); // Variables.Statistics:10
    addListener("countHistoOptPotX"); // Variables.Statistics:11
    addListener("countHistoOptPotY"); // Variables.Statistics:12
    addListener("bDoHistoOptPot"); // Variables.Statistics:13
    addListener("kHistoOptPotX"); // Variables.Statistics:14
    addListener("kHistoOptPotY"); // Variables.Statistics:15
    addListener("particleXYexample"); // Variables.Statistics:16
    addListener("particleXYexample2"); // Variables.Statistics:17
    addListener("cte_f_exclusion"); // Variables.Potentials:1
    addListener("cte_diffusion"); // Variables.Potentials:2
    addListener("bAOmodel"); // Variables.Potentials:3
    addListener("Rg"); // Variables.Potentials:4
    addListener("cteAOennp"); // Variables.Potentials:5
    addListener("A0"); // Variables.Potentials:6
    addListener("A"); // Variables.Potentials:7
    addListener("B"); // Variables.Potentials:8
    addListener("bUseExclusionForce"); // Variables.Potentials:9
    addListener("bUseHSn12"); // Variables.Potentials:10
    addListener("bUseHSn36"); // Variables.Potentials:11
    addListener("bUseHSHeyes"); // Variables.Potentials:12
    addListener("cteAHSn12"); // Variables.Potentials:13
    addListener("cteAHSn36"); // Variables.Potentials:14
    addListener("ctekHSHeyes"); // Variables.Potentials:15
    addListener("bUseElecAtracPot"); // Variables.Potentials:16
    addListener("Zelec"); // Variables.Potentials:17
    addListener("lambdaelec"); // Variables.Potentials:18
    addListener("kappainvelec"); // Variables.Potentials:19
    addListener("qelec"); // Variables.Potentials:20
    addListener("k_optics_y"); // Variables.Potentials:21
    addListener("k_optics_x"); // Variables.Potentials:22
    addListener("cabeceraEstadisticas"); // Variables.Labels:1
    addListener("sLabel"); // Variables.Labels:2
    addListener("MSG_OPEN_FILE"); // Variables.Labels:3
    addListener("MSG_CLOSE_FILE"); // Variables.Labels:4
    addListener("MSG_WRITE_FILE"); // Variables.Labels:5
    addListener("MSG_WRITE_FILE_ERROR"); // Variables.Labels:6
    addListener("MSG_SAVING_ARRAY"); // Variables.Labels:7
    addListener("MSG_CLEARING_ARRAY"); // Variables.Labels:8
    addListener("TEXT_INPUT_FILE"); // Variables.Labels:9
    addListener("TEXT_INPUT_TIMETOTAL"); // Variables.Labels:10
    addListener("TEXT_INPUT_DT"); // Variables.Labels:11
    addListener("TEXT_INPUT_SEP"); // Variables.Labels:12
    addListener("TEXT_INPUT_N"); // Variables.Labels:13
    addListener("TEXT_INPUT_RDIAM"); // Variables.Labels:14
    addListener("TEXT_INPUT_DIAM"); // Variables.Labels:15
    addListener("TEXT_INPUT_CAL"); // Variables.Labels:16
    addListener("TEXT_INPUT_CONC"); // Variables.Labels:17
    addListener("TEXT_INPUT_T"); // Variables.Labels:18
    addListener("TEXT_INPUT_VISCO"); // Variables.Labels:19
    addListener("TEXT_INPUT_DIFF"); // Variables.Labels:20
    addListener("TEXT_INPUT_RDIFF"); // Variables.Labels:21
    addListener("TEXT_INPUT_BOUNDARIES"); // Variables.Labels:22
    addListener("TEXT_INPUT_WALLS"); // Variables.Labels:23
    addListener("TEXT_INPUT_CTE"); // Variables.Labels:24
    addListener("TEXT_INPUT_CYCLIC"); // Variables.Labels:25
    addListener("TEXT_INPUT_DISKFORCE"); // Variables.Labels:26
    addListener("TEXT_INPUT_EXCLUSION"); // Variables.Labels:27
    addListener("TEXT_INPUT_R12"); // Variables.Labels:28
    addListener("TEXT_INPUT_R36"); // Variables.Labels:29
    addListener("TEXT_INPUT_HEYES"); // Variables.Labels:30
    addListener("TEXT_INPUT_DTINTXT"); // Variables.Labels:31
    addListener("TEXT_INPUT_OPTICAL"); // Variables.Labels:32
    addListener("TEXT_INPUT_KX"); // Variables.Labels:33
    addListener("TEXT_INPUT_KY"); // Variables.Labels:34
    addListener("TEXT_INPUT_AO"); // Variables.Labels:35
    addListener("TEXT_INPUT_RG"); // Variables.Labels:36
    addListener("TEXT_INPUT_LONGAOCTE"); // Variables.Labels:37
    addListener("TEXT_INPUT_ELECPOT"); // Variables.Labels:38
    addListener("TEXT_INPUT_Z"); // Variables.Labels:39
    addListener("TEXT_INPUT_LAMBDA"); // Variables.Labels:40
    addListener("TEXT_INPUT_KAPPA"); // Variables.Labels:41
    addListener("TEXT_INPUT_Q"); // Variables.Labels:42
    addListener("MSG_WRITE_INPUT_FILE"); // Variables.Labels:43
  }

// ---------- Implementation of View -------------------

  public void read() {
    // Ejs requires no read(). Actually, having it might cause problems!
  }

  @SuppressWarnings("unchecked")
  public void read(String _variable) {
    if ("n".equals(_variable)) {
      _model.n = getInt("n"); // Variables.Particles:1
      __n_canBeChanged__ = true;
    }
    if ("narray".equals(_variable)) {
      _model.narray = getDouble("narray"); // Variables.Particles:2
      __narray_canBeChanged__ = true;
    }
    if ("diameter_c".equals(_variable)) {
      _model.diameter_c = getDouble("diameter_c"); // Variables.Particles:3
      __diameter_c_canBeChanged__ = true;
    }
    if ("d_real".equals(_variable)) {
      _model.d_real = getDouble("d_real"); // Variables.Particles:4
      __d_real_canBeChanged__ = true;
    }
    if ("diameter".equals(_variable)) {
      double[] _data = (double[]) getValue("diameter").getObject();
      int _n0 = _data.length;
      if (_n0>_model.diameter.length) _n0 = _model.diameter.length;
      for (int _i0=0; _i0<_n0; _i0++) {
        _model.diameter[_i0] = _data[_i0];
      }
      __diameter_canBeChanged__ = true;
    }
    if ("vx_0".equals(_variable)) {
      _model.vx_0 = getDouble("vx_0"); // Variables.Particles:6
      __vx_0_canBeChanged__ = true;
    }
    if ("vy_0".equals(_variable)) {
      _model.vy_0 = getDouble("vy_0"); // Variables.Particles:7
      __vy_0_canBeChanged__ = true;
    }
    if ("x".equals(_variable)) {
      double[] _data = (double[]) getValue("x").getObject();
      int _n0 = _data.length;
      if (_n0>_model.x.length) _n0 = _model.x.length;
      for (int _i0=0; _i0<_n0; _i0++) {
        _model.x[_i0] = _data[_i0];
      }
      __x_canBeChanged__ = true;
    }
    if ("x_0".equals(_variable)) {
      double[] _data = (double[]) getValue("x_0").getObject();
      int _n0 = _data.length;
      if (_n0>_model.x_0.length) _n0 = _model.x_0.length;
      for (int _i0=0; _i0<_n0; _i0++) {
        _model.x_0[_i0] = _data[_i0];
      }
      __x_0_canBeChanged__ = true;
    }
    if ("x_prev".equals(_variable)) {
      double[] _data = (double[]) getValue("x_prev").getObject();
      int _n0 = _data.length;
      if (_n0>_model.x_prev.length) _n0 = _model.x_prev.length;
      for (int _i0=0; _i0<_n0; _i0++) {
        _model.x_prev[_i0] = _data[_i0];
      }
      __x_prev_canBeChanged__ = true;
    }
    if ("vx".equals(_variable)) {
      double[] _data = (double[]) getValue("vx").getObject();
      int _n0 = _data.length;
      if (_n0>_model.vx.length) _n0 = _model.vx.length;
      for (int _i0=0; _i0<_n0; _i0++) {
        _model.vx[_i0] = _data[_i0];
      }
      __vx_canBeChanged__ = true;
    }
    if ("y_0".equals(_variable)) {
      double[] _data = (double[]) getValue("y_0").getObject();
      int _n0 = _data.length;
      if (_n0>_model.y_0.length) _n0 = _model.y_0.length;
      for (int _i0=0; _i0<_n0; _i0++) {
        _model.y_0[_i0] = _data[_i0];
      }
      __y_0_canBeChanged__ = true;
    }
    if ("y_prev".equals(_variable)) {
      double[] _data = (double[]) getValue("y_prev").getObject();
      int _n0 = _data.length;
      if (_n0>_model.y_prev.length) _n0 = _model.y_prev.length;
      for (int _i0=0; _i0<_n0; _i0++) {
        _model.y_prev[_i0] = _data[_i0];
      }
      __y_prev_canBeChanged__ = true;
    }
    if ("y".equals(_variable)) {
      double[] _data = (double[]) getValue("y").getObject();
      int _n0 = _data.length;
      if (_n0>_model.y.length) _n0 = _model.y.length;
      for (int _i0=0; _i0<_n0; _i0++) {
        _model.y[_i0] = _data[_i0];
      }
      __y_canBeChanged__ = true;
    }
    if ("vy".equals(_variable)) {
      double[] _data = (double[]) getValue("vy").getObject();
      int _n0 = _data.length;
      if (_n0>_model.vy.length) _n0 = _model.vy.length;
      for (int _i0=0; _i0<_n0; _i0++) {
        _model.vy[_i0] = _data[_i0];
      }
      __vy_canBeChanged__ = true;
    }
    if ("microns".equals(_variable)) {
      _model.microns = getDouble("microns"); // Variables.Particles:16
      __microns_canBeChanged__ = true;
    }
    if ("a".equals(_variable)) {
      _model.a = getDouble("a"); // Variables.Particles:17
      __a_canBeChanged__ = true;
    }
    if ("a_real".equals(_variable)) {
      _model.a_real = getDouble("a_real"); // Variables.Particles:18
      __a_real_canBeChanged__ = true;
    }
    if ("f_p".equals(_variable)) {
      _model.f_p = getDouble("f_p"); // Variables.Particles:19
      __f_p_canBeChanged__ = true;
    }
    if ("if_p".equals(_variable)) {
      _model.if_p = getDouble("if_p"); // Variables.Particles:20
      __if_p_canBeChanged__ = true;
    }
    if ("eta0".equals(_variable)) {
      _model.eta0 = getDouble("eta0"); // Variables.Particles:21
      __eta0_canBeChanged__ = true;
    }
    if ("eta".equals(_variable)) {
      _model.eta = getDouble("eta"); // Variables.Particles:22
      __eta_canBeChanged__ = true;
    }
    if ("T".equals(_variable)) {
      _model.T = getDouble("T"); // Variables.Particles:23
      __T_canBeChanged__ = true;
    }
    if ("K_B".equals(_variable)) {
      _model.K_B = getDouble("K_B"); // Variables.Particles:24
      __K_B_canBeChanged__ = true;
    }
    if ("D".equals(_variable)) {
      _model.D = getDouble("D"); // Variables.Particles:25
      __D_canBeChanged__ = true;
    }
    if ("chi".equals(_variable)) {
      _model.chi = getDouble("chi"); // Variables.Particles:26
      __chi_canBeChanged__ = true;
    }
    if ("bUseWater".equals(_variable)) {
      _model.bUseWater = getBoolean("bUseWater"); // Variables.Particles:27
      __bUseWater_canBeChanged__ = true;
    }
    if ("arraylist_Strings".equals(_variable)) {
      _model.arraylist_Strings = (ArrayList) getObject("arraylist_Strings"); // Variables.Particles:28
      __arraylist_Strings_canBeChanged__ = true;
    }
    if ("arraylist_StringsStats".equals(_variable)) {
      _model.arraylist_StringsStats = (ArrayList) getObject("arraylist_StringsStats"); // Variables.Particles:29
      __arraylist_StringsStats_canBeChanged__ = true;
    }
    if ("count_images".equals(_variable)) {
      _model.count_images = getInt("count_images"); // Variables.Particles:30
      __count_images_canBeChanged__ = true;
    }
    if ("count_images_total".equals(_variable)) {
      _model.count_images_total = getInt("count_images_total"); // Variables.Particles:31
      __count_images_total_canBeChanged__ = true;
    }
    if ("count_images_dt".equals(_variable)) {
      _model.count_images_dt = getInt("count_images_dt"); // Variables.Particles:32
      __count_images_dt_canBeChanged__ = true;
    }
    if ("count_images_dt_total".equals(_variable)) {
      _model.count_images_dt_total = getInt("count_images_dt_total"); // Variables.Particles:33
      __count_images_dt_total_canBeChanged__ = true;
    }
    if ("checker_t".equals(_variable)) {
      _model.checker_t = getDouble("checker_t"); // Variables.Particles:34
      __checker_t_canBeChanged__ = true;
    }
    if ("xmin".equals(_variable)) {
      _model.xmin = getDouble("xmin"); // Variables.Common:1
      __xmin_canBeChanged__ = true;
    }
    if ("xmax".equals(_variable)) {
      _model.xmax = getDouble("xmax"); // Variables.Common:2
      __xmax_canBeChanged__ = true;
    }
    if ("ymin".equals(_variable)) {
      _model.ymin = getDouble("ymin"); // Variables.Common:3
      __ymin_canBeChanged__ = true;
    }
    if ("ymax".equals(_variable)) {
      _model.ymax = getDouble("ymax"); // Variables.Common:4
      __ymax_canBeChanged__ = true;
    }
    if ("t".equals(_variable)) {
      _model.t = getDouble("t"); // Variables.Common:5
      __t_canBeChanged__ = true;
    }
    if ("dt".equals(_variable)) {
      _model.dt = getDouble("dt"); // Variables.Common:6
      __dt_canBeChanged__ = true;
    }
    if ("tmax".equals(_variable)) {
      _model.tmax = getDouble("tmax"); // Variables.Common:7
      __tmax_canBeChanged__ = true;
    }
    if ("textra".equals(_variable)) {
      _model.textra = getDouble("textra"); // Variables.Common:8
      __textra_canBeChanged__ = true;
    }
    if ("numberOfSteps".equals(_variable)) {
      _model.numberOfSteps = getDouble("numberOfSteps"); // Variables.Common:9
      __numberOfSteps_canBeChanged__ = true;
    }
    if ("limitOfSteps".equals(_variable)) {
      _model.limitOfSteps = getDouble("limitOfSteps"); // Variables.Common:10
      __limitOfSteps_canBeChanged__ = true;
    }
    if ("dMaxTime".equals(_variable)) {
      _model.dMaxTime = getDouble("dMaxTime"); // Variables.Common:11
      __dMaxTime_canBeChanged__ = true;
    }
    if ("dTimeMaxImposed".equals(_variable)) {
      _model.dTimeMaxImposed = getDouble("dTimeMaxImposed"); // Variables.Common:12
      __dTimeMaxImposed_canBeChanged__ = true;
    }
    if ("dtInTxt".equals(_variable)) {
      _model.dtInTxt = getDouble("dtInTxt"); // Variables.Common:13
      __dtInTxt_canBeChanged__ = true;
    }
    if ("bDtInTxt".equals(_variable)) {
      _model.bDtInTxt = getBoolean("bDtInTxt"); // Variables.Common:14
      __bDtInTxt_canBeChanged__ = true;
    }
    if ("bSaveDataAuto".equals(_variable)) {
      _model.bSaveDataAuto = getBoolean("bSaveDataAuto"); // Variables.Common:15
      __bSaveDataAuto_canBeChanged__ = true;
    }
    if ("iNumLogSave".equals(_variable)) {
      _model.iNumLogSave = getInt("iNumLogSave"); // Variables.Common:16
      __iNumLogSave_canBeChanged__ = true;
    }
    if ("ep".equals(_variable)) {
      _model.ep = getDouble("ep"); // Variables.Common:17
      __ep_canBeChanged__ = true;
    }
    if ("ed".equals(_variable)) {
      _model.ed = getDouble("ed"); // Variables.Common:18
      __ed_canBeChanged__ = true;
    }
    if ("sFileName".equals(_variable)) {
      _model.sFileName = getString("sFileName"); // Variables.Common:19
      __sFileName_canBeChanged__ = true;
    }
    if ("sDirectoryName".equals(_variable)) {
      _model.sDirectoryName = getString("sDirectoryName"); // Variables.Common:20
      __sDirectoryName_canBeChanged__ = true;
    }
    if ("sInputFileName".equals(_variable)) {
      _model.sInputFileName = getString("sInputFileName"); // Variables.Common:21
      __sInputFileName_canBeChanged__ = true;
    }
    if ("sReadInputFilePath".equals(_variable)) {
      _model.sReadInputFilePath = getString("sReadInputFilePath"); // Variables.Common:22
      __sReadInputFilePath_canBeChanged__ = true;
    }
    if ("sReadFilePath".equals(_variable)) {
      _model.sReadFilePath = getString("sReadFilePath"); // Variables.Common:23
      __sReadFilePath_canBeChanged__ = true;
    }
    if ("bexclusion1k".equals(_variable)) {
      _model.bexclusion1k = getBoolean("bexclusion1k"); // Variables.Common:24
      __bexclusion1k_canBeChanged__ = true;
    }
    if ("Dreal".equals(_variable)) {
      _model.Dreal = getDouble("Dreal"); // Variables.Common:25
      __Dreal_canBeChanged__ = true;
    }
    if ("phi_2D".equals(_variable)) {
      _model.phi_2D = getDouble("phi_2D"); // Variables.Common:26
      __phi_2D_canBeChanged__ = true;
    }
    if ("bIncludeLabelDisk".equals(_variable)) {
      _model.bIncludeLabelDisk = getBoolean("bIncludeLabelDisk"); // Variables.Common:27
      __bIncludeLabelDisk_canBeChanged__ = true;
    }
    if ("TOLERANCE".equals(_variable)) {
      _model.TOLERANCE = getDouble("TOLERANCE"); // Variables.Events:1
      __TOLERANCE_canBeChanged__ = true;
    }
    if ("bUseCyclicContour".equals(_variable)) {
      _model.bUseCyclicContour = getBoolean("bUseCyclicContour"); // Variables.Events:2
      __bUseCyclicContour_canBeChanged__ = true;
    }
    if ("bUseWallForces".equals(_variable)) {
      _model.bUseWallForces = getBoolean("bUseWallForces"); // Variables.Events:3
      __bUseWallForces_canBeChanged__ = true;
    }
    if ("bUseNoContour".equals(_variable)) {
      _model.bUseNoContour = getBoolean("bUseNoContour"); // Variables.Events:4
      __bUseNoContour_canBeChanged__ = true;
    }
    if ("nInside".equals(_variable)) {
      _model.nInside = getInt("nInside"); // Variables.Events:5
      __nInside_canBeChanged__ = true;
    }
    if ("tSave".equals(_variable)) {
      _model.tSave = getDouble("tSave"); // Variables.Events:6
      __tSave_canBeChanged__ = true;
    }
    if ("bSeparateDisks".equals(_variable)) {
      _model.bSeparateDisks = getBoolean("bSeparateDisks"); // Variables.Events:7
      __bSeparateDisks_canBeChanged__ = true;
    }
    if ("bUseDiskForce".equals(_variable)) {
      _model.bUseDiskForce = getBoolean("bUseDiskForce"); // Variables.Events:8
      __bUseDiskForce_canBeChanged__ = true;
    }
    if ("bUseOpticalForce".equals(_variable)) {
      _model.bUseOpticalForce = getBoolean("bUseOpticalForce"); // Variables.Events:9
      __bUseOpticalForce_canBeChanged__ = true;
    }
    if ("diam_reduction".equals(_variable)) {
      _model.diam_reduction = getDouble("diam_reduction"); // Variables.Events:10
      __diam_reduction_canBeChanged__ = true;
    }
    if ("bFreeMode".equals(_variable)) {
      _model.bFreeMode = getBoolean("bFreeMode"); // Variables.Events:11
      __bFreeMode_canBeChanged__ = true;
    }
    if ("bReadData".equals(_variable)) {
      _model.bReadData = getBoolean("bReadData"); // Variables.Events:12
      __bReadData_canBeChanged__ = true;
    }
    if ("binHistoJumps".equals(_variable)) {
      _model.binHistoJumps = getInt("binHistoJumps"); // Variables.Statistics:1
      __binHistoJumps_canBeChanged__ = true;
    }
    if ("freqHistoJumps".equals(_variable)) {
      double[] _data = (double[]) getValue("freqHistoJumps").getObject();
      int _n0 = _data.length;
      if (_n0>_model.freqHistoJumps.length) _n0 = _model.freqHistoJumps.length;
      for (int _i0=0; _i0<_n0; _i0++) {
        _model.freqHistoJumps[_i0] = _data[_i0];
      }
      __freqHistoJumps_canBeChanged__ = true;
    }
    if ("dFreqesp".equals(_variable)) {
      _model.dFreqesp = getDouble("dFreqesp"); // Variables.Statistics:3
      __dFreqesp_canBeChanged__ = true;
    }
    if ("dFreqespOptPot".equals(_variable)) {
      _model.dFreqespOptPot = getDouble("dFreqespOptPot"); // Variables.Statistics:4
      __dFreqespOptPot_canBeChanged__ = true;
    }
    if ("countHistoJumpsX".equals(_variable)) {
      double[] _data = (double[]) getValue("countHistoJumpsX").getObject();
      int _n0 = _data.length;
      if (_n0>_model.countHistoJumpsX.length) _n0 = _model.countHistoJumpsX.length;
      for (int _i0=0; _i0<_n0; _i0++) {
        _model.countHistoJumpsX[_i0] = _data[_i0];
      }
      __countHistoJumpsX_canBeChanged__ = true;
    }
    if ("countHistoJumpsY".equals(_variable)) {
      double[] _data = (double[]) getValue("countHistoJumpsY").getObject();
      int _n0 = _data.length;
      if (_n0>_model.countHistoJumpsY.length) _n0 = _model.countHistoJumpsY.length;
      for (int _i0=0; _i0<_n0; _i0++) {
        _model.countHistoJumpsY[_i0] = _data[_i0];
      }
      __countHistoJumpsY_canBeChanged__ = true;
    }
    if ("bDoHistoJumps".equals(_variable)) {
      _model.bDoHistoJumps = getBoolean("bDoHistoJumps"); // Variables.Statistics:7
      __bDoHistoJumps_canBeChanged__ = true;
    }
    if ("DHistoJumpsX".equals(_variable)) {
      _model.DHistoJumpsX = getDouble("DHistoJumpsX"); // Variables.Statistics:8
      __DHistoJumpsX_canBeChanged__ = true;
    }
    if ("DHistoJumpsY".equals(_variable)) {
      _model.DHistoJumpsY = getDouble("DHistoJumpsY"); // Variables.Statistics:9
      __DHistoJumpsY_canBeChanged__ = true;
    }
    if ("freqHistoOptPot".equals(_variable)) {
      double[] _data = (double[]) getValue("freqHistoOptPot").getObject();
      int _n0 = _data.length;
      if (_n0>_model.freqHistoOptPot.length) _n0 = _model.freqHistoOptPot.length;
      for (int _i0=0; _i0<_n0; _i0++) {
        _model.freqHistoOptPot[_i0] = _data[_i0];
      }
      __freqHistoOptPot_canBeChanged__ = true;
    }
    if ("countHistoOptPotX".equals(_variable)) {
      double[] _data = (double[]) getValue("countHistoOptPotX").getObject();
      int _n0 = _data.length;
      if (_n0>_model.countHistoOptPotX.length) _n0 = _model.countHistoOptPotX.length;
      for (int _i0=0; _i0<_n0; _i0++) {
        _model.countHistoOptPotX[_i0] = _data[_i0];
      }
      __countHistoOptPotX_canBeChanged__ = true;
    }
    if ("countHistoOptPotY".equals(_variable)) {
      double[] _data = (double[]) getValue("countHistoOptPotY").getObject();
      int _n0 = _data.length;
      if (_n0>_model.countHistoOptPotY.length) _n0 = _model.countHistoOptPotY.length;
      for (int _i0=0; _i0<_n0; _i0++) {
        _model.countHistoOptPotY[_i0] = _data[_i0];
      }
      __countHistoOptPotY_canBeChanged__ = true;
    }
    if ("bDoHistoOptPot".equals(_variable)) {
      _model.bDoHistoOptPot = getBoolean("bDoHistoOptPot"); // Variables.Statistics:13
      __bDoHistoOptPot_canBeChanged__ = true;
    }
    if ("kHistoOptPotX".equals(_variable)) {
      _model.kHistoOptPotX = getDouble("kHistoOptPotX"); // Variables.Statistics:14
      __kHistoOptPotX_canBeChanged__ = true;
    }
    if ("kHistoOptPotY".equals(_variable)) {
      _model.kHistoOptPotY = getDouble("kHistoOptPotY"); // Variables.Statistics:15
      __kHistoOptPotY_canBeChanged__ = true;
    }
    if ("particleXYexample".equals(_variable)) {
      _model.particleXYexample = getInt("particleXYexample"); // Variables.Statistics:16
      __particleXYexample_canBeChanged__ = true;
    }
    if ("particleXYexample2".equals(_variable)) {
      _model.particleXYexample2 = getInt("particleXYexample2"); // Variables.Statistics:17
      __particleXYexample2_canBeChanged__ = true;
    }
    if ("cte_f_exclusion".equals(_variable)) {
      _model.cte_f_exclusion = getDouble("cte_f_exclusion"); // Variables.Potentials:1
      __cte_f_exclusion_canBeChanged__ = true;
    }
    if ("cte_diffusion".equals(_variable)) {
      _model.cte_diffusion = getDouble("cte_diffusion"); // Variables.Potentials:2
      __cte_diffusion_canBeChanged__ = true;
    }
    if ("bAOmodel".equals(_variable)) {
      _model.bAOmodel = getBoolean("bAOmodel"); // Variables.Potentials:3
      __bAOmodel_canBeChanged__ = true;
    }
    if ("Rg".equals(_variable)) {
      _model.Rg = getDouble("Rg"); // Variables.Potentials:4
      __Rg_canBeChanged__ = true;
    }
    if ("cteAOennp".equals(_variable)) {
      _model.cteAOennp = getDouble("cteAOennp"); // Variables.Potentials:5
      __cteAOennp_canBeChanged__ = true;
    }
    if ("A0".equals(_variable)) {
      _model.A0 = getDouble("A0"); // Variables.Potentials:6
      __A0_canBeChanged__ = true;
    }
    if ("A".equals(_variable)) {
      _model.A = getDouble("A"); // Variables.Potentials:7
      __A_canBeChanged__ = true;
    }
    if ("B".equals(_variable)) {
      _model.B = getDouble("B"); // Variables.Potentials:8
      __B_canBeChanged__ = true;
    }
    if ("bUseExclusionForce".equals(_variable)) {
      _model.bUseExclusionForce = getBoolean("bUseExclusionForce"); // Variables.Potentials:9
      __bUseExclusionForce_canBeChanged__ = true;
    }
    if ("bUseHSn12".equals(_variable)) {
      _model.bUseHSn12 = getBoolean("bUseHSn12"); // Variables.Potentials:10
      __bUseHSn12_canBeChanged__ = true;
    }
    if ("bUseHSn36".equals(_variable)) {
      _model.bUseHSn36 = getBoolean("bUseHSn36"); // Variables.Potentials:11
      __bUseHSn36_canBeChanged__ = true;
    }
    if ("bUseHSHeyes".equals(_variable)) {
      _model.bUseHSHeyes = getBoolean("bUseHSHeyes"); // Variables.Potentials:12
      __bUseHSHeyes_canBeChanged__ = true;
    }
    if ("cteAHSn12".equals(_variable)) {
      _model.cteAHSn12 = getDouble("cteAHSn12"); // Variables.Potentials:13
      __cteAHSn12_canBeChanged__ = true;
    }
    if ("cteAHSn36".equals(_variable)) {
      _model.cteAHSn36 = getDouble("cteAHSn36"); // Variables.Potentials:14
      __cteAHSn36_canBeChanged__ = true;
    }
    if ("ctekHSHeyes".equals(_variable)) {
      _model.ctekHSHeyes = getDouble("ctekHSHeyes"); // Variables.Potentials:15
      __ctekHSHeyes_canBeChanged__ = true;
    }
    if ("bUseElecAtracPot".equals(_variable)) {
      _model.bUseElecAtracPot = getBoolean("bUseElecAtracPot"); // Variables.Potentials:16
      __bUseElecAtracPot_canBeChanged__ = true;
    }
    if ("Zelec".equals(_variable)) {
      _model.Zelec = getDouble("Zelec"); // Variables.Potentials:17
      __Zelec_canBeChanged__ = true;
    }
    if ("lambdaelec".equals(_variable)) {
      _model.lambdaelec = getDouble("lambdaelec"); // Variables.Potentials:18
      __lambdaelec_canBeChanged__ = true;
    }
    if ("kappainvelec".equals(_variable)) {
      _model.kappainvelec = getDouble("kappainvelec"); // Variables.Potentials:19
      __kappainvelec_canBeChanged__ = true;
    }
    if ("qelec".equals(_variable)) {
      _model.qelec = getDouble("qelec"); // Variables.Potentials:20
      __qelec_canBeChanged__ = true;
    }
    if ("k_optics_y".equals(_variable)) {
      _model.k_optics_y = getDouble("k_optics_y"); // Variables.Potentials:21
      __k_optics_y_canBeChanged__ = true;
    }
    if ("k_optics_x".equals(_variable)) {
      _model.k_optics_x = getDouble("k_optics_x"); // Variables.Potentials:22
      __k_optics_x_canBeChanged__ = true;
    }
    if ("cabeceraEstadisticas".equals(_variable)) {
      _model.cabeceraEstadisticas = getString("cabeceraEstadisticas"); // Variables.Labels:1
      __cabeceraEstadisticas_canBeChanged__ = true;
    }
    if ("sLabel".equals(_variable)) {
      _model.sLabel = getString("sLabel"); // Variables.Labels:2
      __sLabel_canBeChanged__ = true;
    }
    if ("MSG_OPEN_FILE".equals(_variable)) {
      _model.MSG_OPEN_FILE = getString("MSG_OPEN_FILE"); // Variables.Labels:3
      __MSG_OPEN_FILE_canBeChanged__ = true;
    }
    if ("MSG_CLOSE_FILE".equals(_variable)) {
      _model.MSG_CLOSE_FILE = getString("MSG_CLOSE_FILE"); // Variables.Labels:4
      __MSG_CLOSE_FILE_canBeChanged__ = true;
    }
    if ("MSG_WRITE_FILE".equals(_variable)) {
      _model.MSG_WRITE_FILE = getString("MSG_WRITE_FILE"); // Variables.Labels:5
      __MSG_WRITE_FILE_canBeChanged__ = true;
    }
    if ("MSG_WRITE_FILE_ERROR".equals(_variable)) {
      _model.MSG_WRITE_FILE_ERROR = getString("MSG_WRITE_FILE_ERROR"); // Variables.Labels:6
      __MSG_WRITE_FILE_ERROR_canBeChanged__ = true;
    }
    if ("MSG_SAVING_ARRAY".equals(_variable)) {
      _model.MSG_SAVING_ARRAY = getString("MSG_SAVING_ARRAY"); // Variables.Labels:7
      __MSG_SAVING_ARRAY_canBeChanged__ = true;
    }
    if ("MSG_CLEARING_ARRAY".equals(_variable)) {
      _model.MSG_CLEARING_ARRAY = getString("MSG_CLEARING_ARRAY"); // Variables.Labels:8
      __MSG_CLEARING_ARRAY_canBeChanged__ = true;
    }
    if ("TEXT_INPUT_FILE".equals(_variable)) {
      _model.TEXT_INPUT_FILE = getString("TEXT_INPUT_FILE"); // Variables.Labels:9
      __TEXT_INPUT_FILE_canBeChanged__ = true;
    }
    if ("TEXT_INPUT_TIMETOTAL".equals(_variable)) {
      _model.TEXT_INPUT_TIMETOTAL = getString("TEXT_INPUT_TIMETOTAL"); // Variables.Labels:10
      __TEXT_INPUT_TIMETOTAL_canBeChanged__ = true;
    }
    if ("TEXT_INPUT_DT".equals(_variable)) {
      _model.TEXT_INPUT_DT = getString("TEXT_INPUT_DT"); // Variables.Labels:11
      __TEXT_INPUT_DT_canBeChanged__ = true;
    }
    if ("TEXT_INPUT_SEP".equals(_variable)) {
      _model.TEXT_INPUT_SEP = getString("TEXT_INPUT_SEP"); // Variables.Labels:12
      __TEXT_INPUT_SEP_canBeChanged__ = true;
    }
    if ("TEXT_INPUT_N".equals(_variable)) {
      _model.TEXT_INPUT_N = getString("TEXT_INPUT_N"); // Variables.Labels:13
      __TEXT_INPUT_N_canBeChanged__ = true;
    }
    if ("TEXT_INPUT_RDIAM".equals(_variable)) {
      _model.TEXT_INPUT_RDIAM = getString("TEXT_INPUT_RDIAM"); // Variables.Labels:14
      __TEXT_INPUT_RDIAM_canBeChanged__ = true;
    }
    if ("TEXT_INPUT_DIAM".equals(_variable)) {
      _model.TEXT_INPUT_DIAM = getString("TEXT_INPUT_DIAM"); // Variables.Labels:15
      __TEXT_INPUT_DIAM_canBeChanged__ = true;
    }
    if ("TEXT_INPUT_CAL".equals(_variable)) {
      _model.TEXT_INPUT_CAL = getString("TEXT_INPUT_CAL"); // Variables.Labels:16
      __TEXT_INPUT_CAL_canBeChanged__ = true;
    }
    if ("TEXT_INPUT_CONC".equals(_variable)) {
      _model.TEXT_INPUT_CONC = getString("TEXT_INPUT_CONC"); // Variables.Labels:17
      __TEXT_INPUT_CONC_canBeChanged__ = true;
    }
    if ("TEXT_INPUT_T".equals(_variable)) {
      _model.TEXT_INPUT_T = getString("TEXT_INPUT_T"); // Variables.Labels:18
      __TEXT_INPUT_T_canBeChanged__ = true;
    }
    if ("TEXT_INPUT_VISCO".equals(_variable)) {
      _model.TEXT_INPUT_VISCO = getString("TEXT_INPUT_VISCO"); // Variables.Labels:19
      __TEXT_INPUT_VISCO_canBeChanged__ = true;
    }
    if ("TEXT_INPUT_DIFF".equals(_variable)) {
      _model.TEXT_INPUT_DIFF = getString("TEXT_INPUT_DIFF"); // Variables.Labels:20
      __TEXT_INPUT_DIFF_canBeChanged__ = true;
    }
    if ("TEXT_INPUT_RDIFF".equals(_variable)) {
      _model.TEXT_INPUT_RDIFF = getString("TEXT_INPUT_RDIFF"); // Variables.Labels:21
      __TEXT_INPUT_RDIFF_canBeChanged__ = true;
    }
    if ("TEXT_INPUT_BOUNDARIES".equals(_variable)) {
      _model.TEXT_INPUT_BOUNDARIES = getString("TEXT_INPUT_BOUNDARIES"); // Variables.Labels:22
      __TEXT_INPUT_BOUNDARIES_canBeChanged__ = true;
    }
    if ("TEXT_INPUT_WALLS".equals(_variable)) {
      _model.TEXT_INPUT_WALLS = getString("TEXT_INPUT_WALLS"); // Variables.Labels:23
      __TEXT_INPUT_WALLS_canBeChanged__ = true;
    }
    if ("TEXT_INPUT_CTE".equals(_variable)) {
      _model.TEXT_INPUT_CTE = getString("TEXT_INPUT_CTE"); // Variables.Labels:24
      __TEXT_INPUT_CTE_canBeChanged__ = true;
    }
    if ("TEXT_INPUT_CYCLIC".equals(_variable)) {
      _model.TEXT_INPUT_CYCLIC = getString("TEXT_INPUT_CYCLIC"); // Variables.Labels:25
      __TEXT_INPUT_CYCLIC_canBeChanged__ = true;
    }
    if ("TEXT_INPUT_DISKFORCE".equals(_variable)) {
      _model.TEXT_INPUT_DISKFORCE = getString("TEXT_INPUT_DISKFORCE"); // Variables.Labels:26
      __TEXT_INPUT_DISKFORCE_canBeChanged__ = true;
    }
    if ("TEXT_INPUT_EXCLUSION".equals(_variable)) {
      _model.TEXT_INPUT_EXCLUSION = getString("TEXT_INPUT_EXCLUSION"); // Variables.Labels:27
      __TEXT_INPUT_EXCLUSION_canBeChanged__ = true;
    }
    if ("TEXT_INPUT_R12".equals(_variable)) {
      _model.TEXT_INPUT_R12 = getString("TEXT_INPUT_R12"); // Variables.Labels:28
      __TEXT_INPUT_R12_canBeChanged__ = true;
    }
    if ("TEXT_INPUT_R36".equals(_variable)) {
      _model.TEXT_INPUT_R36 = getString("TEXT_INPUT_R36"); // Variables.Labels:29
      __TEXT_INPUT_R36_canBeChanged__ = true;
    }
    if ("TEXT_INPUT_HEYES".equals(_variable)) {
      _model.TEXT_INPUT_HEYES = getString("TEXT_INPUT_HEYES"); // Variables.Labels:30
      __TEXT_INPUT_HEYES_canBeChanged__ = true;
    }
    if ("TEXT_INPUT_DTINTXT".equals(_variable)) {
      _model.TEXT_INPUT_DTINTXT = getString("TEXT_INPUT_DTINTXT"); // Variables.Labels:31
      __TEXT_INPUT_DTINTXT_canBeChanged__ = true;
    }
    if ("TEXT_INPUT_OPTICAL".equals(_variable)) {
      _model.TEXT_INPUT_OPTICAL = getString("TEXT_INPUT_OPTICAL"); // Variables.Labels:32
      __TEXT_INPUT_OPTICAL_canBeChanged__ = true;
    }
    if ("TEXT_INPUT_KX".equals(_variable)) {
      _model.TEXT_INPUT_KX = getString("TEXT_INPUT_KX"); // Variables.Labels:33
      __TEXT_INPUT_KX_canBeChanged__ = true;
    }
    if ("TEXT_INPUT_KY".equals(_variable)) {
      _model.TEXT_INPUT_KY = getString("TEXT_INPUT_KY"); // Variables.Labels:34
      __TEXT_INPUT_KY_canBeChanged__ = true;
    }
    if ("TEXT_INPUT_AO".equals(_variable)) {
      _model.TEXT_INPUT_AO = getString("TEXT_INPUT_AO"); // Variables.Labels:35
      __TEXT_INPUT_AO_canBeChanged__ = true;
    }
    if ("TEXT_INPUT_RG".equals(_variable)) {
      _model.TEXT_INPUT_RG = getString("TEXT_INPUT_RG"); // Variables.Labels:36
      __TEXT_INPUT_RG_canBeChanged__ = true;
    }
    if ("TEXT_INPUT_LONGAOCTE".equals(_variable)) {
      _model.TEXT_INPUT_LONGAOCTE = getString("TEXT_INPUT_LONGAOCTE"); // Variables.Labels:37
      __TEXT_INPUT_LONGAOCTE_canBeChanged__ = true;
    }
    if ("TEXT_INPUT_ELECPOT".equals(_variable)) {
      _model.TEXT_INPUT_ELECPOT = getString("TEXT_INPUT_ELECPOT"); // Variables.Labels:38
      __TEXT_INPUT_ELECPOT_canBeChanged__ = true;
    }
    if ("TEXT_INPUT_Z".equals(_variable)) {
      _model.TEXT_INPUT_Z = getString("TEXT_INPUT_Z"); // Variables.Labels:39
      __TEXT_INPUT_Z_canBeChanged__ = true;
    }
    if ("TEXT_INPUT_LAMBDA".equals(_variable)) {
      _model.TEXT_INPUT_LAMBDA = getString("TEXT_INPUT_LAMBDA"); // Variables.Labels:40
      __TEXT_INPUT_LAMBDA_canBeChanged__ = true;
    }
    if ("TEXT_INPUT_KAPPA".equals(_variable)) {
      _model.TEXT_INPUT_KAPPA = getString("TEXT_INPUT_KAPPA"); // Variables.Labels:41
      __TEXT_INPUT_KAPPA_canBeChanged__ = true;
    }
    if ("TEXT_INPUT_Q".equals(_variable)) {
      _model.TEXT_INPUT_Q = getString("TEXT_INPUT_Q"); // Variables.Labels:42
      __TEXT_INPUT_Q_canBeChanged__ = true;
    }
    if ("MSG_WRITE_INPUT_FILE".equals(_variable)) {
      _model.MSG_WRITE_INPUT_FILE = getString("MSG_WRITE_INPUT_FILE"); // Variables.Labels:43
      __MSG_WRITE_INPUT_FILE_canBeChanged__ = true;
    }
  }

  public void propagateValues () {
    setValue ("_isPlaying",_simulation.isPlaying());
    setValue ("_isPaused", _simulation.isPaused());
    if(__n_canBeChanged__) setValue("n",_model.n); // Variables.Particles:1
    if(__narray_canBeChanged__) setValue("narray",_model.narray); // Variables.Particles:2
    if(__diameter_c_canBeChanged__) setValue("diameter_c",_model.diameter_c); // Variables.Particles:3
    if(__d_real_canBeChanged__) setValue("d_real",_model.d_real); // Variables.Particles:4
    if(__diameter_canBeChanged__) setValue("diameter",_model.diameter); // Variables.Particles:5
    if(__vx_0_canBeChanged__) setValue("vx_0",_model.vx_0); // Variables.Particles:6
    if(__vy_0_canBeChanged__) setValue("vy_0",_model.vy_0); // Variables.Particles:7
    if(__x_canBeChanged__) setValue("x",_model.x); // Variables.Particles:8
    if(__x_0_canBeChanged__) setValue("x_0",_model.x_0); // Variables.Particles:9
    if(__x_prev_canBeChanged__) setValue("x_prev",_model.x_prev); // Variables.Particles:10
    if(__vx_canBeChanged__) setValue("vx",_model.vx); // Variables.Particles:11
    if(__y_0_canBeChanged__) setValue("y_0",_model.y_0); // Variables.Particles:12
    if(__y_prev_canBeChanged__) setValue("y_prev",_model.y_prev); // Variables.Particles:13
    if(__y_canBeChanged__) setValue("y",_model.y); // Variables.Particles:14
    if(__vy_canBeChanged__) setValue("vy",_model.vy); // Variables.Particles:15
    if(__microns_canBeChanged__) setValue("microns",_model.microns); // Variables.Particles:16
    if(__a_canBeChanged__) setValue("a",_model.a); // Variables.Particles:17
    if(__a_real_canBeChanged__) setValue("a_real",_model.a_real); // Variables.Particles:18
    if(__f_p_canBeChanged__) setValue("f_p",_model.f_p); // Variables.Particles:19
    if(__if_p_canBeChanged__) setValue("if_p",_model.if_p); // Variables.Particles:20
    if(__eta0_canBeChanged__) setValue("eta0",_model.eta0); // Variables.Particles:21
    if(__eta_canBeChanged__) setValue("eta",_model.eta); // Variables.Particles:22
    if(__T_canBeChanged__) setValue("T",_model.T); // Variables.Particles:23
    if(__K_B_canBeChanged__) setValue("K_B",_model.K_B); // Variables.Particles:24
    if(__D_canBeChanged__) setValue("D",_model.D); // Variables.Particles:25
    if(__chi_canBeChanged__) setValue("chi",_model.chi); // Variables.Particles:26
    if(__bUseWater_canBeChanged__) setValue("bUseWater",_model.bUseWater); // Variables.Particles:27
    if(__arraylist_Strings_canBeChanged__) setValue("arraylist_Strings",_model.arraylist_Strings); // Variables.Particles:28
    if(__arraylist_StringsStats_canBeChanged__) setValue("arraylist_StringsStats",_model.arraylist_StringsStats); // Variables.Particles:29
    if(__count_images_canBeChanged__) setValue("count_images",_model.count_images); // Variables.Particles:30
    if(__count_images_total_canBeChanged__) setValue("count_images_total",_model.count_images_total); // Variables.Particles:31
    if(__count_images_dt_canBeChanged__) setValue("count_images_dt",_model.count_images_dt); // Variables.Particles:32
    if(__count_images_dt_total_canBeChanged__) setValue("count_images_dt_total",_model.count_images_dt_total); // Variables.Particles:33
    if(__checker_t_canBeChanged__) setValue("checker_t",_model.checker_t); // Variables.Particles:34
    if(__xmin_canBeChanged__) setValue("xmin",_model.xmin); // Variables.Common:1
    if(__xmax_canBeChanged__) setValue("xmax",_model.xmax); // Variables.Common:2
    if(__ymin_canBeChanged__) setValue("ymin",_model.ymin); // Variables.Common:3
    if(__ymax_canBeChanged__) setValue("ymax",_model.ymax); // Variables.Common:4
    if(__t_canBeChanged__) setValue("t",_model.t); // Variables.Common:5
    if(__dt_canBeChanged__) setValue("dt",_model.dt); // Variables.Common:6
    if(__tmax_canBeChanged__) setValue("tmax",_model.tmax); // Variables.Common:7
    if(__textra_canBeChanged__) setValue("textra",_model.textra); // Variables.Common:8
    if(__numberOfSteps_canBeChanged__) setValue("numberOfSteps",_model.numberOfSteps); // Variables.Common:9
    if(__limitOfSteps_canBeChanged__) setValue("limitOfSteps",_model.limitOfSteps); // Variables.Common:10
    if(__dMaxTime_canBeChanged__) setValue("dMaxTime",_model.dMaxTime); // Variables.Common:11
    if(__dTimeMaxImposed_canBeChanged__) setValue("dTimeMaxImposed",_model.dTimeMaxImposed); // Variables.Common:12
    if(__dtInTxt_canBeChanged__) setValue("dtInTxt",_model.dtInTxt); // Variables.Common:13
    if(__bDtInTxt_canBeChanged__) setValue("bDtInTxt",_model.bDtInTxt); // Variables.Common:14
    if(__bSaveDataAuto_canBeChanged__) setValue("bSaveDataAuto",_model.bSaveDataAuto); // Variables.Common:15
    if(__iNumLogSave_canBeChanged__) setValue("iNumLogSave",_model.iNumLogSave); // Variables.Common:16
    if(__ep_canBeChanged__) setValue("ep",_model.ep); // Variables.Common:17
    if(__ed_canBeChanged__) setValue("ed",_model.ed); // Variables.Common:18
    if(__sFileName_canBeChanged__) setValue("sFileName",_model.sFileName); // Variables.Common:19
    if(__sDirectoryName_canBeChanged__) setValue("sDirectoryName",_model.sDirectoryName); // Variables.Common:20
    if(__sInputFileName_canBeChanged__) setValue("sInputFileName",_model.sInputFileName); // Variables.Common:21
    if(__sReadInputFilePath_canBeChanged__) setValue("sReadInputFilePath",_model.sReadInputFilePath); // Variables.Common:22
    if(__sReadFilePath_canBeChanged__) setValue("sReadFilePath",_model.sReadFilePath); // Variables.Common:23
    if(__bexclusion1k_canBeChanged__) setValue("bexclusion1k",_model.bexclusion1k); // Variables.Common:24
    if(__Dreal_canBeChanged__) setValue("Dreal",_model.Dreal); // Variables.Common:25
    if(__phi_2D_canBeChanged__) setValue("phi_2D",_model.phi_2D); // Variables.Common:26
    if(__bIncludeLabelDisk_canBeChanged__) setValue("bIncludeLabelDisk",_model.bIncludeLabelDisk); // Variables.Common:27
    if(__TOLERANCE_canBeChanged__) setValue("TOLERANCE",_model.TOLERANCE); // Variables.Events:1
    if(__bUseCyclicContour_canBeChanged__) setValue("bUseCyclicContour",_model.bUseCyclicContour); // Variables.Events:2
    if(__bUseWallForces_canBeChanged__) setValue("bUseWallForces",_model.bUseWallForces); // Variables.Events:3
    if(__bUseNoContour_canBeChanged__) setValue("bUseNoContour",_model.bUseNoContour); // Variables.Events:4
    if(__nInside_canBeChanged__) setValue("nInside",_model.nInside); // Variables.Events:5
    if(__tSave_canBeChanged__) setValue("tSave",_model.tSave); // Variables.Events:6
    if(__bSeparateDisks_canBeChanged__) setValue("bSeparateDisks",_model.bSeparateDisks); // Variables.Events:7
    if(__bUseDiskForce_canBeChanged__) setValue("bUseDiskForce",_model.bUseDiskForce); // Variables.Events:8
    if(__bUseOpticalForce_canBeChanged__) setValue("bUseOpticalForce",_model.bUseOpticalForce); // Variables.Events:9
    if(__diam_reduction_canBeChanged__) setValue("diam_reduction",_model.diam_reduction); // Variables.Events:10
    if(__bFreeMode_canBeChanged__) setValue("bFreeMode",_model.bFreeMode); // Variables.Events:11
    if(__bReadData_canBeChanged__) setValue("bReadData",_model.bReadData); // Variables.Events:12
    if(__binHistoJumps_canBeChanged__) setValue("binHistoJumps",_model.binHistoJumps); // Variables.Statistics:1
    if(__freqHistoJumps_canBeChanged__) setValue("freqHistoJumps",_model.freqHistoJumps); // Variables.Statistics:2
    if(__dFreqesp_canBeChanged__) setValue("dFreqesp",_model.dFreqesp); // Variables.Statistics:3
    if(__dFreqespOptPot_canBeChanged__) setValue("dFreqespOptPot",_model.dFreqespOptPot); // Variables.Statistics:4
    if(__countHistoJumpsX_canBeChanged__) setValue("countHistoJumpsX",_model.countHistoJumpsX); // Variables.Statistics:5
    if(__countHistoJumpsY_canBeChanged__) setValue("countHistoJumpsY",_model.countHistoJumpsY); // Variables.Statistics:6
    if(__bDoHistoJumps_canBeChanged__) setValue("bDoHistoJumps",_model.bDoHistoJumps); // Variables.Statistics:7
    if(__DHistoJumpsX_canBeChanged__) setValue("DHistoJumpsX",_model.DHistoJumpsX); // Variables.Statistics:8
    if(__DHistoJumpsY_canBeChanged__) setValue("DHistoJumpsY",_model.DHistoJumpsY); // Variables.Statistics:9
    if(__freqHistoOptPot_canBeChanged__) setValue("freqHistoOptPot",_model.freqHistoOptPot); // Variables.Statistics:10
    if(__countHistoOptPotX_canBeChanged__) setValue("countHistoOptPotX",_model.countHistoOptPotX); // Variables.Statistics:11
    if(__countHistoOptPotY_canBeChanged__) setValue("countHistoOptPotY",_model.countHistoOptPotY); // Variables.Statistics:12
    if(__bDoHistoOptPot_canBeChanged__) setValue("bDoHistoOptPot",_model.bDoHistoOptPot); // Variables.Statistics:13
    if(__kHistoOptPotX_canBeChanged__) setValue("kHistoOptPotX",_model.kHistoOptPotX); // Variables.Statistics:14
    if(__kHistoOptPotY_canBeChanged__) setValue("kHistoOptPotY",_model.kHistoOptPotY); // Variables.Statistics:15
    if(__particleXYexample_canBeChanged__) setValue("particleXYexample",_model.particleXYexample); // Variables.Statistics:16
    if(__particleXYexample2_canBeChanged__) setValue("particleXYexample2",_model.particleXYexample2); // Variables.Statistics:17
    if(__cte_f_exclusion_canBeChanged__) setValue("cte_f_exclusion",_model.cte_f_exclusion); // Variables.Potentials:1
    if(__cte_diffusion_canBeChanged__) setValue("cte_diffusion",_model.cte_diffusion); // Variables.Potentials:2
    if(__bAOmodel_canBeChanged__) setValue("bAOmodel",_model.bAOmodel); // Variables.Potentials:3
    if(__Rg_canBeChanged__) setValue("Rg",_model.Rg); // Variables.Potentials:4
    if(__cteAOennp_canBeChanged__) setValue("cteAOennp",_model.cteAOennp); // Variables.Potentials:5
    if(__A0_canBeChanged__) setValue("A0",_model.A0); // Variables.Potentials:6
    if(__A_canBeChanged__) setValue("A",_model.A); // Variables.Potentials:7
    if(__B_canBeChanged__) setValue("B",_model.B); // Variables.Potentials:8
    if(__bUseExclusionForce_canBeChanged__) setValue("bUseExclusionForce",_model.bUseExclusionForce); // Variables.Potentials:9
    if(__bUseHSn12_canBeChanged__) setValue("bUseHSn12",_model.bUseHSn12); // Variables.Potentials:10
    if(__bUseHSn36_canBeChanged__) setValue("bUseHSn36",_model.bUseHSn36); // Variables.Potentials:11
    if(__bUseHSHeyes_canBeChanged__) setValue("bUseHSHeyes",_model.bUseHSHeyes); // Variables.Potentials:12
    if(__cteAHSn12_canBeChanged__) setValue("cteAHSn12",_model.cteAHSn12); // Variables.Potentials:13
    if(__cteAHSn36_canBeChanged__) setValue("cteAHSn36",_model.cteAHSn36); // Variables.Potentials:14
    if(__ctekHSHeyes_canBeChanged__) setValue("ctekHSHeyes",_model.ctekHSHeyes); // Variables.Potentials:15
    if(__bUseElecAtracPot_canBeChanged__) setValue("bUseElecAtracPot",_model.bUseElecAtracPot); // Variables.Potentials:16
    if(__Zelec_canBeChanged__) setValue("Zelec",_model.Zelec); // Variables.Potentials:17
    if(__lambdaelec_canBeChanged__) setValue("lambdaelec",_model.lambdaelec); // Variables.Potentials:18
    if(__kappainvelec_canBeChanged__) setValue("kappainvelec",_model.kappainvelec); // Variables.Potentials:19
    if(__qelec_canBeChanged__) setValue("qelec",_model.qelec); // Variables.Potentials:20
    if(__k_optics_y_canBeChanged__) setValue("k_optics_y",_model.k_optics_y); // Variables.Potentials:21
    if(__k_optics_x_canBeChanged__) setValue("k_optics_x",_model.k_optics_x); // Variables.Potentials:22
    if(__cabeceraEstadisticas_canBeChanged__) setValue("cabeceraEstadisticas",_model.cabeceraEstadisticas); // Variables.Labels:1
    if(__sLabel_canBeChanged__) setValue("sLabel",_model.sLabel); // Variables.Labels:2
    if(__MSG_OPEN_FILE_canBeChanged__) setValue("MSG_OPEN_FILE",_model.MSG_OPEN_FILE); // Variables.Labels:3
    if(__MSG_CLOSE_FILE_canBeChanged__) setValue("MSG_CLOSE_FILE",_model.MSG_CLOSE_FILE); // Variables.Labels:4
    if(__MSG_WRITE_FILE_canBeChanged__) setValue("MSG_WRITE_FILE",_model.MSG_WRITE_FILE); // Variables.Labels:5
    if(__MSG_WRITE_FILE_ERROR_canBeChanged__) setValue("MSG_WRITE_FILE_ERROR",_model.MSG_WRITE_FILE_ERROR); // Variables.Labels:6
    if(__MSG_SAVING_ARRAY_canBeChanged__) setValue("MSG_SAVING_ARRAY",_model.MSG_SAVING_ARRAY); // Variables.Labels:7
    if(__MSG_CLEARING_ARRAY_canBeChanged__) setValue("MSG_CLEARING_ARRAY",_model.MSG_CLEARING_ARRAY); // Variables.Labels:8
    if(__TEXT_INPUT_FILE_canBeChanged__) setValue("TEXT_INPUT_FILE",_model.TEXT_INPUT_FILE); // Variables.Labels:9
    if(__TEXT_INPUT_TIMETOTAL_canBeChanged__) setValue("TEXT_INPUT_TIMETOTAL",_model.TEXT_INPUT_TIMETOTAL); // Variables.Labels:10
    if(__TEXT_INPUT_DT_canBeChanged__) setValue("TEXT_INPUT_DT",_model.TEXT_INPUT_DT); // Variables.Labels:11
    if(__TEXT_INPUT_SEP_canBeChanged__) setValue("TEXT_INPUT_SEP",_model.TEXT_INPUT_SEP); // Variables.Labels:12
    if(__TEXT_INPUT_N_canBeChanged__) setValue("TEXT_INPUT_N",_model.TEXT_INPUT_N); // Variables.Labels:13
    if(__TEXT_INPUT_RDIAM_canBeChanged__) setValue("TEXT_INPUT_RDIAM",_model.TEXT_INPUT_RDIAM); // Variables.Labels:14
    if(__TEXT_INPUT_DIAM_canBeChanged__) setValue("TEXT_INPUT_DIAM",_model.TEXT_INPUT_DIAM); // Variables.Labels:15
    if(__TEXT_INPUT_CAL_canBeChanged__) setValue("TEXT_INPUT_CAL",_model.TEXT_INPUT_CAL); // Variables.Labels:16
    if(__TEXT_INPUT_CONC_canBeChanged__) setValue("TEXT_INPUT_CONC",_model.TEXT_INPUT_CONC); // Variables.Labels:17
    if(__TEXT_INPUT_T_canBeChanged__) setValue("TEXT_INPUT_T",_model.TEXT_INPUT_T); // Variables.Labels:18
    if(__TEXT_INPUT_VISCO_canBeChanged__) setValue("TEXT_INPUT_VISCO",_model.TEXT_INPUT_VISCO); // Variables.Labels:19
    if(__TEXT_INPUT_DIFF_canBeChanged__) setValue("TEXT_INPUT_DIFF",_model.TEXT_INPUT_DIFF); // Variables.Labels:20
    if(__TEXT_INPUT_RDIFF_canBeChanged__) setValue("TEXT_INPUT_RDIFF",_model.TEXT_INPUT_RDIFF); // Variables.Labels:21
    if(__TEXT_INPUT_BOUNDARIES_canBeChanged__) setValue("TEXT_INPUT_BOUNDARIES",_model.TEXT_INPUT_BOUNDARIES); // Variables.Labels:22
    if(__TEXT_INPUT_WALLS_canBeChanged__) setValue("TEXT_INPUT_WALLS",_model.TEXT_INPUT_WALLS); // Variables.Labels:23
    if(__TEXT_INPUT_CTE_canBeChanged__) setValue("TEXT_INPUT_CTE",_model.TEXT_INPUT_CTE); // Variables.Labels:24
    if(__TEXT_INPUT_CYCLIC_canBeChanged__) setValue("TEXT_INPUT_CYCLIC",_model.TEXT_INPUT_CYCLIC); // Variables.Labels:25
    if(__TEXT_INPUT_DISKFORCE_canBeChanged__) setValue("TEXT_INPUT_DISKFORCE",_model.TEXT_INPUT_DISKFORCE); // Variables.Labels:26
    if(__TEXT_INPUT_EXCLUSION_canBeChanged__) setValue("TEXT_INPUT_EXCLUSION",_model.TEXT_INPUT_EXCLUSION); // Variables.Labels:27
    if(__TEXT_INPUT_R12_canBeChanged__) setValue("TEXT_INPUT_R12",_model.TEXT_INPUT_R12); // Variables.Labels:28
    if(__TEXT_INPUT_R36_canBeChanged__) setValue("TEXT_INPUT_R36",_model.TEXT_INPUT_R36); // Variables.Labels:29
    if(__TEXT_INPUT_HEYES_canBeChanged__) setValue("TEXT_INPUT_HEYES",_model.TEXT_INPUT_HEYES); // Variables.Labels:30
    if(__TEXT_INPUT_DTINTXT_canBeChanged__) setValue("TEXT_INPUT_DTINTXT",_model.TEXT_INPUT_DTINTXT); // Variables.Labels:31
    if(__TEXT_INPUT_OPTICAL_canBeChanged__) setValue("TEXT_INPUT_OPTICAL",_model.TEXT_INPUT_OPTICAL); // Variables.Labels:32
    if(__TEXT_INPUT_KX_canBeChanged__) setValue("TEXT_INPUT_KX",_model.TEXT_INPUT_KX); // Variables.Labels:33
    if(__TEXT_INPUT_KY_canBeChanged__) setValue("TEXT_INPUT_KY",_model.TEXT_INPUT_KY); // Variables.Labels:34
    if(__TEXT_INPUT_AO_canBeChanged__) setValue("TEXT_INPUT_AO",_model.TEXT_INPUT_AO); // Variables.Labels:35
    if(__TEXT_INPUT_RG_canBeChanged__) setValue("TEXT_INPUT_RG",_model.TEXT_INPUT_RG); // Variables.Labels:36
    if(__TEXT_INPUT_LONGAOCTE_canBeChanged__) setValue("TEXT_INPUT_LONGAOCTE",_model.TEXT_INPUT_LONGAOCTE); // Variables.Labels:37
    if(__TEXT_INPUT_ELECPOT_canBeChanged__) setValue("TEXT_INPUT_ELECPOT",_model.TEXT_INPUT_ELECPOT); // Variables.Labels:38
    if(__TEXT_INPUT_Z_canBeChanged__) setValue("TEXT_INPUT_Z",_model.TEXT_INPUT_Z); // Variables.Labels:39
    if(__TEXT_INPUT_LAMBDA_canBeChanged__) setValue("TEXT_INPUT_LAMBDA",_model.TEXT_INPUT_LAMBDA); // Variables.Labels:40
    if(__TEXT_INPUT_KAPPA_canBeChanged__) setValue("TEXT_INPUT_KAPPA",_model.TEXT_INPUT_KAPPA); // Variables.Labels:41
    if(__TEXT_INPUT_Q_canBeChanged__) setValue("TEXT_INPUT_Q",_model.TEXT_INPUT_Q); // Variables.Labels:42
    if(__MSG_WRITE_INPUT_FILE_canBeChanged__) setValue("MSG_WRITE_INPUT_FILE",_model.MSG_WRITE_INPUT_FILE); // Variables.Labels:43
  }

  @SuppressWarnings("unchecked")
  public void blockVariable(String _variable) {
    if ("n".equals(_variable)) __n_canBeChanged__ = false; // Variables.Particles:1
    if ("narray".equals(_variable)) __narray_canBeChanged__ = false; // Variables.Particles:2
    if ("diameter_c".equals(_variable)) __diameter_c_canBeChanged__ = false; // Variables.Particles:3
    if ("d_real".equals(_variable)) __d_real_canBeChanged__ = false; // Variables.Particles:4
    if ("diameter".equals(_variable)) __diameter_canBeChanged__ = false; // Variables.Particles:5
    if ("vx_0".equals(_variable)) __vx_0_canBeChanged__ = false; // Variables.Particles:6
    if ("vy_0".equals(_variable)) __vy_0_canBeChanged__ = false; // Variables.Particles:7
    if ("x".equals(_variable)) __x_canBeChanged__ = false; // Variables.Particles:8
    if ("x_0".equals(_variable)) __x_0_canBeChanged__ = false; // Variables.Particles:9
    if ("x_prev".equals(_variable)) __x_prev_canBeChanged__ = false; // Variables.Particles:10
    if ("vx".equals(_variable)) __vx_canBeChanged__ = false; // Variables.Particles:11
    if ("y_0".equals(_variable)) __y_0_canBeChanged__ = false; // Variables.Particles:12
    if ("y_prev".equals(_variable)) __y_prev_canBeChanged__ = false; // Variables.Particles:13
    if ("y".equals(_variable)) __y_canBeChanged__ = false; // Variables.Particles:14
    if ("vy".equals(_variable)) __vy_canBeChanged__ = false; // Variables.Particles:15
    if ("microns".equals(_variable)) __microns_canBeChanged__ = false; // Variables.Particles:16
    if ("a".equals(_variable)) __a_canBeChanged__ = false; // Variables.Particles:17
    if ("a_real".equals(_variable)) __a_real_canBeChanged__ = false; // Variables.Particles:18
    if ("f_p".equals(_variable)) __f_p_canBeChanged__ = false; // Variables.Particles:19
    if ("if_p".equals(_variable)) __if_p_canBeChanged__ = false; // Variables.Particles:20
    if ("eta0".equals(_variable)) __eta0_canBeChanged__ = false; // Variables.Particles:21
    if ("eta".equals(_variable)) __eta_canBeChanged__ = false; // Variables.Particles:22
    if ("T".equals(_variable)) __T_canBeChanged__ = false; // Variables.Particles:23
    if ("K_B".equals(_variable)) __K_B_canBeChanged__ = false; // Variables.Particles:24
    if ("D".equals(_variable)) __D_canBeChanged__ = false; // Variables.Particles:25
    if ("chi".equals(_variable)) __chi_canBeChanged__ = false; // Variables.Particles:26
    if ("bUseWater".equals(_variable)) __bUseWater_canBeChanged__ = false; // Variables.Particles:27
    if ("arraylist_Strings".equals(_variable)) __arraylist_Strings_canBeChanged__ = false; // Variables.Particles:28
    if ("arraylist_StringsStats".equals(_variable)) __arraylist_StringsStats_canBeChanged__ = false; // Variables.Particles:29
    if ("count_images".equals(_variable)) __count_images_canBeChanged__ = false; // Variables.Particles:30
    if ("count_images_total".equals(_variable)) __count_images_total_canBeChanged__ = false; // Variables.Particles:31
    if ("count_images_dt".equals(_variable)) __count_images_dt_canBeChanged__ = false; // Variables.Particles:32
    if ("count_images_dt_total".equals(_variable)) __count_images_dt_total_canBeChanged__ = false; // Variables.Particles:33
    if ("checker_t".equals(_variable)) __checker_t_canBeChanged__ = false; // Variables.Particles:34
    if ("xmin".equals(_variable)) __xmin_canBeChanged__ = false; // Variables.Common:1
    if ("xmax".equals(_variable)) __xmax_canBeChanged__ = false; // Variables.Common:2
    if ("ymin".equals(_variable)) __ymin_canBeChanged__ = false; // Variables.Common:3
    if ("ymax".equals(_variable)) __ymax_canBeChanged__ = false; // Variables.Common:4
    if ("t".equals(_variable)) __t_canBeChanged__ = false; // Variables.Common:5
    if ("dt".equals(_variable)) __dt_canBeChanged__ = false; // Variables.Common:6
    if ("tmax".equals(_variable)) __tmax_canBeChanged__ = false; // Variables.Common:7
    if ("textra".equals(_variable)) __textra_canBeChanged__ = false; // Variables.Common:8
    if ("numberOfSteps".equals(_variable)) __numberOfSteps_canBeChanged__ = false; // Variables.Common:9
    if ("limitOfSteps".equals(_variable)) __limitOfSteps_canBeChanged__ = false; // Variables.Common:10
    if ("dMaxTime".equals(_variable)) __dMaxTime_canBeChanged__ = false; // Variables.Common:11
    if ("dTimeMaxImposed".equals(_variable)) __dTimeMaxImposed_canBeChanged__ = false; // Variables.Common:12
    if ("dtInTxt".equals(_variable)) __dtInTxt_canBeChanged__ = false; // Variables.Common:13
    if ("bDtInTxt".equals(_variable)) __bDtInTxt_canBeChanged__ = false; // Variables.Common:14
    if ("bSaveDataAuto".equals(_variable)) __bSaveDataAuto_canBeChanged__ = false; // Variables.Common:15
    if ("iNumLogSave".equals(_variable)) __iNumLogSave_canBeChanged__ = false; // Variables.Common:16
    if ("ep".equals(_variable)) __ep_canBeChanged__ = false; // Variables.Common:17
    if ("ed".equals(_variable)) __ed_canBeChanged__ = false; // Variables.Common:18
    if ("sFileName".equals(_variable)) __sFileName_canBeChanged__ = false; // Variables.Common:19
    if ("sDirectoryName".equals(_variable)) __sDirectoryName_canBeChanged__ = false; // Variables.Common:20
    if ("sInputFileName".equals(_variable)) __sInputFileName_canBeChanged__ = false; // Variables.Common:21
    if ("sReadInputFilePath".equals(_variable)) __sReadInputFilePath_canBeChanged__ = false; // Variables.Common:22
    if ("sReadFilePath".equals(_variable)) __sReadFilePath_canBeChanged__ = false; // Variables.Common:23
    if ("bexclusion1k".equals(_variable)) __bexclusion1k_canBeChanged__ = false; // Variables.Common:24
    if ("Dreal".equals(_variable)) __Dreal_canBeChanged__ = false; // Variables.Common:25
    if ("phi_2D".equals(_variable)) __phi_2D_canBeChanged__ = false; // Variables.Common:26
    if ("bIncludeLabelDisk".equals(_variable)) __bIncludeLabelDisk_canBeChanged__ = false; // Variables.Common:27
    if ("TOLERANCE".equals(_variable)) __TOLERANCE_canBeChanged__ = false; // Variables.Events:1
    if ("bUseCyclicContour".equals(_variable)) __bUseCyclicContour_canBeChanged__ = false; // Variables.Events:2
    if ("bUseWallForces".equals(_variable)) __bUseWallForces_canBeChanged__ = false; // Variables.Events:3
    if ("bUseNoContour".equals(_variable)) __bUseNoContour_canBeChanged__ = false; // Variables.Events:4
    if ("nInside".equals(_variable)) __nInside_canBeChanged__ = false; // Variables.Events:5
    if ("tSave".equals(_variable)) __tSave_canBeChanged__ = false; // Variables.Events:6
    if ("bSeparateDisks".equals(_variable)) __bSeparateDisks_canBeChanged__ = false; // Variables.Events:7
    if ("bUseDiskForce".equals(_variable)) __bUseDiskForce_canBeChanged__ = false; // Variables.Events:8
    if ("bUseOpticalForce".equals(_variable)) __bUseOpticalForce_canBeChanged__ = false; // Variables.Events:9
    if ("diam_reduction".equals(_variable)) __diam_reduction_canBeChanged__ = false; // Variables.Events:10
    if ("bFreeMode".equals(_variable)) __bFreeMode_canBeChanged__ = false; // Variables.Events:11
    if ("bReadData".equals(_variable)) __bReadData_canBeChanged__ = false; // Variables.Events:12
    if ("binHistoJumps".equals(_variable)) __binHistoJumps_canBeChanged__ = false; // Variables.Statistics:1
    if ("freqHistoJumps".equals(_variable)) __freqHistoJumps_canBeChanged__ = false; // Variables.Statistics:2
    if ("dFreqesp".equals(_variable)) __dFreqesp_canBeChanged__ = false; // Variables.Statistics:3
    if ("dFreqespOptPot".equals(_variable)) __dFreqespOptPot_canBeChanged__ = false; // Variables.Statistics:4
    if ("countHistoJumpsX".equals(_variable)) __countHistoJumpsX_canBeChanged__ = false; // Variables.Statistics:5
    if ("countHistoJumpsY".equals(_variable)) __countHistoJumpsY_canBeChanged__ = false; // Variables.Statistics:6
    if ("bDoHistoJumps".equals(_variable)) __bDoHistoJumps_canBeChanged__ = false; // Variables.Statistics:7
    if ("DHistoJumpsX".equals(_variable)) __DHistoJumpsX_canBeChanged__ = false; // Variables.Statistics:8
    if ("DHistoJumpsY".equals(_variable)) __DHistoJumpsY_canBeChanged__ = false; // Variables.Statistics:9
    if ("freqHistoOptPot".equals(_variable)) __freqHistoOptPot_canBeChanged__ = false; // Variables.Statistics:10
    if ("countHistoOptPotX".equals(_variable)) __countHistoOptPotX_canBeChanged__ = false; // Variables.Statistics:11
    if ("countHistoOptPotY".equals(_variable)) __countHistoOptPotY_canBeChanged__ = false; // Variables.Statistics:12
    if ("bDoHistoOptPot".equals(_variable)) __bDoHistoOptPot_canBeChanged__ = false; // Variables.Statistics:13
    if ("kHistoOptPotX".equals(_variable)) __kHistoOptPotX_canBeChanged__ = false; // Variables.Statistics:14
    if ("kHistoOptPotY".equals(_variable)) __kHistoOptPotY_canBeChanged__ = false; // Variables.Statistics:15
    if ("particleXYexample".equals(_variable)) __particleXYexample_canBeChanged__ = false; // Variables.Statistics:16
    if ("particleXYexample2".equals(_variable)) __particleXYexample2_canBeChanged__ = false; // Variables.Statistics:17
    if ("cte_f_exclusion".equals(_variable)) __cte_f_exclusion_canBeChanged__ = false; // Variables.Potentials:1
    if ("cte_diffusion".equals(_variable)) __cte_diffusion_canBeChanged__ = false; // Variables.Potentials:2
    if ("bAOmodel".equals(_variable)) __bAOmodel_canBeChanged__ = false; // Variables.Potentials:3
    if ("Rg".equals(_variable)) __Rg_canBeChanged__ = false; // Variables.Potentials:4
    if ("cteAOennp".equals(_variable)) __cteAOennp_canBeChanged__ = false; // Variables.Potentials:5
    if ("A0".equals(_variable)) __A0_canBeChanged__ = false; // Variables.Potentials:6
    if ("A".equals(_variable)) __A_canBeChanged__ = false; // Variables.Potentials:7
    if ("B".equals(_variable)) __B_canBeChanged__ = false; // Variables.Potentials:8
    if ("bUseExclusionForce".equals(_variable)) __bUseExclusionForce_canBeChanged__ = false; // Variables.Potentials:9
    if ("bUseHSn12".equals(_variable)) __bUseHSn12_canBeChanged__ = false; // Variables.Potentials:10
    if ("bUseHSn36".equals(_variable)) __bUseHSn36_canBeChanged__ = false; // Variables.Potentials:11
    if ("bUseHSHeyes".equals(_variable)) __bUseHSHeyes_canBeChanged__ = false; // Variables.Potentials:12
    if ("cteAHSn12".equals(_variable)) __cteAHSn12_canBeChanged__ = false; // Variables.Potentials:13
    if ("cteAHSn36".equals(_variable)) __cteAHSn36_canBeChanged__ = false; // Variables.Potentials:14
    if ("ctekHSHeyes".equals(_variable)) __ctekHSHeyes_canBeChanged__ = false; // Variables.Potentials:15
    if ("bUseElecAtracPot".equals(_variable)) __bUseElecAtracPot_canBeChanged__ = false; // Variables.Potentials:16
    if ("Zelec".equals(_variable)) __Zelec_canBeChanged__ = false; // Variables.Potentials:17
    if ("lambdaelec".equals(_variable)) __lambdaelec_canBeChanged__ = false; // Variables.Potentials:18
    if ("kappainvelec".equals(_variable)) __kappainvelec_canBeChanged__ = false; // Variables.Potentials:19
    if ("qelec".equals(_variable)) __qelec_canBeChanged__ = false; // Variables.Potentials:20
    if ("k_optics_y".equals(_variable)) __k_optics_y_canBeChanged__ = false; // Variables.Potentials:21
    if ("k_optics_x".equals(_variable)) __k_optics_x_canBeChanged__ = false; // Variables.Potentials:22
    if ("cabeceraEstadisticas".equals(_variable)) __cabeceraEstadisticas_canBeChanged__ = false; // Variables.Labels:1
    if ("sLabel".equals(_variable)) __sLabel_canBeChanged__ = false; // Variables.Labels:2
    if ("MSG_OPEN_FILE".equals(_variable)) __MSG_OPEN_FILE_canBeChanged__ = false; // Variables.Labels:3
    if ("MSG_CLOSE_FILE".equals(_variable)) __MSG_CLOSE_FILE_canBeChanged__ = false; // Variables.Labels:4
    if ("MSG_WRITE_FILE".equals(_variable)) __MSG_WRITE_FILE_canBeChanged__ = false; // Variables.Labels:5
    if ("MSG_WRITE_FILE_ERROR".equals(_variable)) __MSG_WRITE_FILE_ERROR_canBeChanged__ = false; // Variables.Labels:6
    if ("MSG_SAVING_ARRAY".equals(_variable)) __MSG_SAVING_ARRAY_canBeChanged__ = false; // Variables.Labels:7
    if ("MSG_CLEARING_ARRAY".equals(_variable)) __MSG_CLEARING_ARRAY_canBeChanged__ = false; // Variables.Labels:8
    if ("TEXT_INPUT_FILE".equals(_variable)) __TEXT_INPUT_FILE_canBeChanged__ = false; // Variables.Labels:9
    if ("TEXT_INPUT_TIMETOTAL".equals(_variable)) __TEXT_INPUT_TIMETOTAL_canBeChanged__ = false; // Variables.Labels:10
    if ("TEXT_INPUT_DT".equals(_variable)) __TEXT_INPUT_DT_canBeChanged__ = false; // Variables.Labels:11
    if ("TEXT_INPUT_SEP".equals(_variable)) __TEXT_INPUT_SEP_canBeChanged__ = false; // Variables.Labels:12
    if ("TEXT_INPUT_N".equals(_variable)) __TEXT_INPUT_N_canBeChanged__ = false; // Variables.Labels:13
    if ("TEXT_INPUT_RDIAM".equals(_variable)) __TEXT_INPUT_RDIAM_canBeChanged__ = false; // Variables.Labels:14
    if ("TEXT_INPUT_DIAM".equals(_variable)) __TEXT_INPUT_DIAM_canBeChanged__ = false; // Variables.Labels:15
    if ("TEXT_INPUT_CAL".equals(_variable)) __TEXT_INPUT_CAL_canBeChanged__ = false; // Variables.Labels:16
    if ("TEXT_INPUT_CONC".equals(_variable)) __TEXT_INPUT_CONC_canBeChanged__ = false; // Variables.Labels:17
    if ("TEXT_INPUT_T".equals(_variable)) __TEXT_INPUT_T_canBeChanged__ = false; // Variables.Labels:18
    if ("TEXT_INPUT_VISCO".equals(_variable)) __TEXT_INPUT_VISCO_canBeChanged__ = false; // Variables.Labels:19
    if ("TEXT_INPUT_DIFF".equals(_variable)) __TEXT_INPUT_DIFF_canBeChanged__ = false; // Variables.Labels:20
    if ("TEXT_INPUT_RDIFF".equals(_variable)) __TEXT_INPUT_RDIFF_canBeChanged__ = false; // Variables.Labels:21
    if ("TEXT_INPUT_BOUNDARIES".equals(_variable)) __TEXT_INPUT_BOUNDARIES_canBeChanged__ = false; // Variables.Labels:22
    if ("TEXT_INPUT_WALLS".equals(_variable)) __TEXT_INPUT_WALLS_canBeChanged__ = false; // Variables.Labels:23
    if ("TEXT_INPUT_CTE".equals(_variable)) __TEXT_INPUT_CTE_canBeChanged__ = false; // Variables.Labels:24
    if ("TEXT_INPUT_CYCLIC".equals(_variable)) __TEXT_INPUT_CYCLIC_canBeChanged__ = false; // Variables.Labels:25
    if ("TEXT_INPUT_DISKFORCE".equals(_variable)) __TEXT_INPUT_DISKFORCE_canBeChanged__ = false; // Variables.Labels:26
    if ("TEXT_INPUT_EXCLUSION".equals(_variable)) __TEXT_INPUT_EXCLUSION_canBeChanged__ = false; // Variables.Labels:27
    if ("TEXT_INPUT_R12".equals(_variable)) __TEXT_INPUT_R12_canBeChanged__ = false; // Variables.Labels:28
    if ("TEXT_INPUT_R36".equals(_variable)) __TEXT_INPUT_R36_canBeChanged__ = false; // Variables.Labels:29
    if ("TEXT_INPUT_HEYES".equals(_variable)) __TEXT_INPUT_HEYES_canBeChanged__ = false; // Variables.Labels:30
    if ("TEXT_INPUT_DTINTXT".equals(_variable)) __TEXT_INPUT_DTINTXT_canBeChanged__ = false; // Variables.Labels:31
    if ("TEXT_INPUT_OPTICAL".equals(_variable)) __TEXT_INPUT_OPTICAL_canBeChanged__ = false; // Variables.Labels:32
    if ("TEXT_INPUT_KX".equals(_variable)) __TEXT_INPUT_KX_canBeChanged__ = false; // Variables.Labels:33
    if ("TEXT_INPUT_KY".equals(_variable)) __TEXT_INPUT_KY_canBeChanged__ = false; // Variables.Labels:34
    if ("TEXT_INPUT_AO".equals(_variable)) __TEXT_INPUT_AO_canBeChanged__ = false; // Variables.Labels:35
    if ("TEXT_INPUT_RG".equals(_variable)) __TEXT_INPUT_RG_canBeChanged__ = false; // Variables.Labels:36
    if ("TEXT_INPUT_LONGAOCTE".equals(_variable)) __TEXT_INPUT_LONGAOCTE_canBeChanged__ = false; // Variables.Labels:37
    if ("TEXT_INPUT_ELECPOT".equals(_variable)) __TEXT_INPUT_ELECPOT_canBeChanged__ = false; // Variables.Labels:38
    if ("TEXT_INPUT_Z".equals(_variable)) __TEXT_INPUT_Z_canBeChanged__ = false; // Variables.Labels:39
    if ("TEXT_INPUT_LAMBDA".equals(_variable)) __TEXT_INPUT_LAMBDA_canBeChanged__ = false; // Variables.Labels:40
    if ("TEXT_INPUT_KAPPA".equals(_variable)) __TEXT_INPUT_KAPPA_canBeChanged__ = false; // Variables.Labels:41
    if ("TEXT_INPUT_Q".equals(_variable)) __TEXT_INPUT_Q_canBeChanged__ = false; // Variables.Labels:42
    if ("MSG_WRITE_INPUT_FILE".equals(_variable)) __MSG_WRITE_INPUT_FILE_canBeChanged__ = false; // Variables.Labels:43
  }

// ---------- Creation of the interface  -------------------

  private void createControl() {
    // This first frame is added due to what I consider a bug in Java (Paco)
    addElement( new org.colos.ejs.library.control.swing.ControlFrame(),"_TOP_SECRET_")
      .setProperty("waitForReset","true")
      .setProperty("visible","false")
      .setProperty("background","green")
      .setProperty("size","100,100");
    drawingFrame2 = (java.awt.Component)
      addElement(new org.colos.ejs.library.control.swing.ControlFrame(),"drawingFrame2")
      .setProperty("_ejs_SecondAction_","updateAfterModelAction()")
      .setProperty("exit","true")
      .setProperty("waitForReset","true")
      .setProperty("title",_simulation.translateString("View.drawingFrame2.title","\"Frame\""))
      .setProperty("layout","border")
      .setProperty("visible","true")
      .setProperty("location","463,185")
      .setProperty("size",_simulation.translateString("View.drawingFrame2.size","\"970,750\""))
      .setProperty("resizable","true")
      .getObject();
    tab = (javax.swing.JTabbedPane)
      addElement(new org.colos.ejs.library.control.swing.ControlTabbedPanel(),"tab")
      .setProperty("_ejs_SecondAction_","updateAfterModelAction()")
      .setProperty("position","north")
      .setProperty("parent","drawingFrame2")
      .setProperty("placement","TOP")
      .setProperty("selected","0")
      .setProperty("size",_simulation.translateString("View.tab.size","\"900,750\""))
      .getObject();
    Simulation = (javax.swing.JPanel)
      addElement(new org.colos.ejs.library.control.swing.ControlPanel(),"Simulation")
      .setProperty("_ejs_SecondAction_","updateAfterModelAction()")
      .setProperty("parent","tab")
      .setProperty("layout","VBOX")
      .getObject();
    panel_TITLE = (javax.swing.JPanel)
      addElement(new org.colos.ejs.library.control.swing.ControlPanel(),"panel_TITLE")
      .setProperty("_ejs_SecondAction_","updateAfterModelAction()")
      .setProperty("parent","Simulation")
      .setProperty("layout","HBOX")
      .setProperty("size",_simulation.translateString("View.panel_TITLE.size","\"700,40\""))
      .setProperty("borderType","RAISED_BEVEL")
      .getObject();
    label_TITLE = (javax.swing.JLabel)
      addElement(new org.colos.ejs.library.control.swing.ControlLabel(),"label_TITLE")
      .setProperty("_ejs_SecondAction_","updateAfterModelAction()")
      .setProperty("parent","panel_TITLE")
      .setProperty("text",_simulation.translateString("View.label_TITLE.text","\"BROWNIAN DISKS LAB\""))
      .setProperty("font","Monospaced,BOLD,26")
      .getObject();
    drawingPanel2 = (org.opensourcephysics.drawing2d.DrawingPanel2D)
      addElement(new org.colos.ejs.library.control.swing.ControlDrawingPanel(),"drawingPanel2")
      .setProperty("_ejs_SecondAction_","updateAfterModelAction()")
      .setProperty("position","center")
      .setProperty("parent","Simulation")
      .setProperty("autoscaleX","false")
      .setProperty("autoscaleY","false")
      .setProperty("minimumX","xmin")
      .setProperty("maximumX","xmax")
      .setProperty("minimumY","%_model._method_for_drawingPanel2_minimumY()%" )
      .setProperty("maximumY","%_model._method_for_drawingPanel2_maximumY()%" )
      .setProperty("square","true")
      .setProperty("visible","true")
      .setProperty("background","173,216,230,255")
      .getObject();
    conjuntoFormas = (org.opensourcephysics.drawing2d.Set)
      addElement(new org.colos.ejs.library.control.drawing2d.ControlShapeSet2D(),"conjuntoFormas")
      .setProperty("_ejs_SecondAction_","updateAfterModelAction()")
      .setProperty("parent","drawingPanel2")
      .setProperty("numberOfElements","n")
      .setProperty("x","x")
      .setProperty("y","y")
      .setProperty("sizeX","diameter")
      .setProperty("sizeY","diameter")
      .setProperty("style","ELLIPSE")
      .setProperty("elementposition","CENTERED")
      .setProperty("lineColor","BLACK")
      .setProperty("fillColor","192,128,0,255")
      .getObject();
    segment = (org.opensourcephysics.drawing2d.ElementSegment)
      addElement(new org.colos.ejs.library.control.drawing2d.ControlSegment2D(),"segment")
      .setProperty("_ejs_SecondAction_","updateAfterModelAction()")
      .setProperty("parent","drawingPanel2")
      .setProperty("x","xmin")
      .setProperty("y","ymin")
      .setProperty("sizeX","0")
      .setProperty("sizeY","%_model._method_for_segment_sizeY()%" )
      .setProperty("lineColor","BLACK")
      .setProperty("lineWidth","2")
      .getObject();
    segment2 = (org.opensourcephysics.drawing2d.ElementSegment)
      addElement(new org.colos.ejs.library.control.drawing2d.ControlSegment2D(),"segment2")
      .setProperty("_ejs_SecondAction_","updateAfterModelAction()")
      .setProperty("parent","drawingPanel2")
      .setProperty("x","xmax")
      .setProperty("y","ymin")
      .setProperty("sizeX","0")
      .setProperty("sizeY","%_model._method_for_segment2_sizeY()%" )
      .setProperty("lineColor","BLACK")
      .setProperty("lineWidth","2")
      .getObject();
    segment3 = (org.opensourcephysics.drawing2d.ElementSegment)
      addElement(new org.colos.ejs.library.control.drawing2d.ControlSegment2D(),"segment3")
      .setProperty("_ejs_SecondAction_","updateAfterModelAction()")
      .setProperty("parent","drawingPanel2")
      .setProperty("x","xmin")
      .setProperty("y","ymax")
      .setProperty("sizeX","%_model._method_for_segment3_sizeX()%" )
      .setProperty("sizeY","0")
      .setProperty("lineColor","BLACK")
      .setProperty("lineWidth","3")
      .getObject();
    segment4 = (org.opensourcephysics.drawing2d.ElementSegment)
      addElement(new org.colos.ejs.library.control.drawing2d.ControlSegment2D(),"segment4")
      .setProperty("_ejs_SecondAction_","updateAfterModelAction()")
      .setProperty("parent","drawingPanel2")
      .setProperty("x","xmin")
      .setProperty("y","ymin")
      .setProperty("sizeX","%_model._method_for_segment4_sizeX()%" )
      .setProperty("sizeY","0")
      .setProperty("lineColor","BLACK")
      .setProperty("lineWidth","3")
      .getObject();
    label_simulation = (javax.swing.JPanel)
      addElement(new org.colos.ejs.library.control.swing.ControlPanel(),"label_simulation")
      .setProperty("_ejs_SecondAction_","updateAfterModelAction()")
      .setProperty("position","south")
      .setProperty("parent","Simulation")
      .setProperty("layout","GRID:2,1,0,0")
      .setProperty("size",_simulation.translateString("View.label_simulation.size","\"700,100\""))
      .setProperty("borderType","RAISED_BEVEL")
      .getObject();
    panel_button = (javax.swing.JPanel)
      addElement(new org.colos.ejs.library.control.swing.ControlPanel(),"panel_button")
      .setProperty("_ejs_SecondAction_","updateAfterModelAction()")
      .setProperty("position","west")
      .setProperty("parent","label_simulation")
      .setProperty("layout","FLOW:center,0,20")
      .setProperty("size",_simulation.translateString("View.panel_button.size","\"700,50\""))
      .getObject();
    playPauseButton = (javax.swing.JButton)
      addElement(new org.colos.ejs.library.control.swing.ControlTwoStateButton(),"playPauseButton")
      .setProperty("_ejs_SecondAction_","updateAfterModelAction()")
      .setProperty("position","west")
      .setProperty("parent","panel_button")
      .setProperty("variable","_isPaused")
      .setProperty("size",_simulation.translateString("View.playPauseButton.size","\"50,20\""))
      .setProperty("imageOn",_simulation.translateString("View.playPauseButton.imageOn","\"/org/opensourcephysics/resources/controls/images/play.gif\""))
      .setProperty("actionOn","_model._method_for_playPauseButton_actionOn()" )
      .setProperty("imageOff",_simulation.translateString("View.playPauseButton.imageOff","/org/opensourcephysics/resources/controls/images/pause.gif"))
      .setProperty("actionOff","_model._method_for_playPauseButton_actionOff()" )
      .getObject();
    panel_separator_sb1 = (javax.swing.JPanel)
      addElement(new org.colos.ejs.library.control.swing.ControlPanel(),"panel_separator_sb1")
      .setProperty("_ejs_SecondAction_","updateAfterModelAction()")
      .setProperty("parent","panel_button")
      .setProperty("size",_simulation.translateString("View.panel_separator_sb1.size","\"20,10\""))
      .getObject();
    resetbutton = (javax.swing.JButton)
      addElement(new org.colos.ejs.library.control.swing.ControlButton(),"resetbutton")
      .setProperty("_ejs_SecondAction_","updateAfterModelAction()")
      .setProperty("position","center")
      .setProperty("parent","panel_button")
      .setProperty("image",_simulation.translateString("View.resetbutton.image","\"/org/opensourcephysics/resources/controls/images/reset2.gif\""))
      .setProperty("action","_model._method_for_resetbutton_action()" )
      .setProperty("size",_simulation.translateString("View.resetbutton.size","\"50,20\""))
      .getObject();
    panel_separator_sb15 = (javax.swing.JPanel)
      addElement(new org.colos.ejs.library.control.swing.ControlPanel(),"panel_separator_sb15")
      .setProperty("_ejs_SecondAction_","updateAfterModelAction()")
      .setProperty("parent","panel_button")
      .setProperty("size",_simulation.translateString("View.panel_separator_sb15.size","\"20,10\""))
      .getObject();
    label_write = (javax.swing.JLabel)
      addElement(new org.colos.ejs.library.control.swing.ControlLabel(),"label_write")
      .setProperty("_ejs_SecondAction_","updateAfterModelAction()")
      .setProperty("parent","panel_button")
      .setProperty("text",_simulation.translateString("View.label_write.text","\"Write data: \""))
      .getObject();
    button_write = (javax.swing.JButton)
      addElement(new org.colos.ejs.library.control.swing.ControlButton(),"button_write")
      .setProperty("_ejs_SecondAction_","updateAfterModelAction()")
      .setProperty("position","east")
      .setProperty("parent","panel_button")
      .setProperty("image",_simulation.translateString("View.button_write.image","\"./saveSmall.gif\""))
      .setProperty("enabled","%_model._method_for_button_write_enabled()%" )
      .setProperty("action","_model._method_for_button_write_action()" )
      .setProperty("size",_simulation.translateString("View.button_write.size","\"50,20\""))
      .getObject();
    panel_separator_sb22 = (javax.swing.JPanel)
      addElement(new org.colos.ejs.library.control.swing.ControlPanel(),"panel_separator_sb22")
      .setProperty("_ejs_SecondAction_","updateAfterModelAction()")
      .setProperty("parent","panel_button")
      .setProperty("size",_simulation.translateString("View.panel_separator_sb22.size","\"20,10\""))
      .getObject();
    label_write2 = (javax.swing.JLabel)
      addElement(new org.colos.ejs.library.control.swing.ControlLabel(),"label_write2")
      .setProperty("_ejs_SecondAction_","updateAfterModelAction()")
      .setProperty("parent","panel_button")
      .setProperty("text",_simulation.translateString("View.label_write2.text","\"Write last step \""))
      .getObject();
    button_write2 = (javax.swing.JButton)
      addElement(new org.colos.ejs.library.control.swing.ControlButton(),"button_write2")
      .setProperty("_ejs_SecondAction_","updateAfterModelAction()")
      .setProperty("parent","panel_button")
      .setProperty("image",_simulation.translateString("View.button_write2.image","\"./saveSmall.gif\""))
      .setProperty("enabled","%_model._method_for_button_write2_enabled()%" )
      .setProperty("action","_model._method_for_button_write2_action()" )
      .setProperty("size",_simulation.translateString("View.button_write2.size","\"50,20\""))
      .getObject();
    panel_separator_sb2 = (javax.swing.JPanel)
      addElement(new org.colos.ejs.library.control.swing.ControlPanel(),"panel_separator_sb2")
      .setProperty("_ejs_SecondAction_","updateAfterModelAction()")
      .setProperty("parent","panel_button")
      .setProperty("size",_simulation.translateString("View.panel_separator_sb2.size","\"20,10\""))
      .getObject();
    label_reset2 = (javax.swing.JLabel)
      addElement(new org.colos.ejs.library.control.swing.ControlLabel(),"label_reset2")
      .setProperty("_ejs_SecondAction_","updateAfterModelAction()")
      .setProperty("parent","panel_button")
      .setProperty("text",_simulation.translateString("View.label_reset2.text","\"Reset (default val.): \""))
      .getObject();
    resetbutton2 = (javax.swing.JButton)
      addElement(new org.colos.ejs.library.control.swing.ControlButton(),"resetbutton2")
      .setProperty("_ejs_SecondAction_","updateAfterModelAction()")
      .setProperty("parent","panel_button")
      .setProperty("image",_simulation.translateString("View.resetbutton2.image","\"/org/opensourcephysics/resources/controls/images/reset.gif\""))
      .setProperty("action","_model._method_for_resetbutton2_action()" )
      .setProperty("size",_simulation.translateString("View.resetbutton2.size","\"50,20\""))
      .getObject();
    panel_time = (javax.swing.JPanel)
      addElement(new org.colos.ejs.library.control.swing.ControlPanel(),"panel_time")
      .setProperty("_ejs_SecondAction_","updateAfterModelAction()")
      .setProperty("parent","label_simulation")
      .setProperty("layout","FLOW:center,0,0")
      .setProperty("size",_simulation.translateString("View.panel_time.size","\"700,30\""))
      .getObject();
    panel_times = (javax.swing.JPanel)
      addElement(new org.colos.ejs.library.control.swing.ControlPanel(),"panel_times")
      .setProperty("_ejs_SecondAction_","updateAfterModelAction()")
      .setProperty("position","center")
      .setProperty("parent","panel_time")
      .setProperty("layout","HBOX")
      .getObject();
    text_time = (javax.swing.JLabel)
      addElement(new org.colos.ejs.library.control.swing.ControlLabel(),"text_time")
      .setProperty("_ejs_SecondAction_","updateAfterModelAction()")
      .setProperty("position","west")
      .setProperty("parent","panel_times")
      .setProperty("text",_simulation.translateString("View.text_time.text","\"Time (s): \""))
      .getObject();
    time_view = (javax.swing.JTextField)
      addElement(new org.colos.ejs.library.control.swing.ControlParsedNumberField(),"time_view")
      .setProperty("_ejs_SecondAction_","updateAfterModelAction()")
      .setProperty("parent","panel_times")
      .setProperty("variable","t")
      .setProperty("editable","false")
      .setProperty("visible","false")
      .setProperty("size",_simulation.translateString("View.time_view.size","\"50,20\""))
      .getObject();
    bar_time = (org.colos.ejs.library.control.swing.JProgressBarDouble)
      addElement(new org.colos.ejs.library.control.swing.ControlBar(),"bar_time")
      .setProperty("_ejs_SecondAction_","updateAfterModelAction()")
      .setProperty("parent","panel_times")
      .setProperty("variable","t")
      .setProperty("minimum","0.0")
      .setProperty("maximum","tmax")
      .setProperty("visible","true")
      .setProperty("size",_simulation.translateString("View.bar_time.size","\"50,20\""))
      .setProperty("background","RED")
      .getObject();
    panel_separator_sb12 = (javax.swing.JPanel)
      addElement(new org.colos.ejs.library.control.swing.ControlPanel(),"panel_separator_sb12")
      .setProperty("_ejs_SecondAction_","updateAfterModelAction()")
      .setProperty("parent","panel_times")
      .setProperty("size",_simulation.translateString("View.panel_separator_sb12.size","\"20,10\""))
      .getObject();
    label_maxtime = (javax.swing.JLabel)
      addElement(new org.colos.ejs.library.control.swing.ControlLabel(),"label_maxtime")
      .setProperty("_ejs_SecondAction_","updateAfterModelAction()")
      .setProperty("parent","panel_times")
      .setProperty("text",_simulation.translateString("View.label_maxtime.text","\"Duration of experiment (s): \""))
      .getObject();
    tmax = (javax.swing.JTextField)
      addElement(new org.colos.ejs.library.control.swing.ControlParsedNumberField(),"tmax")
      .setProperty("_ejs_SecondAction_","updateAfterModelAction()")
      .setProperty("parent","panel_times")
      .setProperty("variable","tmax")
      .setProperty("editable","true")
      .setProperty("action","_model._method_for_tmax_action()" )
      .setProperty("size",_simulation.translateString("View.tmax.size","\"60,30\""))
      .getObject();
    panel_separator_sb13 = (javax.swing.JPanel)
      addElement(new org.colos.ejs.library.control.swing.ControlPanel(),"panel_separator_sb13")
      .setProperty("_ejs_SecondAction_","updateAfterModelAction()")
      .setProperty("parent","panel_times")
      .setProperty("size",_simulation.translateString("View.panel_separator_sb13.size","\"20,10\""))
      .getObject();
    text_initialtime = (javax.swing.JLabel)
      addElement(new org.colos.ejs.library.control.swing.ControlLabel(),"text_initialtime")
      .setProperty("_ejs_SecondAction_","updateAfterModelAction()")
      .setProperty("parent","panel_times")
      .setProperty("text",_simulation.translateString("View.text_initialtime.text","\"Time initial diffusion (s): \""))
      .getObject();
    textra = (javax.swing.JTextField)
      addElement(new org.colos.ejs.library.control.swing.ControlParsedNumberField(),"textra")
      .setProperty("_ejs_SecondAction_","updateAfterModelAction()")
      .setProperty("parent","panel_times")
      .setProperty("variable","textra")
      .setProperty("format",_simulation.translateString("View.textra.format","\"00.0\""))
      .setProperty("action","_model._method_for_textra_action()" )
      .setProperty("size",_simulation.translateString("View.textra.size","\"50,30\""))
      .getObject();
    panel_separator_sb14 = (javax.swing.JPanel)
      addElement(new org.colos.ejs.library.control.swing.ControlPanel(),"panel_separator_sb14")
      .setProperty("_ejs_SecondAction_","updateAfterModelAction()")
      .setProperty("parent","panel_times")
      .setProperty("size",_simulation.translateString("View.panel_separator_sb14.size","\"20,10\""))
      .getObject();
    label_dt = (javax.swing.JLabel)
      addElement(new org.colos.ejs.library.control.swing.ControlLabel(),"label_dt")
      .setProperty("_ejs_SecondAction_","updateAfterModelAction()")
      .setProperty("parent","panel_times")
      .setProperty("text",_simulation.translateString("View.label_dt.text","\"Temporal step (s): \""))
      .getObject();
    dt = (javax.swing.JTextField)
      addElement(new org.colos.ejs.library.control.swing.ControlParsedNumberField(),"dt")
      .setProperty("_ejs_SecondAction_","updateAfterModelAction()")
      .setProperty("parent","panel_times")
      .setProperty("variable","dt")
      .setProperty("format",_simulation.translateString("View.dt.format","\"0.0000\""))
      .setProperty("editable","true")
      .setProperty("action","_model._method_for_dt_action()" )
      .setProperty("size",_simulation.translateString("View.dt.size","\"80,30\""))
      .getObject();
    Input_Data = (javax.swing.JPanel)
      addElement(new org.colos.ejs.library.control.swing.ControlPanel(),"Input_Data")
      .setProperty("_ejs_SecondAction_","updateAfterModelAction()")
      .setProperty("position","south")
      .setProperty("parent","tab")
      .setProperty("layout","VBOX")
      .setProperty("visible","true")
      .getObject();
    panel_particles = (javax.swing.JPanel)
      addElement(new org.colos.ejs.library.control.swing.ControlPanel(),"panel_particles")
      .setProperty("_ejs_SecondAction_","updateAfterModelAction()")
      .setProperty("parent","Input_Data")
      .setProperty("layout","GRID:5,1,0,0")
      .setProperty("borderType","RAISED_BEVEL")
      .getObject();
    label_panel_particles = (javax.swing.JLabel)
      addElement(new org.colos.ejs.library.control.swing.ControlLabel(),"label_panel_particles")
      .setProperty("_ejs_SecondAction_","updateAfterModelAction()")
      .setProperty("parent","panel_particles")
      .setProperty("text",_simulation.translateString("View.label_panel_particles.text","\"INPUT DATA FOR PARTICLES: \""))
      .getObject();
    panel_input = (javax.swing.JPanel)
      addElement(new org.colos.ejs.library.control.swing.ControlPanel(),"panel_input")
      .setProperty("_ejs_SecondAction_","updateAfterModelAction()")
      .setProperty("parent","panel_particles")
      .setProperty("layout","HBOX")
      .getObject();
    panel_num = (javax.swing.JPanel)
      addElement(new org.colos.ejs.library.control.swing.ControlPanel(),"panel_num")
      .setProperty("_ejs_SecondAction_","updateAfterModelAction()")
      .setProperty("position","center")
      .setProperty("parent","panel_input")
      .setProperty("layout","FLOW:left,0,0")
      .getObject();
    label_explain_num = (javax.swing.JLabel)
      addElement(new org.colos.ejs.library.control.swing.ControlLabel(),"label_explain_num")
      .setProperty("_ejs_SecondAction_","updateAfterModelAction()")
      .setProperty("parent","panel_num")
      .setProperty("text",_simulation.translateString("View.label_explain_num.text","\"Number, size and concentration:\""))
      .getObject();
    panel_separator22 = (javax.swing.JPanel)
      addElement(new org.colos.ejs.library.control.swing.ControlPanel(),"panel_separator22")
      .setProperty("_ejs_SecondAction_","updateAfterModelAction()")
      .setProperty("parent","panel_num")
      .setProperty("size",_simulation.translateString("View.panel_separator22.size","\"50,10\""))
      .getObject();
    text_num = (javax.swing.JLabel)
      addElement(new org.colos.ejs.library.control.swing.ControlLabel(),"text_num")
      .setProperty("_ejs_SecondAction_","updateAfterModelAction()")
      .setProperty("position","west")
      .setProperty("parent","panel_num")
      .setProperty("text",_simulation.translateString("View.text_num.text","\"N: \""))
      .getObject();
    num = (javax.swing.JTextField)
      addElement(new org.colos.ejs.library.control.swing.ControlParsedNumberField(),"num")
      .setProperty("_ejs_SecondAction_","updateAfterModelAction()")
      .setProperty("position","east")
      .setProperty("parent","panel_num")
      .setProperty("variable","n")
      .setProperty("format",_simulation.translateString("View.num.format","\"#000\""))
      .setProperty("editable","true")
      .setProperty("action","_model._method_for_num_action()" )
      .getObject();
    createControl50();
  }

  private void createControl50() {
    panel_separator = (javax.swing.JPanel)
      addElement(new org.colos.ejs.library.control.swing.ControlPanel(),"panel_separator")
      .setProperty("_ejs_SecondAction_","updateAfterModelAction()")
      .setProperty("position","north")
      .setProperty("parent","panel_num")
      .setProperty("size",_simulation.translateString("View.panel_separator.size","\"50,10\""))
      .getObject();
    text_dreal = (javax.swing.JLabel)
      addElement(new org.colos.ejs.library.control.swing.ControlLabel(),"text_dreal")
      .setProperty("_ejs_SecondAction_","updateAfterModelAction()")
      .setProperty("position","east")
      .setProperty("parent","panel_num")
      .setProperty("text",_simulation.translateString("View.text_dreal.text","\"Diameter (μm): \""))
      .getObject();
    dreal = (javax.swing.JTextField)
      addElement(new org.colos.ejs.library.control.swing.ControlParsedNumberField(),"dreal")
      .setProperty("_ejs_SecondAction_","updateAfterModelAction()")
      .setProperty("position","west")
      .setProperty("parent","panel_num")
      .setProperty("variable","d_real")
      .setProperty("format",_simulation.translateString("View.dreal.format","\"0.00\""))
      .setProperty("editable","true")
      .setProperty("action","_model._method_for_dreal_action()" )
      .getObject();
    panel_separator2 = (javax.swing.JPanel)
      addElement(new org.colos.ejs.library.control.swing.ControlPanel(),"panel_separator2")
      .setProperty("_ejs_SecondAction_","updateAfterModelAction()")
      .setProperty("parent","panel_num")
      .setProperty("size",_simulation.translateString("View.panel_separator2.size","\"50,10\""))
      .getObject();
    text_phi2D = (javax.swing.JLabel)
      addElement(new org.colos.ejs.library.control.swing.ControlLabel(),"text_phi2D")
      .setProperty("_ejs_SecondAction_","updateAfterModelAction()")
      .setProperty("position","east")
      .setProperty("parent","panel_num")
      .setProperty("text",_simulation.translateString("View.text_phi2D.text","\"ϕ2D: \""))
      .getObject();
    phi2D = (javax.swing.JTextField)
      addElement(new org.colos.ejs.library.control.swing.ControlParsedNumberField(),"phi2D")
      .setProperty("_ejs_SecondAction_","updateAfterModelAction()")
      .setProperty("position","west")
      .setProperty("parent","panel_num")
      .setProperty("variable","phi_2D")
      .setProperty("format",_simulation.translateString("View.phi2D.format","\"0.0000\""))
      .setProperty("editable","true")
      .setProperty("action","_model._method_for_phi2D_action()" )
      .getObject();
    panel_temp = (javax.swing.JPanel)
      addElement(new org.colos.ejs.library.control.swing.ControlPanel(),"panel_temp")
      .setProperty("_ejs_SecondAction_","updateAfterModelAction()")
      .setProperty("position","west")
      .setProperty("parent","panel_particles")
      .setProperty("layout","FLOW:left,0,0")
      .getObject();
    label_explain_temp = (javax.swing.JLabel)
      addElement(new org.colos.ejs.library.control.swing.ControlLabel(),"label_explain_temp")
      .setProperty("_ejs_SecondAction_","updateAfterModelAction()")
      .setProperty("parent","panel_temp")
      .setProperty("text",_simulation.translateString("View.label_explain_temp.text","\"Fluid: temperature and viscosity: \""))
      .getObject();
    check_water = (javax.swing.JCheckBox)
      addElement(new org.colos.ejs.library.control.swing.ControlCheckBox(),"check_water")
      .setProperty("_ejs_SecondAction_","updateAfterModelAction()")
      .setProperty("position","west")
      .setProperty("parent","panel_temp")
      .setProperty("variable","bUseWater")
      .setProperty("selected","true")
      .setProperty("text",_simulation.translateString("View.check_water.text","\"Water?\""))
      .setProperty("action","_model._method_for_check_water_action()" )
      .getObject();
    panel_separator_temp1 = (javax.swing.JPanel)
      addElement(new org.colos.ejs.library.control.swing.ControlPanel(),"panel_separator_temp1")
      .setProperty("_ejs_SecondAction_","updateAfterModelAction()")
      .setProperty("parent","panel_temp")
      .setProperty("size",_simulation.translateString("View.panel_separator_temp1.size","\"30,10\""))
      .getObject();
    label_temp = (javax.swing.JLabel)
      addElement(new org.colos.ejs.library.control.swing.ControlLabel(),"label_temp")
      .setProperty("_ejs_SecondAction_","updateAfterModelAction()")
      .setProperty("position","west")
      .setProperty("parent","panel_temp")
      .setProperty("text",_simulation.translateString("View.label_temp.text","\"Temp. (K):\""))
      .getObject();
    temp = (javax.swing.JTextField)
      addElement(new org.colos.ejs.library.control.swing.ControlParsedNumberField(),"temp")
      .setProperty("_ejs_SecondAction_","updateAfterModelAction()")
      .setProperty("position","center")
      .setProperty("parent","panel_temp")
      .setProperty("variable","T")
      .setProperty("format",_simulation.translateString("View.temp.format","\"000.0\""))
      .setProperty("editable","true")
      .setProperty("action","_model._method_for_temp_action()" )
      .getObject();
    panel_separator_temp2 = (javax.swing.JPanel)
      addElement(new org.colos.ejs.library.control.swing.ControlPanel(),"panel_separator_temp2")
      .setProperty("_ejs_SecondAction_","updateAfterModelAction()")
      .setProperty("parent","panel_temp")
      .setProperty("size",_simulation.translateString("View.panel_separator_temp2.size","\"30,10\""))
      .getObject();
    label_visco = (javax.swing.JLabel)
      addElement(new org.colos.ejs.library.control.swing.ControlLabel(),"label_visco")
      .setProperty("_ejs_SecondAction_","updateAfterModelAction()")
      .setProperty("position","center")
      .setProperty("parent","panel_temp")
      .setProperty("text",_simulation.translateString("View.label_visco.text","\"η (Pa.s): \""))
      .getObject();
    visco = (javax.swing.JTextField)
      addElement(new org.colos.ejs.library.control.swing.ControlParsedNumberField(),"visco")
      .setProperty("_ejs_SecondAction_","updateAfterModelAction()")
      .setProperty("position","north")
      .setProperty("parent","panel_temp")
      .setProperty("variable","eta0")
      .setProperty("format",_simulation.translateString("View.visco.format","\"0.0000\""))
      .setProperty("editable","%_model._method_for_visco_editable()%" )
      .setProperty("action","_model._method_for_visco_action()" )
      .getObject();
    panel_separator_temp3 = (javax.swing.JPanel)
      addElement(new org.colos.ejs.library.control.swing.ControlPanel(),"panel_separator_temp3")
      .setProperty("_ejs_SecondAction_","updateAfterModelAction()")
      .setProperty("parent","panel_temp")
      .setProperty("size",_simulation.translateString("View.panel_separator_temp3.size","\"30,10\""))
      .getObject();
    text_diffreal = (javax.swing.JLabel)
      addElement(new org.colos.ejs.library.control.swing.ControlLabel(),"text_diffreal")
      .setProperty("_ejs_SecondAction_","updateAfterModelAction()")
      .setProperty("position","east")
      .setProperty("parent","panel_temp")
      .setProperty("text",_simulation.translateString("View.text_diffreal.text","\"D (μm²/s): \""))
      .getObject();
    diffreal = (javax.swing.JTextField)
      addElement(new org.colos.ejs.library.control.swing.ControlParsedNumberField(),"diffreal")
      .setProperty("_ejs_SecondAction_","updateAfterModelAction()")
      .setProperty("position","south")
      .setProperty("parent","panel_temp")
      .setProperty("variable","Dreal")
      .setProperty("format",_simulation.translateString("View.diffreal.format","\"0.##E0\""))
      .setProperty("editable","false")
      .getObject();
    panel_conversion = (javax.swing.JPanel)
      addElement(new org.colos.ejs.library.control.swing.ControlPanel(),"panel_conversion")
      .setProperty("_ejs_SecondAction_","updateAfterModelAction()")
      .setProperty("parent","panel_particles")
      .setProperty("layout","FLOW:left,0,0")
      .getObject();
    label_explain_conversion = (javax.swing.JLabel)
      addElement(new org.colos.ejs.library.control.swing.ControlLabel(),"label_explain_conversion")
      .setProperty("_ejs_SecondAction_","updateAfterModelAction()")
      .setProperty("parent","panel_conversion")
      .setProperty("text",_simulation.translateString("View.label_explain_conversion.text","\"Values in simulation (screen units): \""))
      .getObject();
    panel_separator_conv1 = (javax.swing.JPanel)
      addElement(new org.colos.ejs.library.control.swing.ControlPanel(),"panel_separator_conv1")
      .setProperty("_ejs_SecondAction_","updateAfterModelAction()")
      .setProperty("parent","panel_conversion")
      .setProperty("size",_simulation.translateString("View.panel_separator_conv1.size","\"50,10\""))
      .getObject();
    text_dsim = (javax.swing.JLabel)
      addElement(new org.colos.ejs.library.control.swing.ControlLabel(),"text_dsim")
      .setProperty("_ejs_SecondAction_","updateAfterModelAction()")
      .setProperty("position","center")
      .setProperty("parent","panel_conversion")
      .setProperty("text",_simulation.translateString("View.text_dsim.text","\"Diameter: \""))
      .getObject();
    dsim = (javax.swing.JTextField)
      addElement(new org.colos.ejs.library.control.swing.ControlParsedNumberField(),"dsim")
      .setProperty("_ejs_SecondAction_","updateAfterModelAction()")
      .setProperty("position","north")
      .setProperty("parent","panel_conversion")
      .setProperty("variable","diameter_c")
      .setProperty("format",_simulation.translateString("View.dsim.format","\"0.0000\""))
      .setProperty("editable","false")
      .getObject();
    panel_separator_conv2 = (javax.swing.JPanel)
      addElement(new org.colos.ejs.library.control.swing.ControlPanel(),"panel_separator_conv2")
      .setProperty("_ejs_SecondAction_","updateAfterModelAction()")
      .setProperty("parent","panel_conversion")
      .setProperty("size",_simulation.translateString("View.panel_separator_conv2.size","\"30,10\""))
      .getObject();
    text_factorcal = (javax.swing.JLabel)
      addElement(new org.colos.ejs.library.control.swing.ControlLabel(),"text_factorcal")
      .setProperty("_ejs_SecondAction_","updateAfterModelAction()")
      .setProperty("position","center")
      .setProperty("parent","panel_conversion")
      .setProperty("text",_simulation.translateString("View.text_factorcal.text","\"Cal. factor: \""))
      .setProperty("font","Monospaced,BOLD,16")
      .getObject();
    factcal = (javax.swing.JTextField)
      addElement(new org.colos.ejs.library.control.swing.ControlParsedNumberField(),"factcal")
      .setProperty("_ejs_SecondAction_","updateAfterModelAction()")
      .setProperty("position","north")
      .setProperty("parent","panel_conversion")
      .setProperty("variable","f_p")
      .setProperty("format",_simulation.translateString("View.factcal.format","\"0.0000\""))
      .setProperty("editable","false")
      .getObject();
    panel_separator_conv3 = (javax.swing.JPanel)
      addElement(new org.colos.ejs.library.control.swing.ControlPanel(),"panel_separator_conv3")
      .setProperty("_ejs_SecondAction_","updateAfterModelAction()")
      .setProperty("parent","panel_conversion")
      .setProperty("size",_simulation.translateString("View.panel_separator_conv3.size","\"30,10\""))
      .getObject();
    text_diffsim = (javax.swing.JLabel)
      addElement(new org.colos.ejs.library.control.swing.ControlLabel(),"text_diffsim")
      .setProperty("_ejs_SecondAction_","updateAfterModelAction()")
      .setProperty("position","west")
      .setProperty("parent","panel_conversion")
      .setProperty("text",_simulation.translateString("View.text_diffsim.text","\"D: \""))
      .getObject();
    diffsim = (javax.swing.JTextField)
      addElement(new org.colos.ejs.library.control.swing.ControlParsedNumberField(),"diffsim")
      .setProperty("_ejs_SecondAction_","updateAfterModelAction()")
      .setProperty("position","center")
      .setProperty("parent","panel_conversion")
      .setProperty("variable","D")
      .setProperty("format",_simulation.translateString("View.diffsim.format","\"0.##E0\""))
      .setProperty("editable","false")
      .getObject();
    panel_contour = (javax.swing.JPanel)
      addElement(new org.colos.ejs.library.control.swing.ControlPanel(),"panel_contour")
      .setProperty("_ejs_SecondAction_","updateAfterModelAction()")
      .setProperty("parent","Input_Data")
      .setProperty("layout","GRID:4,1,0,0")
      .setProperty("borderType","RAISED_BEVEL")
      .getObject();
    label_panel_particles2 = (javax.swing.JLabel)
      addElement(new org.colos.ejs.library.control.swing.ControlLabel(),"label_panel_particles2")
      .setProperty("_ejs_SecondAction_","updateAfterModelAction()")
      .setProperty("parent","panel_contour")
      .setProperty("text",_simulation.translateString("View.label_panel_particles2.text","\"BOUNDARY LIMITS AND HARD-DISK FORCES\""))
      .getObject();
    label_boundaries = (javax.swing.JPanel)
      addElement(new org.colos.ejs.library.control.swing.ControlPanel(),"label_boundaries")
      .setProperty("_ejs_SecondAction_","updateAfterModelAction()")
      .setProperty("position","center")
      .setProperty("parent","panel_contour")
      .setProperty("layout","FLOW:left,0,0")
      .getObject();
    text_boundary = (javax.swing.JLabel)
      addElement(new org.colos.ejs.library.control.swing.ControlLabel(),"text_boundary")
      .setProperty("_ejs_SecondAction_","updateAfterModelAction()")
      .setProperty("parent","label_boundaries")
      .setProperty("text",_simulation.translateString("View.text_boundary.text","\"Boundary conditions: \""))
      .getObject();
    panel_separator_cont1 = (javax.swing.JPanel)
      addElement(new org.colos.ejs.library.control.swing.ControlPanel(),"panel_separator_cont1")
      .setProperty("_ejs_SecondAction_","updateAfterModelAction()")
      .setProperty("parent","label_boundaries")
      .setProperty("size",_simulation.translateString("View.panel_separator_cont1.size","\"30,10\""))
      .getObject();
    noboundary = (javax.swing.JRadioButton)
      addElement(new org.colos.ejs.library.control.swing.ControlRadioButton(),"noboundary")
      .setProperty("_ejs_SecondAction_","updateAfterModelAction()")
      .setProperty("parent","label_boundaries")
      .setProperty("variable","bUseNoContour")
      .setProperty("selected","true")
      .setProperty("text",_simulation.translateString("View.noboundary.text","\"No Boundary.\""))
      .setProperty("actionon","_model._method_for_noboundary_actionon()" )
      .setProperty("actionoff","_model._method_for_noboundary_actionoff()" )
      .getObject();
    panel_separator_cont2 = (javax.swing.JPanel)
      addElement(new org.colos.ejs.library.control.swing.ControlPanel(),"panel_separator_cont2")
      .setProperty("_ejs_SecondAction_","updateAfterModelAction()")
      .setProperty("parent","label_boundaries")
      .setProperty("size",_simulation.translateString("View.panel_separator_cont2.size","\"30,10\""))
      .getObject();
    check_walls = (javax.swing.JRadioButton)
      addElement(new org.colos.ejs.library.control.swing.ControlRadioButton(),"check_walls")
      .setProperty("_ejs_SecondAction_","updateAfterModelAction()")
      .setProperty("position","center")
      .setProperty("parent","label_boundaries")
      .setProperty("variable","bUseWallForces")
      .setProperty("selected","true")
      .setProperty("text",_simulation.translateString("View.check_walls.text","\"Wall force: \""))
      .setProperty("enabled","%_model._method_for_check_walls_enabled()%" )
      .setProperty("actionon","_model._method_for_check_walls_actionon()" )
      .getObject();
    wall = (javax.swing.JTextField)
      addElement(new org.colos.ejs.library.control.swing.ControlParsedNumberField(),"wall")
      .setProperty("_ejs_SecondAction_","updateAfterModelAction()")
      .setProperty("parent","label_boundaries")
      .setProperty("variable","ep")
      .setProperty("format",_simulation.translateString("View.wall.format","\"0.00\""))
      .setProperty("editable","bUseWallForces")
      .setProperty("size",_simulation.translateString("View.wall.size","\"50,20\""))
      .getObject();
    panel_separator_cont3 = (javax.swing.JPanel)
      addElement(new org.colos.ejs.library.control.swing.ControlPanel(),"panel_separator_cont3")
      .setProperty("_ejs_SecondAction_","updateAfterModelAction()")
      .setProperty("parent","label_boundaries")
      .setProperty("size",_simulation.translateString("View.panel_separator_cont3.size","\"30,10\""))
      .getObject();
    PacMan = (javax.swing.JRadioButton)
      addElement(new org.colos.ejs.library.control.swing.ControlRadioButton(),"PacMan")
      .setProperty("_ejs_SecondAction_","updateAfterModelAction()")
      .setProperty("parent","label_boundaries")
      .setProperty("variable","bUseCyclicContour")
      .setProperty("text",_simulation.translateString("View.PacMan.text","\"Cyclic.  \""))
      .setProperty("enabled","%_model._method_for_PacMan_enabled()%" )
      .setProperty("action","_model._method_for_PacMan_action()" )
      .getObject();
    diam_redux = (javax.swing.JTextField)
      addElement(new org.colos.ejs.library.control.swing.ControlParsedNumberField(),"diam_redux")
      .setProperty("_ejs_SecondAction_","updateAfterModelAction()")
      .setProperty("parent","label_boundaries")
      .setProperty("variable","diam_reduction")
      .setProperty("format",_simulation.translateString("View.diam_redux.format","\"#0.00\""))
      .setProperty("editable","bUseCyclicContour")
      .setProperty("action","_model._method_for_diam_redux_action()" )
      .setProperty("size",_simulation.translateString("View.diam_redux.size","\"50,20\""))
      .getObject();
    label_disks = (javax.swing.JPanel)
      addElement(new org.colos.ejs.library.control.swing.ControlPanel(),"label_disks")
      .setProperty("_ejs_SecondAction_","updateAfterModelAction()")
      .setProperty("position","north")
      .setProperty("parent","panel_contour")
      .setProperty("layout","FLOW:left,0,0")
      .getObject();
    check_forcedisk = (javax.swing.JCheckBox)
      addElement(new org.colos.ejs.library.control.swing.ControlCheckBox(),"check_forcedisk")
      .setProperty("_ejs_SecondAction_","updateAfterModelAction()")
      .setProperty("parent","label_disks")
      .setProperty("variable","bUseDiskForce")
      .setProperty("selected","true")
      .setProperty("text",_simulation.translateString("View.check_forcedisk.text","\"Use disk forces: \""))
      .setProperty("actionon","_model._method_for_check_forcedisk_actionon()" )
      .getObject();
    panel_separator_dsk1 = (javax.swing.JPanel)
      addElement(new org.colos.ejs.library.control.swing.ControlPanel(),"panel_separator_dsk1")
      .setProperty("_ejs_SecondAction_","updateAfterModelAction()")
      .setProperty("parent","label_disks")
      .setProperty("size",_simulation.translateString("View.panel_separator_dsk1.size","\"20,10\""))
      .getObject();
    check_exclusionvolumenforce = (javax.swing.JRadioButton)
      addElement(new org.colos.ejs.library.control.swing.ControlRadioButton(),"check_exclusionvolumenforce")
      .setProperty("_ejs_SecondAction_","updateAfterModelAction()")
      .setProperty("parent","label_disks")
      .setProperty("variable","bUseExclusionForce")
      .setProperty("text",_simulation.translateString("View.check_exclusionvolumenforce.text","\"Exclusion volume force\""))
      .setProperty("enabled","bUseDiskForce")
      .setProperty("actionon","_model._method_for_check_exclusionvolumenforce_actionon()" )
      .getObject();
    panel_separator_dsk2 = (javax.swing.JPanel)
      addElement(new org.colos.ejs.library.control.swing.ControlPanel(),"panel_separator_dsk2")
      .setProperty("_ejs_SecondAction_","updateAfterModelAction()")
      .setProperty("parent","label_disks")
      .setProperty("size",_simulation.translateString("View.panel_separator_dsk2.size","\"20,10\""))
      .getObject();
    check_hsn12 = (javax.swing.JRadioButton)
      addElement(new org.colos.ejs.library.control.swing.ControlRadioButton(),"check_hsn12")
      .setProperty("_ejs_SecondAction_","updateAfterModelAction()")
      .setProperty("parent","label_disks")
      .setProperty("variable","bUseHSn12")
      .setProperty("selected","false")
      .setProperty("text",_simulation.translateString("View.check_hsn12.text","\"HS n=12\""))
      .setProperty("enabled","bUseDiskForce")
      .setProperty("actionon","_model._method_for_check_hsn12_actionon()" )
      .getObject();
    hsn12 = (javax.swing.JTextField)
      addElement(new org.colos.ejs.library.control.swing.ControlParsedNumberField(),"hsn12")
      .setProperty("_ejs_SecondAction_","updateAfterModelAction()")
      .setProperty("parent","label_disks")
      .setProperty("variable","cteAHSn12")
      .setProperty("editable","%_model._method_for_hsn12_editable()%" )
      .getObject();
    panel_separator_dsk3 = (javax.swing.JPanel)
      addElement(new org.colos.ejs.library.control.swing.ControlPanel(),"panel_separator_dsk3")
      .setProperty("_ejs_SecondAction_","updateAfterModelAction()")
      .setProperty("parent","label_disks")
      .setProperty("size",_simulation.translateString("View.panel_separator_dsk3.size","\"20,10\""))
      .getObject();
    check_check_hsn36 = (javax.swing.JRadioButton)
      addElement(new org.colos.ejs.library.control.swing.ControlRadioButton(),"check_check_hsn36")
      .setProperty("_ejs_SecondAction_","updateAfterModelAction()")
      .setProperty("parent","label_disks")
      .setProperty("variable","bUseHSn36")
      .setProperty("selected","false")
      .setProperty("text",_simulation.translateString("View.check_check_hsn36.text","\"HS n=36\""))
      .setProperty("enabled","bUseDiskForce")
      .setProperty("actionon","_model._method_for_check_check_hsn36_actionon()" )
      .getObject();
    createControl100();
  }

  private void createControl100() {
    hsn36 = (javax.swing.JTextField)
      addElement(new org.colos.ejs.library.control.swing.ControlParsedNumberField(),"hsn36")
      .setProperty("_ejs_SecondAction_","updateAfterModelAction()")
      .setProperty("parent","label_disks")
      .setProperty("variable","cteAHSn36")
      .setProperty("editable","%_model._method_for_hsn36_editable()%" )
      .getObject();
    panel_separator_dsk4 = (javax.swing.JPanel)
      addElement(new org.colos.ejs.library.control.swing.ControlPanel(),"panel_separator_dsk4")
      .setProperty("_ejs_SecondAction_","updateAfterModelAction()")
      .setProperty("parent","label_disks")
      .setProperty("size",_simulation.translateString("View.panel_separator_dsk4.size","\"20,10\""))
      .getObject();
    check_heyes = (javax.swing.JRadioButton)
      addElement(new org.colos.ejs.library.control.swing.ControlRadioButton(),"check_heyes")
      .setProperty("_ejs_SecondAction_","updateAfterModelAction()")
      .setProperty("parent","label_disks")
      .setProperty("variable","bUseHSHeyes")
      .setProperty("selected","true")
      .setProperty("text",_simulation.translateString("View.check_heyes.text","\"Heyes\""))
      .setProperty("enabled","bUseDiskForce")
      .setProperty("actionon","_model._method_for_check_heyes_actionon()" )
      .getObject();
    heyes = (javax.swing.JTextField)
      addElement(new org.colos.ejs.library.control.swing.ControlParsedNumberField(),"heyes")
      .setProperty("_ejs_SecondAction_","updateAfterModelAction()")
      .setProperty("parent","label_disks")
      .setProperty("variable","ctekHSHeyes")
      .setProperty("editable","%_model._method_for_heyes_editable()%" )
      .getObject();
    panel_potentials = (javax.swing.JPanel)
      addElement(new org.colos.ejs.library.control.swing.ControlPanel(),"panel_potentials")
      .setProperty("_ejs_SecondAction_","updateAfterModelAction()")
      .setProperty("parent","Input_Data")
      .setProperty("layout","GRID:5,1,0,0")
      .setProperty("borderType","RAISED_BEVEL")
      .getObject();
    label_panel_particles22 = (javax.swing.JLabel)
      addElement(new org.colos.ejs.library.control.swing.ControlLabel(),"label_panel_particles22")
      .setProperty("_ejs_SecondAction_","updateAfterModelAction()")
      .setProperty("parent","panel_potentials")
      .setProperty("text",_simulation.translateString("View.label_panel_particles22.text","\"EXTERNAL POTENTIALS\""))
      .getObject();
    panel_AO = (javax.swing.JPanel)
      addElement(new org.colos.ejs.library.control.swing.ControlPanel(),"panel_AO")
      .setProperty("_ejs_SecondAction_","updateAfterModelAction()")
      .setProperty("position","west")
      .setProperty("parent","panel_potentials")
      .setProperty("layout","FLOW:left,0,0")
      .setProperty("visible","true")
      .getObject();
    check_AO = (javax.swing.JRadioButton)
      addElement(new org.colos.ejs.library.control.swing.ControlRadioButton(),"check_AO")
      .setProperty("_ejs_SecondAction_","updateAfterModelAction()")
      .setProperty("position","center")
      .setProperty("parent","panel_AO")
      .setProperty("variable","bAOmodel")
      .setProperty("selected","false")
      .setProperty("text",_simulation.translateString("View.check_AO.text","\"AO force\""))
      .getObject();
    panel_separator_ao1 = (javax.swing.JPanel)
      addElement(new org.colos.ejs.library.control.swing.ControlPanel(),"panel_separator_ao1")
      .setProperty("_ejs_SecondAction_","updateAfterModelAction()")
      .setProperty("parent","panel_AO")
      .setProperty("size",_simulation.translateString("View.panel_separator_ao1.size","\"50,10\""))
      .getObject();
    text_rg = (javax.swing.JLabel)
      addElement(new org.colos.ejs.library.control.swing.ControlLabel(),"text_rg")
      .setProperty("_ejs_SecondAction_","updateAfterModelAction()")
      .setProperty("parent","panel_AO")
      .setProperty("text",_simulation.translateString("View.text_rg.text","\"Rg(nm): \""))
      .getObject();
    rg = (javax.swing.JTextField)
      addElement(new org.colos.ejs.library.control.swing.ControlParsedNumberField(),"rg")
      .setProperty("_ejs_SecondAction_","updateAfterModelAction()")
      .setProperty("parent","panel_AO")
      .setProperty("variable","Rg")
      .setProperty("editable","bAOmodel")
      .getObject();
    panel_separator_ao2 = (javax.swing.JPanel)
      addElement(new org.colos.ejs.library.control.swing.ControlPanel(),"panel_separator_ao2")
      .setProperty("_ejs_SecondAction_","updateAfterModelAction()")
      .setProperty("parent","panel_AO")
      .setProperty("size",_simulation.translateString("View.panel_separator_ao2.size","\"50,10\""))
      .getObject();
    label_ctenp = (javax.swing.JLabel)
      addElement(new org.colos.ejs.library.control.swing.ControlLabel(),"label_ctenp")
      .setProperty("_ejs_SecondAction_","updateAfterModelAction()")
      .setProperty("parent","panel_AO")
      .setProperty("text",_simulation.translateString("View.label_ctenp.text","\"Π/KT (μm-³):\""))
      .getObject();
    ctenp = (javax.swing.JTextField)
      addElement(new org.colos.ejs.library.control.swing.ControlParsedNumberField(),"ctenp")
      .setProperty("_ejs_SecondAction_","updateAfterModelAction()")
      .setProperty("parent","panel_AO")
      .setProperty("variable","cteAOennp")
      .setProperty("editable","bAOmodel")
      .getObject();
    panel_atrac_pot = (javax.swing.JPanel)
      addElement(new org.colos.ejs.library.control.swing.ControlPanel(),"panel_atrac_pot")
      .setProperty("_ejs_SecondAction_","updateAfterModelAction()")
      .setProperty("position","east")
      .setProperty("parent","panel_potentials")
      .setProperty("layout","FLOW:left,0,0")
      .setProperty("visible","true")
      .getObject();
    check_atracpot = (javax.swing.JRadioButton)
      addElement(new org.colos.ejs.library.control.swing.ControlRadioButton(),"check_atracpot")
      .setProperty("_ejs_SecondAction_","updateAfterModelAction()")
      .setProperty("position","center")
      .setProperty("parent","panel_atrac_pot")
      .setProperty("variable","bUseElecAtracPot")
      .setProperty("text",_simulation.translateString("View.check_atracpot.text","\"Pot Elec. Atrac.\""))
      .getObject();
    panel_separator_ap1 = (javax.swing.JPanel)
      addElement(new org.colos.ejs.library.control.swing.ControlPanel(),"panel_separator_ap1")
      .setProperty("_ejs_SecondAction_","updateAfterModelAction()")
      .setProperty("parent","panel_atrac_pot")
      .setProperty("size",_simulation.translateString("View.panel_separator_ap1.size","\"80,10\""))
      .getObject();
    text_Z = (javax.swing.JLabel)
      addElement(new org.colos.ejs.library.control.swing.ControlLabel(),"text_Z")
      .setProperty("_ejs_SecondAction_","updateAfterModelAction()")
      .setProperty("parent","panel_atrac_pot")
      .setProperty("text",_simulation.translateString("View.text_Z.text","\"Z: \""))
      .getObject();
    Z = (javax.swing.JTextField)
      addElement(new org.colos.ejs.library.control.swing.ControlParsedNumberField(),"Z")
      .setProperty("_ejs_SecondAction_","updateAfterModelAction()")
      .setProperty("parent","panel_atrac_pot")
      .setProperty("variable","Zelec")
      .setProperty("editable","bUseElecAtracPot")
      .getObject();
    panel_separator_ap2 = (javax.swing.JPanel)
      addElement(new org.colos.ejs.library.control.swing.ControlPanel(),"panel_separator_ap2")
      .setProperty("_ejs_SecondAction_","updateAfterModelAction()")
      .setProperty("parent","panel_atrac_pot")
      .setProperty("size",_simulation.translateString("View.panel_separator_ap2.size","\"20,10\""))
      .getObject();
    text_lambda = (javax.swing.JLabel)
      addElement(new org.colos.ejs.library.control.swing.ControlLabel(),"text_lambda")
      .setProperty("_ejs_SecondAction_","updateAfterModelAction()")
      .setProperty("parent","panel_atrac_pot")
      .setProperty("text",_simulation.translateString("View.text_lambda.text","\" λB (nm): \""))
      .getObject();
    lambda = (javax.swing.JTextField)
      addElement(new org.colos.ejs.library.control.swing.ControlParsedNumberField(),"lambda")
      .setProperty("_ejs_SecondAction_","updateAfterModelAction()")
      .setProperty("parent","panel_atrac_pot")
      .setProperty("variable","lambdaelec")
      .setProperty("editable","bUseElecAtracPot")
      .getObject();
    panel_separator_ap3 = (javax.swing.JPanel)
      addElement(new org.colos.ejs.library.control.swing.ControlPanel(),"panel_separator_ap3")
      .setProperty("_ejs_SecondAction_","updateAfterModelAction()")
      .setProperty("parent","panel_atrac_pot")
      .setProperty("size",_simulation.translateString("View.panel_separator_ap3.size","\"20,10\""))
      .getObject();
    text_1divk = (javax.swing.JLabel)
      addElement(new org.colos.ejs.library.control.swing.ControlLabel(),"text_1divk")
      .setProperty("_ejs_SecondAction_","updateAfterModelAction()")
      .setProperty("parent","panel_atrac_pot")
      .setProperty("text",_simulation.translateString("View.text_1divk.text","\" 1/κ (μm): \""))
      .getObject();
    _divk = (javax.swing.JTextField)
      addElement(new org.colos.ejs.library.control.swing.ControlParsedNumberField(),"_divk")
      .setProperty("_ejs_SecondAction_","updateAfterModelAction()")
      .setProperty("parent","panel_atrac_pot")
      .setProperty("variable","kappainvelec")
      .setProperty("editable","bUseElecAtracPot")
      .getObject();
    panel_separator_ap4 = (javax.swing.JPanel)
      addElement(new org.colos.ejs.library.control.swing.ControlPanel(),"panel_separator_ap4")
      .setProperty("_ejs_SecondAction_","updateAfterModelAction()")
      .setProperty("parent","panel_atrac_pot")
      .setProperty("size",_simulation.translateString("View.panel_separator_ap4.size","\"20,10\""))
      .getObject();
    text_q = (javax.swing.JLabel)
      addElement(new org.colos.ejs.library.control.swing.ControlLabel(),"text_q")
      .setProperty("_ejs_SecondAction_","updateAfterModelAction()")
      .setProperty("parent","panel_atrac_pot")
      .setProperty("text",_simulation.translateString("View.text_q.text","\" q :\""))
      .getObject();
    q = (javax.swing.JTextField)
      addElement(new org.colos.ejs.library.control.swing.ControlParsedNumberField(),"q")
      .setProperty("_ejs_SecondAction_","updateAfterModelAction()")
      .setProperty("parent","panel_atrac_pot")
      .setProperty("variable","qelec")
      .setProperty("editable","bUseElecAtracPot")
      .getObject();
    panel_optical_forces = (javax.swing.JPanel)
      addElement(new org.colos.ejs.library.control.swing.ControlPanel(),"panel_optical_forces")
      .setProperty("_ejs_SecondAction_","updateAfterModelAction()")
      .setProperty("parent","panel_potentials")
      .setProperty("layout","FLOW:left,0,0")
      .setProperty("visible","true")
      .getObject();
    check_opticaltrap = (javax.swing.JRadioButton)
      addElement(new org.colos.ejs.library.control.swing.ControlRadioButton(),"check_opticaltrap")
      .setProperty("_ejs_SecondAction_","updateAfterModelAction()")
      .setProperty("parent","panel_optical_forces")
      .setProperty("variable","bUseOpticalForce")
      .setProperty("selected","false")
      .setProperty("text",_simulation.translateString("View.check_opticaltrap.text","\"Optical trapping forces\""))
      .setProperty("action","_model._method_for_check_opticaltrap_action()" )
      .getObject();
    panel_separator_op1 = (javax.swing.JPanel)
      addElement(new org.colos.ejs.library.control.swing.ControlPanel(),"panel_separator_op1")
      .setProperty("_ejs_SecondAction_","updateAfterModelAction()")
      .setProperty("parent","panel_optical_forces")
      .setProperty("layout","border")
      .setProperty("size",_simulation.translateString("View.panel_separator_op1.size","\"50,10\""))
      .getObject();
    spring_text_x = (javax.swing.JLabel)
      addElement(new org.colos.ejs.library.control.swing.ControlLabel(),"spring_text_x")
      .setProperty("_ejs_SecondAction_","updateAfterModelAction()")
      .setProperty("position","west")
      .setProperty("parent","panel_optical_forces")
      .setProperty("text",_simulation.translateString("View.spring_text_x.text","\"k_x (μN/m):  \""))
      .getObject();
    spring_value_x = (javax.swing.JTextField)
      addElement(new org.colos.ejs.library.control.swing.ControlParsedNumberField(),"spring_value_x")
      .setProperty("_ejs_SecondAction_","updateAfterModelAction()")
      .setProperty("position","center")
      .setProperty("parent","panel_optical_forces")
      .setProperty("variable","k_optics_x")
      .setProperty("format",_simulation.translateString("View.spring_value_x.format","\"0.00\""))
      .setProperty("editable","bUseOpticalForce")
      .setProperty("action","_model._method_for_spring_value_x_action()" )
      .getObject();
    panel_separator_op12 = (javax.swing.JPanel)
      addElement(new org.colos.ejs.library.control.swing.ControlPanel(),"panel_separator_op12")
      .setProperty("_ejs_SecondAction_","updateAfterModelAction()")
      .setProperty("parent","panel_optical_forces")
      .setProperty("layout","border")
      .setProperty("size",_simulation.translateString("View.panel_separator_op12.size","\"50,10\""))
      .getObject();
    spring_text_y = (javax.swing.JLabel)
      addElement(new org.colos.ejs.library.control.swing.ControlLabel(),"spring_text_y")
      .setProperty("_ejs_SecondAction_","updateAfterModelAction()")
      .setProperty("position","west")
      .setProperty("parent","panel_optical_forces")
      .setProperty("text",_simulation.translateString("View.spring_text_y.text","\"k_y (μN/m):  \""))
      .getObject();
    spring_value_y = (javax.swing.JTextField)
      addElement(new org.colos.ejs.library.control.swing.ControlParsedNumberField(),"spring_value_y")
      .setProperty("_ejs_SecondAction_","updateAfterModelAction()")
      .setProperty("position","center")
      .setProperty("parent","panel_optical_forces")
      .setProperty("variable","k_optics_y")
      .setProperty("format",_simulation.translateString("View.spring_value_y.format","\"0.00\""))
      .setProperty("editable","bUseOpticalForce")
      .getObject();
    panel_writereaddata = (javax.swing.JPanel)
      addElement(new org.colos.ejs.library.control.swing.ControlPanel(),"panel_writereaddata")
      .setProperty("_ejs_SecondAction_","updateAfterModelAction()")
      .setProperty("parent","Input_Data")
      .setProperty("layout","GRID:5,1,0,0")
      .setProperty("borderType","RAISED_BEVEL")
      .getObject();
    text_explain_data = (javax.swing.JLabel)
      addElement(new org.colos.ejs.library.control.swing.ControlLabel(),"text_explain_data")
      .setProperty("_ejs_SecondAction_","updateAfterModelAction()")
      .setProperty("parent","panel_writereaddata")
      .setProperty("text",_simulation.translateString("View.text_explain_data.text","\"SAVE DATA TO TXT FILE\""))
      .getObject();
    panel_Deltat = (javax.swing.JPanel)
      addElement(new org.colos.ejs.library.control.swing.ControlPanel(),"panel_Deltat")
      .setProperty("_ejs_SecondAction_","updateAfterModelAction()")
      .setProperty("position","north")
      .setProperty("parent","panel_writereaddata")
      .setProperty("layout","FLOW:left,0,0")
      .getObject();
    checkBox_savedata = (javax.swing.JCheckBox)
      addElement(new org.colos.ejs.library.control.swing.ControlCheckBox(),"checkBox_savedata")
      .setProperty("_ejs_SecondAction_","updateAfterModelAction()")
      .setProperty("parent","panel_Deltat")
      .setProperty("variable","bSaveDataAuto")
      .setProperty("selected","false")
      .setProperty("text",_simulation.translateString("View.checkBox_savedata.text","\"Save data automatically? \""))
      .setProperty("enabled","%_model._method_for_checkBox_savedata_enabled()%" )
      .getObject();
    panel_separator_Dt12 = (javax.swing.JPanel)
      addElement(new org.colos.ejs.library.control.swing.ControlPanel(),"panel_separator_Dt12")
      .setProperty("_ejs_SecondAction_","updateAfterModelAction()")
      .setProperty("parent","panel_Deltat")
      .setProperty("size",_simulation.translateString("View.panel_separator_Dt12.size","\"20,10\""))
      .getObject();
    checkBox_Deltat = (javax.swing.JCheckBox)
      addElement(new org.colos.ejs.library.control.swing.ControlCheckBox(),"checkBox_Deltat")
      .setProperty("_ejs_SecondAction_","updateAfterModelAction()")
      .setProperty("parent","panel_Deltat")
      .setProperty("variable","bDtInTxt")
      .setProperty("text",_simulation.translateString("View.checkBox_Deltat.text","\"Δt (s) imposed in txt: \""))
      .setProperty("enabled","%_model._method_for_checkBox_Deltat_enabled()%" )
      .setProperty("actionon","_model._method_for_checkBox_Deltat_actionon()" )
      .getObject();
    Deltat = (javax.swing.JTextField)
      addElement(new org.colos.ejs.library.control.swing.ControlParsedNumberField(),"Deltat")
      .setProperty("_ejs_SecondAction_","updateAfterModelAction()")
      .setProperty("position","east")
      .setProperty("parent","panel_Deltat")
      .setProperty("variable","dtInTxt")
      .setProperty("format",_simulation.translateString("View.Deltat.format","\"0.0000\""))
      .setProperty("editable","%_model._method_for_Deltat_editable()%" )
      .setProperty("action","_model._method_for_Deltat_action()" )
      .setProperty("size",_simulation.translateString("View.Deltat.size","\"100,30\""))
      .getObject();
    panel_separator_Dt122 = (javax.swing.JPanel)
      addElement(new org.colos.ejs.library.control.swing.ControlPanel(),"panel_separator_Dt122")
      .setProperty("_ejs_SecondAction_","updateAfterModelAction()")
      .setProperty("parent","panel_Deltat")
      .setProperty("size",_simulation.translateString("View.panel_separator_Dt122.size","\"20,10\""))
      .getObject();
    checkBox_labeldisks = (javax.swing.JCheckBox)
      addElement(new org.colos.ejs.library.control.swing.ControlCheckBox(),"checkBox_labeldisks")
      .setProperty("_ejs_SecondAction_","updateAfterModelAction()")
      .setProperty("parent","panel_Deltat")
      .setProperty("variable","bIncludeLabelDisk")
      .setProperty("text",_simulation.translateString("View.checkBox_labeldisks.text","\"Include disks' number?\""))
      .setProperty("enabled","%_model._method_for_checkBox_labeldisks_enabled()%" )
      .getObject();
    panel_separator_Dt1222 = (javax.swing.JPanel)
      addElement(new org.colos.ejs.library.control.swing.ControlPanel(),"panel_separator_Dt1222")
      .setProperty("_ejs_SecondAction_","updateAfterModelAction()")
      .setProperty("parent","panel_Deltat")
      .setProperty("size",_simulation.translateString("View.panel_separator_Dt1222.size","\"20,10\""))
      .getObject();
    checkBox_freemode = (javax.swing.JCheckBox)
      addElement(new org.colos.ejs.library.control.swing.ControlCheckBox(),"checkBox_freemode")
      .setProperty("_ejs_SecondAction_","updateAfterModelAction()")
      .setProperty("parent","panel_Deltat")
      .setProperty("variable","bFreeMode")
      .setProperty("text",_simulation.translateString("View.checkBox_freemode.text","\"Not saving data?\""))
      .setProperty("actionon","_model._method_for_checkBox_freemode_actionon()" )
      .getObject();
    panel_paths = (javax.swing.JPanel)
      addElement(new org.colos.ejs.library.control.swing.ControlPanel(),"panel_paths")
      .setProperty("_ejs_SecondAction_","updateAfterModelAction()")
      .setProperty("position","center")
      .setProperty("parent","panel_writereaddata")
      .setProperty("layout","FLOW:left,0,0")
      .getObject();
    text_path = (javax.swing.JLabel)
      addElement(new org.colos.ejs.library.control.swing.ControlLabel(),"text_path")
      .setProperty("_ejs_SecondAction_","updateAfterModelAction()")
      .setProperty("position","west")
      .setProperty("parent","panel_paths")
      .setProperty("text",_simulation.translateString("View.text_path.text","\"Directory to save file: \""))
      .getObject();
    panel_separator_path1 = (javax.swing.JPanel)
      addElement(new org.colos.ejs.library.control.swing.ControlPanel(),"panel_separator_path1")
      .setProperty("_ejs_SecondAction_","updateAfterModelAction()")
      .setProperty("parent","panel_paths")
      .setProperty("size",_simulation.translateString("View.panel_separator_path1.size","\"20,10\""))
      .getObject();
    createControl150();
  }

  private void createControl150() {
    button_path = (javax.swing.JButton)
      addElement(new org.colos.ejs.library.control.swing.ControlButton(),"button_path")
      .setProperty("_ejs_SecondAction_","updateAfterModelAction()")
      .setProperty("parent","panel_paths")
      .setProperty("image",_simulation.translateString("View.button_path.image","\"/org/opensourcephysics/resources/controls/images/folder.gif\""))
      .setProperty("enabled","%_model._method_for_button_path_enabled()%" )
      .setProperty("action","_model._method_for_button_path_action()" )
      .getObject();
    path = (javax.swing.JTextField)
      addElement(new org.colos.ejs.library.control.swing.ControlTextField(),"path")
      .setProperty("_ejs_SecondAction_","updateAfterModelAction()")
      .setProperty("position","center")
      .setProperty("parent","panel_paths")
      .setProperty("variable","sDirectoryName")
      .setProperty("editable","%_model._method_for_path_editable()%" )
      .setProperty("size",_simulation.translateString("View.path.size","\"300,30\""))
      .getObject();
    panel_separator_path2 = (javax.swing.JPanel)
      addElement(new org.colos.ejs.library.control.swing.ControlPanel(),"panel_separator_path2")
      .setProperty("_ejs_SecondAction_","updateAfterModelAction()")
      .setProperty("parent","panel_paths")
      .setProperty("size",_simulation.translateString("View.panel_separator_path2.size","\"20,10\""))
      .getObject();
    text_file = (javax.swing.JLabel)
      addElement(new org.colos.ejs.library.control.swing.ControlLabel(),"text_file")
      .setProperty("_ejs_SecondAction_","updateAfterModelAction()")
      .setProperty("position","north")
      .setProperty("parent","panel_paths")
      .setProperty("text",_simulation.translateString("View.text_file.text","\"Name file.txt: \""))
      .getObject();
    file = (javax.swing.JTextField)
      addElement(new org.colos.ejs.library.control.swing.ControlTextField(),"file")
      .setProperty("_ejs_SecondAction_","updateAfterModelAction()")
      .setProperty("position","south")
      .setProperty("parent","panel_paths")
      .setProperty("variable","sFileName")
      .setProperty("editable","%_model._method_for_file_editable()%" )
      .setProperty("size",_simulation.translateString("View.file.size","\"200,30\""))
      .getObject();
    text_explain_data2 = (javax.swing.JLabel)
      addElement(new org.colos.ejs.library.control.swing.ControlLabel(),"text_explain_data2")
      .setProperty("_ejs_SecondAction_","updateAfterModelAction()")
      .setProperty("parent","panel_writereaddata")
      .setProperty("text",_simulation.translateString("View.text_explain_data2.text","\"READ  INPUT FILE AND INITIAL XY POSITIONS\""))
      .getObject();
    panel_read = (javax.swing.JPanel)
      addElement(new org.colos.ejs.library.control.swing.ControlPanel(),"panel_read")
      .setProperty("_ejs_SecondAction_","updateAfterModelAction()")
      .setProperty("parent","panel_writereaddata")
      .setProperty("layout","FLOW:left,0,0")
      .getObject();
    botonRadio_read = (javax.swing.JRadioButton)
      addElement(new org.colos.ejs.library.control.swing.ControlRadioButton(),"botonRadio_read")
      .setProperty("_ejs_SecondAction_","updateAfterModelAction()")
      .setProperty("parent","panel_read")
      .setProperty("variable","bReadData")
      .setProperty("selected","false")
      .setProperty("text",_simulation.translateString("View.botonRadio_read.text","\"Read data from files: \""))
      .getObject();
    panel_separator_path12 = (javax.swing.JPanel)
      addElement(new org.colos.ejs.library.control.swing.ControlPanel(),"panel_separator_path12")
      .setProperty("_ejs_SecondAction_","updateAfterModelAction()")
      .setProperty("parent","panel_read")
      .setProperty("size",_simulation.translateString("View.panel_separator_path12.size","\"20,10\""))
      .getObject();
    etiqueta_inputfile = (javax.swing.JLabel)
      addElement(new org.colos.ejs.library.control.swing.ControlLabel(),"etiqueta_inputfile")
      .setProperty("_ejs_SecondAction_","updateAfterModelAction()")
      .setProperty("parent","panel_read")
      .setProperty("text",_simulation.translateString("View.etiqueta_inputfile.text","\"Input file: \""))
      .getObject();
    button_input = (javax.swing.JButton)
      addElement(new org.colos.ejs.library.control.swing.ControlButton(),"button_input")
      .setProperty("_ejs_SecondAction_","updateAfterModelAction()")
      .setProperty("parent","panel_read")
      .setProperty("image",_simulation.translateString("View.button_input.image","\"/org/opensourcephysics/resources/controls/images/folder.gif\""))
      .setProperty("enabled","bReadData")
      .setProperty("action","_model._method_for_button_input_action()" )
      .getObject();
    path_inputfile = (javax.swing.JTextField)
      addElement(new org.colos.ejs.library.control.swing.ControlTextField(),"path_inputfile")
      .setProperty("_ejs_SecondAction_","updateAfterModelAction()")
      .setProperty("parent","panel_read")
      .setProperty("variable","sReadInputFilePath")
      .setProperty("editable","bReadData")
      .setProperty("size",_simulation.translateString("View.path_inputfile.size","\"200,30\""))
      .getObject();
    etiqueta_filename = (javax.swing.JLabel)
      addElement(new org.colos.ejs.library.control.swing.ControlLabel(),"etiqueta_filename")
      .setProperty("_ejs_SecondAction_","updateAfterModelAction()")
      .setProperty("parent","panel_read")
      .setProperty("text",_simulation.translateString("View.etiqueta_filename.text","\"  XY file: \""))
      .getObject();
    button_filename = (javax.swing.JButton)
      addElement(new org.colos.ejs.library.control.swing.ControlButton(),"button_filename")
      .setProperty("_ejs_SecondAction_","updateAfterModelAction()")
      .setProperty("parent","panel_read")
      .setProperty("image",_simulation.translateString("View.button_filename.image","\"/org/opensourcephysics/resources/controls/images/folder.gif\""))
      .setProperty("enabled","bReadData")
      .setProperty("action","_model._method_for_button_filename_action()" )
      .getObject();
    path_filename = (javax.swing.JTextField)
      addElement(new org.colos.ejs.library.control.swing.ControlTextField(),"path_filename")
      .setProperty("_ejs_SecondAction_","updateAfterModelAction()")
      .setProperty("parent","panel_read")
      .setProperty("variable","sReadFilePath")
      .setProperty("editable","bReadData")
      .setProperty("size",_simulation.translateString("View.path_filename.size","\"200,30\""))
      .getObject();
    panel_separator_path122 = (javax.swing.JPanel)
      addElement(new org.colos.ejs.library.control.swing.ControlPanel(),"panel_separator_path122")
      .setProperty("_ejs_SecondAction_","updateAfterModelAction()")
      .setProperty("parent","panel_read")
      .setProperty("size",_simulation.translateString("View.panel_separator_path122.size","\"20,10\""))
      .getObject();
    boton_read = (javax.swing.JButton)
      addElement(new org.colos.ejs.library.control.swing.ControlButton(),"boton_read")
      .setProperty("_ejs_SecondAction_","updateAfterModelAction()")
      .setProperty("parent","panel_read")
      .setProperty("text",_simulation.translateString("View.boton_read.text","\"Read\""))
      .setProperty("enabled","bReadData")
      .setProperty("action","_model._method_for_boton_read_action()" )
      .getObject();
    Graphics = (javax.swing.JPanel)
      addElement(new org.colos.ejs.library.control.swing.ControlPanel(),"Graphics")
      .setProperty("_ejs_SecondAction_","updateAfterModelAction()")
      .setProperty("parent","tab")
      .setProperty("layout","GRID:3,1,0,0")
      .getObject();
    Diffusion_panel = (javax.swing.JPanel)
      addElement(new org.colos.ejs.library.control.swing.ControlPanel(),"Diffusion_panel")
      .setProperty("_ejs_SecondAction_","updateAfterModelAction()")
      .setProperty("position","west")
      .setProperty("parent","Graphics")
      .setProperty("layout","GRID:1,0,50,10")
      .getObject();
    panel_data_diff = (javax.swing.JPanel)
      addElement(new org.colos.ejs.library.control.swing.ControlPanel(),"panel_data_diff")
      .setProperty("_ejs_SecondAction_","updateAfterModelAction()")
      .setProperty("parent","Diffusion_panel")
      .setProperty("layout","GRID:6,1,0,0")
      .getObject();
    panel_data_title_label = (javax.swing.JLabel)
      addElement(new org.colos.ejs.library.control.swing.ControlLabel(),"panel_data_title_label")
      .setProperty("_ejs_SecondAction_","updateAfterModelAction()")
      .setProperty("parent","panel_data_diff")
      .setProperty("text",_simulation.translateString("View.panel_data_title_label.text","\"GAUSSIAN DIFFUSION\""))
      .getObject();
    useGaussian_panel = (javax.swing.JPanel)
      addElement(new org.colos.ejs.library.control.swing.ControlPanel(),"useGaussian_panel")
      .setProperty("_ejs_SecondAction_","updateAfterModelAction()")
      .setProperty("parent","panel_data_diff")
      .setProperty("layout","border")
      .getObject();
    useGaussian = (javax.swing.JRadioButton)
      addElement(new org.colos.ejs.library.control.swing.ControlRadioButton(),"useGaussian")
      .setProperty("_ejs_SecondAction_","updateAfterModelAction()")
      .setProperty("position","center")
      .setProperty("parent","useGaussian_panel")
      .setProperty("variable","bDoHistoJumps")
      .setProperty("text",_simulation.translateString("View.useGaussian.text","\"Calculate Gaussian statistics\""))
      .getObject();
    n_histo_panel = (javax.swing.JPanel)
      addElement(new org.colos.ejs.library.control.swing.ControlPanel(),"n_histo_panel")
      .setProperty("_ejs_SecondAction_","updateAfterModelAction()")
      .setProperty("parent","panel_data_diff")
      .setProperty("layout","border")
      .getObject();
    n_histo_label = (javax.swing.JLabel)
      addElement(new org.colos.ejs.library.control.swing.ControlLabel(),"n_histo_label")
      .setProperty("_ejs_SecondAction_","updateAfterModelAction()")
      .setProperty("position","west")
      .setProperty("parent","n_histo_panel")
      .setProperty("text",_simulation.translateString("View.n_histo_label.text","\"Number of points of histogram (10-200): \""))
      .getObject();
    n_histo = (javax.swing.JTextField)
      addElement(new org.colos.ejs.library.control.swing.ControlParsedNumberField(),"n_histo")
      .setProperty("_ejs_SecondAction_","updateAfterModelAction()")
      .setProperty("position","east")
      .setProperty("parent","n_histo_panel")
      .setProperty("variable","binHistoJumps")
      .setProperty("format",_simulation.translateString("View.n_histo.format","\"000\""))
      .setProperty("action","_model._method_for_n_histo_action()" )
      .setProperty("size",_simulation.translateString("View.n_histo.size","\"60,10\""))
      .getObject();
    DeltaDx_panel = (javax.swing.JPanel)
      addElement(new org.colos.ejs.library.control.swing.ControlPanel(),"DeltaDx_panel")
      .setProperty("_ejs_SecondAction_","updateAfterModelAction()")
      .setProperty("parent","panel_data_diff")
      .setProperty("layout","border")
      .getObject();
    DeltaDx_label = (javax.swing.JLabel)
      addElement(new org.colos.ejs.library.control.swing.ControlLabel(),"DeltaDx_label")
      .setProperty("_ejs_SecondAction_","updateAfterModelAction()")
      .setProperty("position","west")
      .setProperty("parent","DeltaDx_panel")
      .setProperty("text",_simulation.translateString("View.DeltaDx_label.text","\"Relative error Dx and calculated (%) :\""))
      .getObject();
    DeltaDx = (javax.swing.JTextField)
      addElement(new org.colos.ejs.library.control.swing.ControlParsedNumberField(),"DeltaDx")
      .setProperty("_ejs_SecondAction_","updateAfterModelAction()")
      .setProperty("position","east")
      .setProperty("parent","DeltaDx_panel")
      .setProperty("variable","%_model._method_for_DeltaDx_variable()%" )
      .setProperty("format",_simulation.translateString("View.DeltaDx.format","\"0.0\""))
      .setProperty("editable","false")
      .setProperty("size",_simulation.translateString("View.DeltaDx.size","\"60,10\""))
      .getObject();
    DeltaDy_panel = (javax.swing.JPanel)
      addElement(new org.colos.ejs.library.control.swing.ControlPanel(),"DeltaDy_panel")
      .setProperty("_ejs_SecondAction_","updateAfterModelAction()")
      .setProperty("parent","panel_data_diff")
      .setProperty("layout","border")
      .getObject();
    DeltaDy_label = (javax.swing.JLabel)
      addElement(new org.colos.ejs.library.control.swing.ControlLabel(),"DeltaDy_label")
      .setProperty("_ejs_SecondAction_","updateAfterModelAction()")
      .setProperty("position","west")
      .setProperty("parent","DeltaDy_panel")
      .setProperty("text",_simulation.translateString("View.DeltaDy_label.text","\"Relative error Dy and calculated (%) :\""))
      .getObject();
    DeltaDy = (javax.swing.JTextField)
      addElement(new org.colos.ejs.library.control.swing.ControlParsedNumberField(),"DeltaDy")
      .setProperty("_ejs_SecondAction_","updateAfterModelAction()")
      .setProperty("position","east")
      .setProperty("parent","DeltaDy_panel")
      .setProperty("variable","%_model._method_for_DeltaDy_variable()%" )
      .setProperty("format",_simulation.translateString("View.DeltaDy.format","\"0.0\""))
      .setProperty("editable","false")
      .setProperty("size",_simulation.translateString("View.DeltaDy.size","\"60,10\""))
      .getObject();
    panel_diff_separator = (javax.swing.JSeparator)
      addElement(new org.colos.ejs.library.control.swing.ControlSeparator(),"panel_diff_separator")
      .setProperty("_ejs_SecondAction_","updateAfterModelAction()")
      .setProperty("parent","panel_data_diff")
      .getObject();
    panel_graph_diff = (javax.swing.JPanel)
      addElement(new org.colos.ejs.library.control.swing.ControlPanel(),"panel_graph_diff")
      .setProperty("_ejs_SecondAction_","updateAfterModelAction()")
      .setProperty("parent","Diffusion_panel")
      .setProperty("layout","FLOW:center,50,10")
      .getObject();
    Diffusion = (org.opensourcephysics.drawing2d.PlottingPanel2D)
      addElement(new org.colos.ejs.library.control.swing.ControlPlottingPanel(),"Diffusion")
      .setProperty("_ejs_SecondAction_","updateAfterModelAction()")
      .setProperty("position","center")
      .setProperty("parent","panel_graph_diff")
      .setProperty("autoscaleX","false")
      .setProperty("autoscaleY","true")
      .setProperty("title",_simulation.translateString("View.Diffusion.title","\"Gaussian Diffusion\""))
      .setProperty("titleY",_simulation.translateString("View.Diffusion.titleY","\"Counts X (blue), Y (red)\""))
      .setProperty("visible","true")
      .setProperty("size",_simulation.translateString("View.Diffusion.size","\"300,200\""))
      .getObject();
    countx = (org.opensourcephysics.displayejs.InteractiveTrace)
      addElement(new org.colos.ejs.library.control.displayejs.ControlTrace(),"countx")
      .setProperty("_ejs_SecondAction_","updateAfterModelAction()")
      .setProperty("parent","Diffusion")
      .setProperty("x","freqHistoJumps")
      .setProperty("y","countHistoJumpsX")
      .setProperty("clearAtInput","true")
      .setProperty("norepeat","true")
      .setProperty("connected","true")
      .setProperty("color","BLUE")
      .getObject();
    county = (org.opensourcephysics.displayejs.InteractiveTrace)
      addElement(new org.colos.ejs.library.control.displayejs.ControlTrace(),"county")
      .setProperty("_ejs_SecondAction_","updateAfterModelAction()")
      .setProperty("parent","Diffusion")
      .setProperty("x","freqHistoJumps")
      .setProperty("y","countHistoJumpsY")
      .setProperty("clearAtInput","true")
      .setProperty("norepeat","true")
      .setProperty("connected","true")
      .setProperty("color","RED")
      .getObject();
    Optical_panel = (javax.swing.JPanel)
      addElement(new org.colos.ejs.library.control.swing.ControlPanel(),"Optical_panel")
      .setProperty("_ejs_SecondAction_","updateAfterModelAction()")
      .setProperty("position","east")
      .setProperty("parent","Graphics")
      .setProperty("layout","GRID:1,0,50,10")
      .getObject();
    panel_data_k = (javax.swing.JPanel)
      addElement(new org.colos.ejs.library.control.swing.ControlPanel(),"panel_data_k")
      .setProperty("_ejs_SecondAction_","updateAfterModelAction()")
      .setProperty("parent","Optical_panel")
      .setProperty("layout","GRID:6,1,0,0")
      .getObject();
    panel_data_k_title = (javax.swing.JLabel)
      addElement(new org.colos.ejs.library.control.swing.ControlLabel(),"panel_data_k_title")
      .setProperty("_ejs_SecondAction_","updateAfterModelAction()")
      .setProperty("parent","panel_data_k")
      .setProperty("text",_simulation.translateString("View.panel_data_k_title.text","\"BOLTZMANN STATISTICS ON OPTICAL TRAP\""))
      .getObject();
    usek_panel = (javax.swing.JPanel)
      addElement(new org.colos.ejs.library.control.swing.ControlPanel(),"usek_panel")
      .setProperty("_ejs_SecondAction_","updateAfterModelAction()")
      .setProperty("parent","panel_data_k")
      .setProperty("layout","border")
      .getObject();
    usek = (javax.swing.JRadioButton)
      addElement(new org.colos.ejs.library.control.swing.ControlRadioButton(),"usek")
      .setProperty("_ejs_SecondAction_","updateAfterModelAction()")
      .setProperty("position","center")
      .setProperty("parent","usek_panel")
      .setProperty("variable","bDoHistoOptPot")
      .setProperty("text",_simulation.translateString("View.usek.text","\"Calculate k from Boltzmann statistics\""))
      .setProperty("enabled","bUseOpticalForce")
      .getObject();
    n_histo_k_panel = (javax.swing.JPanel)
      addElement(new org.colos.ejs.library.control.swing.ControlPanel(),"n_histo_k_panel")
      .setProperty("_ejs_SecondAction_","updateAfterModelAction()")
      .setProperty("parent","panel_data_k")
      .setProperty("layout","border")
      .getObject();
    n_histo_label2 = (javax.swing.JLabel)
      addElement(new org.colos.ejs.library.control.swing.ControlLabel(),"n_histo_label2")
      .setProperty("_ejs_SecondAction_","updateAfterModelAction()")
      .setProperty("position","west")
      .setProperty("parent","n_histo_k_panel")
      .setProperty("text",_simulation.translateString("View.n_histo_label2.text","\"Number of points of histogram (10-200): \""))
      .getObject();
    n_histo2 = (javax.swing.JTextField)
      addElement(new org.colos.ejs.library.control.swing.ControlParsedNumberField(),"n_histo2")
      .setProperty("_ejs_SecondAction_","updateAfterModelAction()")
      .setProperty("position","east")
      .setProperty("parent","n_histo_k_panel")
      .setProperty("variable","binHistoJumps")
      .setProperty("format",_simulation.translateString("View.n_histo2.format","\"000\""))
      .setProperty("editable","bUseOpticalForce")
      .setProperty("action","_model._method_for_n_histo2_action()" )
      .setProperty("size",_simulation.translateString("View.n_histo2.size","\"60,10\""))
      .getObject();
    Deltakx_panel = (javax.swing.JPanel)
      addElement(new org.colos.ejs.library.control.swing.ControlPanel(),"Deltakx_panel")
      .setProperty("_ejs_SecondAction_","updateAfterModelAction()")
      .setProperty("parent","panel_data_k")
      .setProperty("layout","border")
      .getObject();
    Deltakx_label = (javax.swing.JLabel)
      addElement(new org.colos.ejs.library.control.swing.ControlLabel(),"Deltakx_label")
      .setProperty("_ejs_SecondAction_","updateAfterModelAction()")
      .setProperty("position","west")
      .setProperty("parent","Deltakx_panel")
      .setProperty("text",_simulation.translateString("View.Deltakx_label.text","\"Relative error kx and calculated (%) :\""))
      .getObject();
    Deltakx = (javax.swing.JTextField)
      addElement(new org.colos.ejs.library.control.swing.ControlParsedNumberField(),"Deltakx")
      .setProperty("_ejs_SecondAction_","updateAfterModelAction()")
      .setProperty("position","east")
      .setProperty("parent","Deltakx_panel")
      .setProperty("variable","%_model._method_for_Deltakx_variable()%" )
      .setProperty("format",_simulation.translateString("View.Deltakx.format","\"0.0\""))
      .setProperty("editable","false")
      .setProperty("size",_simulation.translateString("View.Deltakx.size","\"60,10\""))
      .getObject();
    Deltaky_panel = (javax.swing.JPanel)
      addElement(new org.colos.ejs.library.control.swing.ControlPanel(),"Deltaky_panel")
      .setProperty("_ejs_SecondAction_","updateAfterModelAction()")
      .setProperty("parent","panel_data_k")
      .setProperty("layout","border")
      .getObject();
    Deltaky_label = (javax.swing.JLabel)
      addElement(new org.colos.ejs.library.control.swing.ControlLabel(),"Deltaky_label")
      .setProperty("_ejs_SecondAction_","updateAfterModelAction()")
      .setProperty("position","west")
      .setProperty("parent","Deltaky_panel")
      .setProperty("text",_simulation.translateString("View.Deltaky_label.text","\"Relative error ky and calculated (%) :\""))
      .getObject();
    createControl200();
  }

  private void createControl200() {
    Deltaky = (javax.swing.JTextField)
      addElement(new org.colos.ejs.library.control.swing.ControlParsedNumberField(),"Deltaky")
      .setProperty("_ejs_SecondAction_","updateAfterModelAction()")
      .setProperty("position","east")
      .setProperty("parent","Deltaky_panel")
      .setProperty("variable","%_model._method_for_Deltaky_variable()%" )
      .setProperty("format",_simulation.translateString("View.Deltaky.format","\"0.0\""))
      .setProperty("editable","false")
      .setProperty("size",_simulation.translateString("View.Deltaky.size","\"60,10\""))
      .getObject();
    panel_diff_separator2 = (javax.swing.JSeparator)
      addElement(new org.colos.ejs.library.control.swing.ControlSeparator(),"panel_diff_separator2")
      .setProperty("_ejs_SecondAction_","updateAfterModelAction()")
      .setProperty("parent","panel_data_k")
      .getObject();
    panel_graph_k = (javax.swing.JPanel)
      addElement(new org.colos.ejs.library.control.swing.ControlPanel(),"panel_graph_k")
      .setProperty("_ejs_SecondAction_","updateAfterModelAction()")
      .setProperty("parent","Optical_panel")
      .setProperty("layout","FLOW:center,50,10")
      .getObject();
    Potential = (org.opensourcephysics.drawing2d.PlottingPanel2D)
      addElement(new org.colos.ejs.library.control.swing.ControlPlottingPanel(),"Potential")
      .setProperty("_ejs_SecondAction_","updateAfterModelAction()")
      .setProperty("position","center")
      .setProperty("parent","panel_graph_k")
      .setProperty("autoscaleX","false")
      .setProperty("autoscaleY","true")
      .setProperty("title",_simulation.translateString("View.Potential.title","\"Boltzmann statistics\""))
      .setProperty("titleY",_simulation.translateString("View.Potential.titleY","\"Counts X (blue), Y (red)\""))
      .setProperty("visible","true")
      .setProperty("size",_simulation.translateString("View.Potential.size","\"300,200\""))
      .getObject();
    x = (org.opensourcephysics.displayejs.InteractiveTrace)
      addElement(new org.colos.ejs.library.control.displayejs.ControlTrace(),"x")
      .setProperty("_ejs_SecondAction_","updateAfterModelAction()")
      .setProperty("parent","Potential")
      .setProperty("x","freqHistoOptPot")
      .setProperty("y","countHistoOptPotX")
      .setProperty("clearAtInput","true")
      .setProperty("norepeat","true")
      .setProperty("connected","true")
      .setProperty("color","BLUE")
      .getObject();
    y = (org.opensourcephysics.displayejs.InteractiveTrace)
      addElement(new org.colos.ejs.library.control.displayejs.ControlTrace(),"y")
      .setProperty("_ejs_SecondAction_","updateAfterModelAction()")
      .setProperty("parent","Potential")
      .setProperty("x","freqHistoOptPot")
      .setProperty("y","countHistoOptPotY")
      .setProperty("clearAtInput","true")
      .setProperty("norepeat","true")
      .setProperty("connected","true")
      .setProperty("color","RED")
      .getObject();
    Particles_panel = (javax.swing.JPanel)
      addElement(new org.colos.ejs.library.control.swing.ControlPanel(),"Particles_panel")
      .setProperty("_ejs_SecondAction_","updateAfterModelAction()")
      .setProperty("parent","Graphics")
      .setProperty("layout","GRID:1,0,0,0")
      .getObject();
    panel_XY = (javax.swing.JPanel)
      addElement(new org.colos.ejs.library.control.swing.ControlPanel(),"panel_XY")
      .setProperty("_ejs_SecondAction_","updateAfterModelAction()")
      .setProperty("position","center")
      .setProperty("parent","Particles_panel")
      .setProperty("layout","VBOX")
      .getObject();
    paneltitle = (javax.swing.JPanel)
      addElement(new org.colos.ejs.library.control.swing.ControlPanel(),"paneltitle")
      .setProperty("_ejs_SecondAction_","updateAfterModelAction()")
      .setProperty("position","north")
      .setProperty("parent","panel_XY")
      .setProperty("layout","HBOX")
      .getObject();
    particletitle = (javax.swing.JLabel)
      addElement(new org.colos.ejs.library.control.swing.ControlLabel(),"particletitle")
      .setProperty("_ejs_SecondAction_","updateAfterModelAction()")
      .setProperty("position","west")
      .setProperty("parent","paneltitle")
      .setProperty("text",_simulation.translateString("View.particletitle.text","\"Particle's xy position. \""))
      .getObject();
    sep_panel = (javax.swing.JPanel)
      addElement(new org.colos.ejs.library.control.swing.ControlPanel(),"sep_panel")
      .setProperty("_ejs_SecondAction_","updateAfterModelAction()")
      .setProperty("parent","paneltitle")
      .setProperty("layout","border")
      .getObject();
    etiqueta = (javax.swing.JLabel)
      addElement(new org.colos.ejs.library.control.swing.ControlLabel(),"etiqueta")
      .setProperty("_ejs_SecondAction_","updateAfterModelAction()")
      .setProperty("parent","paneltitle")
      .setProperty("text",_simulation.translateString("View.etiqueta.text","\"Number of the particle:  \""))
      .getObject();
    particlenumber = (javax.swing.JTextField)
      addElement(new org.colos.ejs.library.control.swing.ControlParsedNumberField(),"particlenumber")
      .setProperty("_ejs_SecondAction_","updateAfterModelAction()")
      .setProperty("position","east")
      .setProperty("parent","paneltitle")
      .setProperty("variable","particleXYexample")
      .setProperty("format",_simulation.translateString("View.particlenumber.format","\"#0\""))
      .setProperty("editable","true")
      .setProperty("action","_model._method_for_particlenumber_action()" )
      .setProperty("size",_simulation.translateString("View.particlenumber.size","\"5,15\""))
      .getObject();
    boton = (javax.swing.JButton)
      addElement(new org.colos.ejs.library.control.swing.ControlButton(),"boton")
      .setProperty("_ejs_SecondAction_","updateAfterModelAction()")
      .setProperty("parent","paneltitle")
      .setProperty("text",_simulation.translateString("View.boton.text","\"Change\""))
      .setProperty("action","_model._method_for_boton_action()" )
      .getObject();
    one_particle_xy = (org.opensourcephysics.drawing2d.PlottingPanel2D)
      addElement(new org.colos.ejs.library.control.swing.ControlPlottingPanel(),"one_particle_xy")
      .setProperty("_ejs_SecondAction_","updateAfterModelAction()")
      .setProperty("position","center")
      .setProperty("parent","panel_XY")
      .setProperty("autoscaleX","true")
      .setProperty("autoscaleY","true")
      .setProperty("square","true")
      .setProperty("titleX",_simulation.translateString("View.one_particle_xy.titleX","\"X\""))
      .setProperty("titleY",_simulation.translateString("View.one_particle_xy.titleY","\"Y\""))
      .setProperty("visible","true")
      .setProperty("size",_simulation.translateString("View.one_particle_xy.size","\"300,200\""))
      .getObject();
    x_y = (org.opensourcephysics.displayejs.InteractiveTrace)
      addElement(new org.colos.ejs.library.control.displayejs.ControlTrace(),"x_y")
      .setProperty("_ejs_SecondAction_","updateAfterModelAction()")
      .setProperty("parent","one_particle_xy")
      .setProperty("x","%_model._method_for_x_y_x()%" )
      .setProperty("y","%_model._method_for_x_y_y()%" )
      .setProperty("clearAtInput","false")
      .setProperty("norepeat","true")
      .setProperty("connected","true")
      .getObject();
    panel_n = (javax.swing.JPanel)
      addElement(new org.colos.ejs.library.control.swing.ControlPanel(),"panel_n")
      .setProperty("_ejs_SecondAction_","updateAfterModelAction()")
      .setProperty("position","north")
      .setProperty("parent","Particles_panel")
      .setProperty("layout","border")
      .getObject();
    Particles = (org.opensourcephysics.drawing2d.PlottingPanel2D)
      addElement(new org.colos.ejs.library.control.swing.ControlPlottingPanel(),"Particles")
      .setProperty("_ejs_SecondAction_","updateAfterModelAction()")
      .setProperty("position","center")
      .setProperty("parent","panel_n")
      .setProperty("autoscaleX","true")
      .setProperty("autoscaleY","false")
      .setProperty("minimumY","%_model._method_for_Particles_minimumY()%" )
      .setProperty("maximumY","%_model._method_for_Particles_maximumY()%" )
      .setProperty("title",_simulation.translateString("View.Particles.title","\"Number of particles (red) inside the box (blue)\""))
      .setProperty("titleX",_simulation.translateString("View.Particles.titleX","\"time (s)\""))
      .setProperty("titleY",_simulation.translateString("View.Particles.titleY","\"Number of particles\""))
      .setProperty("visible","true")
      .setProperty("size",_simulation.translateString("View.Particles.size","\"300,200\""))
      .getObject();
    n = (org.opensourcephysics.displayejs.InteractiveTrace)
      addElement(new org.colos.ejs.library.control.displayejs.ControlTrace(),"n")
      .setProperty("_ejs_SecondAction_","updateAfterModelAction()")
      .setProperty("parent","Particles")
      .setProperty("x","t")
      .setProperty("y","n")
      .setProperty("clearAtInput","false")
      .setProperty("norepeat","true")
      .setProperty("connected","true")
      .setProperty("color","RED")
      .setProperty("stroke","2")
      .getObject();
    ndentro = (org.opensourcephysics.displayejs.InteractiveTrace)
      addElement(new org.colos.ejs.library.control.displayejs.ControlTrace(),"ndentro")
      .setProperty("_ejs_SecondAction_","updateAfterModelAction()")
      .setProperty("parent","Particles")
      .setProperty("x","t")
      .setProperty("y","nInside")
      .setProperty("clearAtInput","false")
      .setProperty("norepeat","true")
      .setProperty("connected","true")
      .setProperty("color","BLUE")
      .setProperty("stroke","2")
      .getObject();
  }

// ---------- Resetting the interface  -------------------

  public void reset() {
    getElement("drawingFrame2")
      .setProperty("title",_simulation.translateString("View.drawingFrame2.title","\"Frame\""))
      .setProperty("visible","true")
      .setProperty("resizable","true");
    getElement("tab")
      .setProperty("placement","TOP")
      .setProperty("selected","0")
      .setProperty("size",_simulation.translateString("View.tab.size","\"900,750\""));
    getElement("Simulation");
    getElement("panel_TITLE")
      .setProperty("size",_simulation.translateString("View.panel_TITLE.size","\"700,40\""))
      .setProperty("borderType","RAISED_BEVEL");
    getElement("label_TITLE")
      .setProperty("text",_simulation.translateString("View.label_TITLE.text","\"BROWNIAN DISKS LAB\""))
      .setProperty("font","Monospaced,BOLD,26");
    getElement("drawingPanel2")
      .setProperty("autoscaleX","false")
      .setProperty("autoscaleY","false")
      .setProperty("square","true")
      .setProperty("visible","true")
      .setProperty("background","173,216,230,255");
    getElement("conjuntoFormas")
      .setProperty("style","ELLIPSE")
      .setProperty("elementposition","CENTERED")
      .setProperty("lineColor","BLACK")
      .setProperty("fillColor","192,128,0,255");
    getElement("segment")
      .setProperty("sizeX","0")
      .setProperty("lineColor","BLACK")
      .setProperty("lineWidth","2");
    getElement("segment2")
      .setProperty("sizeX","0")
      .setProperty("lineColor","BLACK")
      .setProperty("lineWidth","2");
    getElement("segment3")
      .setProperty("sizeY","0")
      .setProperty("lineColor","BLACK")
      .setProperty("lineWidth","3");
    getElement("segment4")
      .setProperty("sizeY","0")
      .setProperty("lineColor","BLACK")
      .setProperty("lineWidth","3");
    getElement("label_simulation")
      .setProperty("size",_simulation.translateString("View.label_simulation.size","\"700,100\""))
      .setProperty("borderType","RAISED_BEVEL");
    getElement("panel_button")
      .setProperty("size",_simulation.translateString("View.panel_button.size","\"700,50\""));
    getElement("playPauseButton")
      .setProperty("size",_simulation.translateString("View.playPauseButton.size","\"50,20\""))
      .setProperty("imageOn",_simulation.translateString("View.playPauseButton.imageOn","\"/org/opensourcephysics/resources/controls/images/play.gif\""))
      .setProperty("imageOff",_simulation.translateString("View.playPauseButton.imageOff","/org/opensourcephysics/resources/controls/images/pause.gif"));
    getElement("panel_separator_sb1")
      .setProperty("size",_simulation.translateString("View.panel_separator_sb1.size","\"20,10\""));
    getElement("resetbutton")
      .setProperty("image",_simulation.translateString("View.resetbutton.image","\"/org/opensourcephysics/resources/controls/images/reset2.gif\""))
      .setProperty("size",_simulation.translateString("View.resetbutton.size","\"50,20\""));
    getElement("panel_separator_sb15")
      .setProperty("size",_simulation.translateString("View.panel_separator_sb15.size","\"20,10\""));
    getElement("label_write")
      .setProperty("text",_simulation.translateString("View.label_write.text","\"Write data: \""));
    getElement("button_write")
      .setProperty("image",_simulation.translateString("View.button_write.image","\"./saveSmall.gif\""))
      .setProperty("size",_simulation.translateString("View.button_write.size","\"50,20\""));
    getElement("panel_separator_sb22")
      .setProperty("size",_simulation.translateString("View.panel_separator_sb22.size","\"20,10\""));
    getElement("label_write2")
      .setProperty("text",_simulation.translateString("View.label_write2.text","\"Write last step \""));
    getElement("button_write2")
      .setProperty("image",_simulation.translateString("View.button_write2.image","\"./saveSmall.gif\""))
      .setProperty("size",_simulation.translateString("View.button_write2.size","\"50,20\""));
    getElement("panel_separator_sb2")
      .setProperty("size",_simulation.translateString("View.panel_separator_sb2.size","\"20,10\""));
    getElement("label_reset2")
      .setProperty("text",_simulation.translateString("View.label_reset2.text","\"Reset (default val.): \""));
    getElement("resetbutton2")
      .setProperty("image",_simulation.translateString("View.resetbutton2.image","\"/org/opensourcephysics/resources/controls/images/reset.gif\""))
      .setProperty("size",_simulation.translateString("View.resetbutton2.size","\"50,20\""));
    getElement("panel_time")
      .setProperty("size",_simulation.translateString("View.panel_time.size","\"700,30\""));
    getElement("panel_times");
    getElement("text_time")
      .setProperty("text",_simulation.translateString("View.text_time.text","\"Time (s): \""));
    getElement("time_view")
      .setProperty("editable","false")
      .setProperty("visible","false")
      .setProperty("size",_simulation.translateString("View.time_view.size","\"50,20\""));
    getElement("bar_time")
      .setProperty("minimum","0.0")
      .setProperty("visible","true")
      .setProperty("size",_simulation.translateString("View.bar_time.size","\"50,20\""))
      .setProperty("background","RED");
    getElement("panel_separator_sb12")
      .setProperty("size",_simulation.translateString("View.panel_separator_sb12.size","\"20,10\""));
    getElement("label_maxtime")
      .setProperty("text",_simulation.translateString("View.label_maxtime.text","\"Duration of experiment (s): \""));
    getElement("tmax")
      .setProperty("editable","true")
      .setProperty("size",_simulation.translateString("View.tmax.size","\"60,30\""));
    getElement("panel_separator_sb13")
      .setProperty("size",_simulation.translateString("View.panel_separator_sb13.size","\"20,10\""));
    getElement("text_initialtime")
      .setProperty("text",_simulation.translateString("View.text_initialtime.text","\"Time initial diffusion (s): \""));
    getElement("textra")
      .setProperty("format",_simulation.translateString("View.textra.format","\"00.0\""))
      .setProperty("size",_simulation.translateString("View.textra.size","\"50,30\""));
    getElement("panel_separator_sb14")
      .setProperty("size",_simulation.translateString("View.panel_separator_sb14.size","\"20,10\""));
    getElement("label_dt")
      .setProperty("text",_simulation.translateString("View.label_dt.text","\"Temporal step (s): \""));
    getElement("dt")
      .setProperty("format",_simulation.translateString("View.dt.format","\"0.0000\""))
      .setProperty("editable","true")
      .setProperty("size",_simulation.translateString("View.dt.size","\"80,30\""));
    getElement("Input_Data")
      .setProperty("visible","true");
    getElement("panel_particles")
      .setProperty("borderType","RAISED_BEVEL");
    getElement("label_panel_particles")
      .setProperty("text",_simulation.translateString("View.label_panel_particles.text","\"INPUT DATA FOR PARTICLES: \""));
    getElement("panel_input");
    getElement("panel_num");
    getElement("label_explain_num")
      .setProperty("text",_simulation.translateString("View.label_explain_num.text","\"Number, size and concentration:\""));
    getElement("panel_separator22")
      .setProperty("size",_simulation.translateString("View.panel_separator22.size","\"50,10\""));
    getElement("text_num")
      .setProperty("text",_simulation.translateString("View.text_num.text","\"N: \""));
    getElement("num")
      .setProperty("format",_simulation.translateString("View.num.format","\"#000\""))
      .setProperty("editable","true");
    getElement("panel_separator")
      .setProperty("size",_simulation.translateString("View.panel_separator.size","\"50,10\""));
    getElement("text_dreal")
      .setProperty("text",_simulation.translateString("View.text_dreal.text","\"Diameter (μm): \""));
    getElement("dreal")
      .setProperty("format",_simulation.translateString("View.dreal.format","\"0.00\""))
      .setProperty("editable","true");
    getElement("panel_separator2")
      .setProperty("size",_simulation.translateString("View.panel_separator2.size","\"50,10\""));
    getElement("text_phi2D")
      .setProperty("text",_simulation.translateString("View.text_phi2D.text","\"ϕ2D: \""));
    getElement("phi2D")
      .setProperty("format",_simulation.translateString("View.phi2D.format","\"0.0000\""))
      .setProperty("editable","true");
    getElement("panel_temp");
    getElement("label_explain_temp")
      .setProperty("text",_simulation.translateString("View.label_explain_temp.text","\"Fluid: temperature and viscosity: \""));
    getElement("check_water")
      .setProperty("selected","true")
      .setProperty("text",_simulation.translateString("View.check_water.text","\"Water?\""));
    getElement("panel_separator_temp1")
      .setProperty("size",_simulation.translateString("View.panel_separator_temp1.size","\"30,10\""));
    getElement("label_temp")
      .setProperty("text",_simulation.translateString("View.label_temp.text","\"Temp. (K):\""));
    getElement("temp")
      .setProperty("format",_simulation.translateString("View.temp.format","\"000.0\""))
      .setProperty("editable","true");
    getElement("panel_separator_temp2")
      .setProperty("size",_simulation.translateString("View.panel_separator_temp2.size","\"30,10\""));
    getElement("label_visco")
      .setProperty("text",_simulation.translateString("View.label_visco.text","\"η (Pa.s): \""));
    getElement("visco")
      .setProperty("format",_simulation.translateString("View.visco.format","\"0.0000\""));
    getElement("panel_separator_temp3")
      .setProperty("size",_simulation.translateString("View.panel_separator_temp3.size","\"30,10\""));
    getElement("text_diffreal")
      .setProperty("text",_simulation.translateString("View.text_diffreal.text","\"D (μm²/s): \""));
    getElement("diffreal")
      .setProperty("format",_simulation.translateString("View.diffreal.format","\"0.##E0\""))
      .setProperty("editable","false");
    getElement("panel_conversion");
    getElement("label_explain_conversion")
      .setProperty("text",_simulation.translateString("View.label_explain_conversion.text","\"Values in simulation (screen units): \""));
    getElement("panel_separator_conv1")
      .setProperty("size",_simulation.translateString("View.panel_separator_conv1.size","\"50,10\""));
    getElement("text_dsim")
      .setProperty("text",_simulation.translateString("View.text_dsim.text","\"Diameter: \""));
    getElement("dsim")
      .setProperty("format",_simulation.translateString("View.dsim.format","\"0.0000\""))
      .setProperty("editable","false");
    getElement("panel_separator_conv2")
      .setProperty("size",_simulation.translateString("View.panel_separator_conv2.size","\"30,10\""));
    getElement("text_factorcal")
      .setProperty("text",_simulation.translateString("View.text_factorcal.text","\"Cal. factor: \""))
      .setProperty("font","Monospaced,BOLD,16");
    getElement("factcal")
      .setProperty("format",_simulation.translateString("View.factcal.format","\"0.0000\""))
      .setProperty("editable","false");
    getElement("panel_separator_conv3")
      .setProperty("size",_simulation.translateString("View.panel_separator_conv3.size","\"30,10\""));
    getElement("text_diffsim")
      .setProperty("text",_simulation.translateString("View.text_diffsim.text","\"D: \""));
    getElement("diffsim")
      .setProperty("format",_simulation.translateString("View.diffsim.format","\"0.##E0\""))
      .setProperty("editable","false");
    getElement("panel_contour")
      .setProperty("borderType","RAISED_BEVEL");
    getElement("label_panel_particles2")
      .setProperty("text",_simulation.translateString("View.label_panel_particles2.text","\"BOUNDARY LIMITS AND HARD-DISK FORCES\""));
    getElement("label_boundaries");
    getElement("text_boundary")
      .setProperty("text",_simulation.translateString("View.text_boundary.text","\"Boundary conditions: \""));
    getElement("panel_separator_cont1")
      .setProperty("size",_simulation.translateString("View.panel_separator_cont1.size","\"30,10\""));
    getElement("noboundary")
      .setProperty("selected","true")
      .setProperty("text",_simulation.translateString("View.noboundary.text","\"No Boundary.\""));
    getElement("panel_separator_cont2")
      .setProperty("size",_simulation.translateString("View.panel_separator_cont2.size","\"30,10\""));
    getElement("check_walls")
      .setProperty("selected","true")
      .setProperty("text",_simulation.translateString("View.check_walls.text","\"Wall force: \""));
    getElement("wall")
      .setProperty("format",_simulation.translateString("View.wall.format","\"0.00\""))
      .setProperty("size",_simulation.translateString("View.wall.size","\"50,20\""));
    getElement("panel_separator_cont3")
      .setProperty("size",_simulation.translateString("View.panel_separator_cont3.size","\"30,10\""));
    getElement("PacMan")
      .setProperty("text",_simulation.translateString("View.PacMan.text","\"Cyclic.  \""));
    getElement("diam_redux")
      .setProperty("format",_simulation.translateString("View.diam_redux.format","\"#0.00\""))
      .setProperty("size",_simulation.translateString("View.diam_redux.size","\"50,20\""));
    getElement("label_disks");
    getElement("check_forcedisk")
      .setProperty("selected","true")
      .setProperty("text",_simulation.translateString("View.check_forcedisk.text","\"Use disk forces: \""));
    getElement("panel_separator_dsk1")
      .setProperty("size",_simulation.translateString("View.panel_separator_dsk1.size","\"20,10\""));
    getElement("check_exclusionvolumenforce")
      .setProperty("text",_simulation.translateString("View.check_exclusionvolumenforce.text","\"Exclusion volume force\""));
    getElement("panel_separator_dsk2")
      .setProperty("size",_simulation.translateString("View.panel_separator_dsk2.size","\"20,10\""));
    getElement("check_hsn12")
      .setProperty("selected","false")
      .setProperty("text",_simulation.translateString("View.check_hsn12.text","\"HS n=12\""));
    getElement("hsn12");
    getElement("panel_separator_dsk3")
      .setProperty("size",_simulation.translateString("View.panel_separator_dsk3.size","\"20,10\""));
    getElement("check_check_hsn36")
      .setProperty("selected","false")
      .setProperty("text",_simulation.translateString("View.check_check_hsn36.text","\"HS n=36\""));
    getElement("hsn36");
    getElement("panel_separator_dsk4")
      .setProperty("size",_simulation.translateString("View.panel_separator_dsk4.size","\"20,10\""));
    getElement("check_heyes")
      .setProperty("selected","true")
      .setProperty("text",_simulation.translateString("View.check_heyes.text","\"Heyes\""));
    getElement("heyes");
    getElement("panel_potentials")
      .setProperty("borderType","RAISED_BEVEL");
    getElement("label_panel_particles22")
      .setProperty("text",_simulation.translateString("View.label_panel_particles22.text","\"EXTERNAL POTENTIALS\""));
    getElement("panel_AO")
      .setProperty("visible","true");
    getElement("check_AO")
      .setProperty("selected","false")
      .setProperty("text",_simulation.translateString("View.check_AO.text","\"AO force\""));
    getElement("panel_separator_ao1")
      .setProperty("size",_simulation.translateString("View.panel_separator_ao1.size","\"50,10\""));
    getElement("text_rg")
      .setProperty("text",_simulation.translateString("View.text_rg.text","\"Rg(nm): \""));
    getElement("rg");
    getElement("panel_separator_ao2")
      .setProperty("size",_simulation.translateString("View.panel_separator_ao2.size","\"50,10\""));
    getElement("label_ctenp")
      .setProperty("text",_simulation.translateString("View.label_ctenp.text","\"Π/KT (μm-³):\""));
    getElement("ctenp");
    getElement("panel_atrac_pot")
      .setProperty("visible","true");
    getElement("check_atracpot")
      .setProperty("text",_simulation.translateString("View.check_atracpot.text","\"Pot Elec. Atrac.\""));
    getElement("panel_separator_ap1")
      .setProperty("size",_simulation.translateString("View.panel_separator_ap1.size","\"80,10\""));
    getElement("text_Z")
      .setProperty("text",_simulation.translateString("View.text_Z.text","\"Z: \""));
    getElement("Z");
    getElement("panel_separator_ap2")
      .setProperty("size",_simulation.translateString("View.panel_separator_ap2.size","\"20,10\""));
    getElement("text_lambda")
      .setProperty("text",_simulation.translateString("View.text_lambda.text","\" λB (nm): \""));
    getElement("lambda");
    getElement("panel_separator_ap3")
      .setProperty("size",_simulation.translateString("View.panel_separator_ap3.size","\"20,10\""));
    getElement("text_1divk")
      .setProperty("text",_simulation.translateString("View.text_1divk.text","\" 1/κ (μm): \""));
    getElement("_divk");
    getElement("panel_separator_ap4")
      .setProperty("size",_simulation.translateString("View.panel_separator_ap4.size","\"20,10\""));
    getElement("text_q")
      .setProperty("text",_simulation.translateString("View.text_q.text","\" q :\""));
    getElement("q");
    getElement("panel_optical_forces")
      .setProperty("visible","true");
    getElement("check_opticaltrap")
      .setProperty("selected","false")
      .setProperty("text",_simulation.translateString("View.check_opticaltrap.text","\"Optical trapping forces\""));
    getElement("panel_separator_op1")
      .setProperty("size",_simulation.translateString("View.panel_separator_op1.size","\"50,10\""));
    getElement("spring_text_x")
      .setProperty("text",_simulation.translateString("View.spring_text_x.text","\"k_x (μN/m):  \""));
    getElement("spring_value_x")
      .setProperty("format",_simulation.translateString("View.spring_value_x.format","\"0.00\""));
    getElement("panel_separator_op12")
      .setProperty("size",_simulation.translateString("View.panel_separator_op12.size","\"50,10\""));
    getElement("spring_text_y")
      .setProperty("text",_simulation.translateString("View.spring_text_y.text","\"k_y (μN/m):  \""));
    getElement("spring_value_y")
      .setProperty("format",_simulation.translateString("View.spring_value_y.format","\"0.00\""));
    getElement("panel_writereaddata")
      .setProperty("borderType","RAISED_BEVEL");
    getElement("text_explain_data")
      .setProperty("text",_simulation.translateString("View.text_explain_data.text","\"SAVE DATA TO TXT FILE\""));
    getElement("panel_Deltat");
    getElement("checkBox_savedata")
      .setProperty("selected","false")
      .setProperty("text",_simulation.translateString("View.checkBox_savedata.text","\"Save data automatically? \""));
    getElement("panel_separator_Dt12")
      .setProperty("size",_simulation.translateString("View.panel_separator_Dt12.size","\"20,10\""));
    getElement("checkBox_Deltat")
      .setProperty("text",_simulation.translateString("View.checkBox_Deltat.text","\"Δt (s) imposed in txt: \""));
    getElement("Deltat")
      .setProperty("format",_simulation.translateString("View.Deltat.format","\"0.0000\""))
      .setProperty("size",_simulation.translateString("View.Deltat.size","\"100,30\""));
    getElement("panel_separator_Dt122")
      .setProperty("size",_simulation.translateString("View.panel_separator_Dt122.size","\"20,10\""));
    getElement("checkBox_labeldisks")
      .setProperty("text",_simulation.translateString("View.checkBox_labeldisks.text","\"Include disks' number?\""));
    getElement("panel_separator_Dt1222")
      .setProperty("size",_simulation.translateString("View.panel_separator_Dt1222.size","\"20,10\""));
    getElement("checkBox_freemode")
      .setProperty("text",_simulation.translateString("View.checkBox_freemode.text","\"Not saving data?\""));
    getElement("panel_paths");
    getElement("text_path")
      .setProperty("text",_simulation.translateString("View.text_path.text","\"Directory to save file: \""));
    getElement("panel_separator_path1")
      .setProperty("size",_simulation.translateString("View.panel_separator_path1.size","\"20,10\""));
    getElement("button_path")
      .setProperty("image",_simulation.translateString("View.button_path.image","\"/org/opensourcephysics/resources/controls/images/folder.gif\""));
    getElement("path")
      .setProperty("size",_simulation.translateString("View.path.size","\"300,30\""));
    getElement("panel_separator_path2")
      .setProperty("size",_simulation.translateString("View.panel_separator_path2.size","\"20,10\""));
    getElement("text_file")
      .setProperty("text",_simulation.translateString("View.text_file.text","\"Name file.txt: \""));
    getElement("file")
      .setProperty("size",_simulation.translateString("View.file.size","\"200,30\""));
    getElement("text_explain_data2")
      .setProperty("text",_simulation.translateString("View.text_explain_data2.text","\"READ  INPUT FILE AND INITIAL XY POSITIONS\""));
    getElement("panel_read");
    getElement("botonRadio_read")
      .setProperty("selected","false")
      .setProperty("text",_simulation.translateString("View.botonRadio_read.text","\"Read data from files: \""));
    getElement("panel_separator_path12")
      .setProperty("size",_simulation.translateString("View.panel_separator_path12.size","\"20,10\""));
    getElement("etiqueta_inputfile")
      .setProperty("text",_simulation.translateString("View.etiqueta_inputfile.text","\"Input file: \""));
    getElement("button_input")
      .setProperty("image",_simulation.translateString("View.button_input.image","\"/org/opensourcephysics/resources/controls/images/folder.gif\""));
    getElement("path_inputfile")
      .setProperty("size",_simulation.translateString("View.path_inputfile.size","\"200,30\""));
    getElement("etiqueta_filename")
      .setProperty("text",_simulation.translateString("View.etiqueta_filename.text","\"  XY file: \""));
    getElement("button_filename")
      .setProperty("image",_simulation.translateString("View.button_filename.image","\"/org/opensourcephysics/resources/controls/images/folder.gif\""));
    getElement("path_filename")
      .setProperty("size",_simulation.translateString("View.path_filename.size","\"200,30\""));
    getElement("panel_separator_path122")
      .setProperty("size",_simulation.translateString("View.panel_separator_path122.size","\"20,10\""));
    getElement("boton_read")
      .setProperty("text",_simulation.translateString("View.boton_read.text","\"Read\""));
    getElement("Graphics");
    getElement("Diffusion_panel");
    getElement("panel_data_diff");
    getElement("panel_data_title_label")
      .setProperty("text",_simulation.translateString("View.panel_data_title_label.text","\"GAUSSIAN DIFFUSION\""));
    getElement("useGaussian_panel");
    getElement("useGaussian")
      .setProperty("text",_simulation.translateString("View.useGaussian.text","\"Calculate Gaussian statistics\""));
    getElement("n_histo_panel");
    getElement("n_histo_label")
      .setProperty("text",_simulation.translateString("View.n_histo_label.text","\"Number of points of histogram (10-200): \""));
    getElement("n_histo")
      .setProperty("format",_simulation.translateString("View.n_histo.format","\"000\""))
      .setProperty("size",_simulation.translateString("View.n_histo.size","\"60,10\""));
    getElement("DeltaDx_panel");
    getElement("DeltaDx_label")
      .setProperty("text",_simulation.translateString("View.DeltaDx_label.text","\"Relative error Dx and calculated (%) :\""));
    getElement("DeltaDx")
      .setProperty("format",_simulation.translateString("View.DeltaDx.format","\"0.0\""))
      .setProperty("editable","false")
      .setProperty("size",_simulation.translateString("View.DeltaDx.size","\"60,10\""));
    getElement("DeltaDy_panel");
    getElement("DeltaDy_label")
      .setProperty("text",_simulation.translateString("View.DeltaDy_label.text","\"Relative error Dy and calculated (%) :\""));
    getElement("DeltaDy")
      .setProperty("format",_simulation.translateString("View.DeltaDy.format","\"0.0\""))
      .setProperty("editable","false")
      .setProperty("size",_simulation.translateString("View.DeltaDy.size","\"60,10\""));
    getElement("panel_diff_separator");
    getElement("panel_graph_diff");
    getElement("Diffusion")
      .setProperty("autoscaleX","false")
      .setProperty("autoscaleY","true")
      .setProperty("title",_simulation.translateString("View.Diffusion.title","\"Gaussian Diffusion\""))
      .setProperty("titleY",_simulation.translateString("View.Diffusion.titleY","\"Counts X (blue), Y (red)\""))
      .setProperty("visible","true")
      .setProperty("size",_simulation.translateString("View.Diffusion.size","\"300,200\""));
    getElement("countx")
      .setProperty("clearAtInput","true")
      .setProperty("norepeat","true")
      .setProperty("connected","true")
      .setProperty("color","BLUE");
    getElement("county")
      .setProperty("clearAtInput","true")
      .setProperty("norepeat","true")
      .setProperty("connected","true")
      .setProperty("color","RED");
    getElement("Optical_panel");
    getElement("panel_data_k");
    getElement("panel_data_k_title")
      .setProperty("text",_simulation.translateString("View.panel_data_k_title.text","\"BOLTZMANN STATISTICS ON OPTICAL TRAP\""));
    getElement("usek_panel");
    getElement("usek")
      .setProperty("text",_simulation.translateString("View.usek.text","\"Calculate k from Boltzmann statistics\""));
    getElement("n_histo_k_panel");
    getElement("n_histo_label2")
      .setProperty("text",_simulation.translateString("View.n_histo_label2.text","\"Number of points of histogram (10-200): \""));
    getElement("n_histo2")
      .setProperty("format",_simulation.translateString("View.n_histo2.format","\"000\""))
      .setProperty("size",_simulation.translateString("View.n_histo2.size","\"60,10\""));
    getElement("Deltakx_panel");
    getElement("Deltakx_label")
      .setProperty("text",_simulation.translateString("View.Deltakx_label.text","\"Relative error kx and calculated (%) :\""));
    getElement("Deltakx")
      .setProperty("format",_simulation.translateString("View.Deltakx.format","\"0.0\""))
      .setProperty("editable","false")
      .setProperty("size",_simulation.translateString("View.Deltakx.size","\"60,10\""));
    getElement("Deltaky_panel");
    getElement("Deltaky_label")
      .setProperty("text",_simulation.translateString("View.Deltaky_label.text","\"Relative error ky and calculated (%) :\""));
    getElement("Deltaky")
      .setProperty("format",_simulation.translateString("View.Deltaky.format","\"0.0\""))
      .setProperty("editable","false")
      .setProperty("size",_simulation.translateString("View.Deltaky.size","\"60,10\""));
    getElement("panel_diff_separator2");
    getElement("panel_graph_k");
    getElement("Potential")
      .setProperty("autoscaleX","false")
      .setProperty("autoscaleY","true")
      .setProperty("title",_simulation.translateString("View.Potential.title","\"Boltzmann statistics\""))
      .setProperty("titleY",_simulation.translateString("View.Potential.titleY","\"Counts X (blue), Y (red)\""))
      .setProperty("visible","true")
      .setProperty("size",_simulation.translateString("View.Potential.size","\"300,200\""));
    getElement("x")
      .setProperty("clearAtInput","true")
      .setProperty("norepeat","true")
      .setProperty("connected","true")
      .setProperty("color","BLUE");
    getElement("y")
      .setProperty("clearAtInput","true")
      .setProperty("norepeat","true")
      .setProperty("connected","true")
      .setProperty("color","RED");
    getElement("Particles_panel");
    getElement("panel_XY");
    getElement("paneltitle");
    getElement("particletitle")
      .setProperty("text",_simulation.translateString("View.particletitle.text","\"Particle's xy position. \""));
    getElement("sep_panel");
    getElement("etiqueta")
      .setProperty("text",_simulation.translateString("View.etiqueta.text","\"Number of the particle:  \""));
    getElement("particlenumber")
      .setProperty("format",_simulation.translateString("View.particlenumber.format","\"#0\""))
      .setProperty("editable","true")
      .setProperty("size",_simulation.translateString("View.particlenumber.size","\"5,15\""));
    getElement("boton")
      .setProperty("text",_simulation.translateString("View.boton.text","\"Change\""));
    getElement("one_particle_xy")
      .setProperty("autoscaleX","true")
      .setProperty("autoscaleY","true")
      .setProperty("square","true")
      .setProperty("titleX",_simulation.translateString("View.one_particle_xy.titleX","\"X\""))
      .setProperty("titleY",_simulation.translateString("View.one_particle_xy.titleY","\"Y\""))
      .setProperty("visible","true")
      .setProperty("size",_simulation.translateString("View.one_particle_xy.size","\"300,200\""));
    getElement("x_y")
      .setProperty("clearAtInput","false")
      .setProperty("norepeat","true")
      .setProperty("connected","true");
    getElement("panel_n");
    getElement("Particles")
      .setProperty("autoscaleX","true")
      .setProperty("autoscaleY","false")
      .setProperty("title",_simulation.translateString("View.Particles.title","\"Number of particles (red) inside the box (blue)\""))
      .setProperty("titleX",_simulation.translateString("View.Particles.titleX","\"time (s)\""))
      .setProperty("titleY",_simulation.translateString("View.Particles.titleY","\"Number of particles\""))
      .setProperty("visible","true")
      .setProperty("size",_simulation.translateString("View.Particles.size","\"300,200\""));
    getElement("n")
      .setProperty("clearAtInput","false")
      .setProperty("norepeat","true")
      .setProperty("connected","true")
      .setProperty("color","RED")
      .setProperty("stroke","2");
    getElement("ndentro")
      .setProperty("clearAtInput","false")
      .setProperty("norepeat","true")
      .setProperty("connected","true")
      .setProperty("color","BLUE")
      .setProperty("stroke","2");
    __n_canBeChanged__ = true; // Variables.Particles:1
    __narray_canBeChanged__ = true; // Variables.Particles:2
    __diameter_c_canBeChanged__ = true; // Variables.Particles:3
    __d_real_canBeChanged__ = true; // Variables.Particles:4
    __diameter_canBeChanged__ = true; // Variables.Particles:5
    __vx_0_canBeChanged__ = true; // Variables.Particles:6
    __vy_0_canBeChanged__ = true; // Variables.Particles:7
    __x_canBeChanged__ = true; // Variables.Particles:8
    __x_0_canBeChanged__ = true; // Variables.Particles:9
    __x_prev_canBeChanged__ = true; // Variables.Particles:10
    __vx_canBeChanged__ = true; // Variables.Particles:11
    __y_0_canBeChanged__ = true; // Variables.Particles:12
    __y_prev_canBeChanged__ = true; // Variables.Particles:13
    __y_canBeChanged__ = true; // Variables.Particles:14
    __vy_canBeChanged__ = true; // Variables.Particles:15
    __microns_canBeChanged__ = true; // Variables.Particles:16
    __a_canBeChanged__ = true; // Variables.Particles:17
    __a_real_canBeChanged__ = true; // Variables.Particles:18
    __f_p_canBeChanged__ = true; // Variables.Particles:19
    __if_p_canBeChanged__ = true; // Variables.Particles:20
    __eta0_canBeChanged__ = true; // Variables.Particles:21
    __eta_canBeChanged__ = true; // Variables.Particles:22
    __T_canBeChanged__ = true; // Variables.Particles:23
    __K_B_canBeChanged__ = true; // Variables.Particles:24
    __D_canBeChanged__ = true; // Variables.Particles:25
    __chi_canBeChanged__ = true; // Variables.Particles:26
    __bUseWater_canBeChanged__ = true; // Variables.Particles:27
    __arraylist_Strings_canBeChanged__ = true; // Variables.Particles:28
    __arraylist_StringsStats_canBeChanged__ = true; // Variables.Particles:29
    __count_images_canBeChanged__ = true; // Variables.Particles:30
    __count_images_total_canBeChanged__ = true; // Variables.Particles:31
    __count_images_dt_canBeChanged__ = true; // Variables.Particles:32
    __count_images_dt_total_canBeChanged__ = true; // Variables.Particles:33
    __checker_t_canBeChanged__ = true; // Variables.Particles:34
    __xmin_canBeChanged__ = true; // Variables.Common:1
    __xmax_canBeChanged__ = true; // Variables.Common:2
    __ymin_canBeChanged__ = true; // Variables.Common:3
    __ymax_canBeChanged__ = true; // Variables.Common:4
    __t_canBeChanged__ = true; // Variables.Common:5
    __dt_canBeChanged__ = true; // Variables.Common:6
    __tmax_canBeChanged__ = true; // Variables.Common:7
    __textra_canBeChanged__ = true; // Variables.Common:8
    __numberOfSteps_canBeChanged__ = true; // Variables.Common:9
    __limitOfSteps_canBeChanged__ = true; // Variables.Common:10
    __dMaxTime_canBeChanged__ = true; // Variables.Common:11
    __dTimeMaxImposed_canBeChanged__ = true; // Variables.Common:12
    __dtInTxt_canBeChanged__ = true; // Variables.Common:13
    __bDtInTxt_canBeChanged__ = true; // Variables.Common:14
    __bSaveDataAuto_canBeChanged__ = true; // Variables.Common:15
    __iNumLogSave_canBeChanged__ = true; // Variables.Common:16
    __ep_canBeChanged__ = true; // Variables.Common:17
    __ed_canBeChanged__ = true; // Variables.Common:18
    __sFileName_canBeChanged__ = true; // Variables.Common:19
    __sDirectoryName_canBeChanged__ = true; // Variables.Common:20
    __sInputFileName_canBeChanged__ = true; // Variables.Common:21
    __sReadInputFilePath_canBeChanged__ = true; // Variables.Common:22
    __sReadFilePath_canBeChanged__ = true; // Variables.Common:23
    __bexclusion1k_canBeChanged__ = true; // Variables.Common:24
    __Dreal_canBeChanged__ = true; // Variables.Common:25
    __phi_2D_canBeChanged__ = true; // Variables.Common:26
    __bIncludeLabelDisk_canBeChanged__ = true; // Variables.Common:27
    __TOLERANCE_canBeChanged__ = true; // Variables.Events:1
    __bUseCyclicContour_canBeChanged__ = true; // Variables.Events:2
    __bUseWallForces_canBeChanged__ = true; // Variables.Events:3
    __bUseNoContour_canBeChanged__ = true; // Variables.Events:4
    __nInside_canBeChanged__ = true; // Variables.Events:5
    __tSave_canBeChanged__ = true; // Variables.Events:6
    __bSeparateDisks_canBeChanged__ = true; // Variables.Events:7
    __bUseDiskForce_canBeChanged__ = true; // Variables.Events:8
    __bUseOpticalForce_canBeChanged__ = true; // Variables.Events:9
    __diam_reduction_canBeChanged__ = true; // Variables.Events:10
    __bFreeMode_canBeChanged__ = true; // Variables.Events:11
    __bReadData_canBeChanged__ = true; // Variables.Events:12
    __binHistoJumps_canBeChanged__ = true; // Variables.Statistics:1
    __freqHistoJumps_canBeChanged__ = true; // Variables.Statistics:2
    __dFreqesp_canBeChanged__ = true; // Variables.Statistics:3
    __dFreqespOptPot_canBeChanged__ = true; // Variables.Statistics:4
    __countHistoJumpsX_canBeChanged__ = true; // Variables.Statistics:5
    __countHistoJumpsY_canBeChanged__ = true; // Variables.Statistics:6
    __bDoHistoJumps_canBeChanged__ = true; // Variables.Statistics:7
    __DHistoJumpsX_canBeChanged__ = true; // Variables.Statistics:8
    __DHistoJumpsY_canBeChanged__ = true; // Variables.Statistics:9
    __freqHistoOptPot_canBeChanged__ = true; // Variables.Statistics:10
    __countHistoOptPotX_canBeChanged__ = true; // Variables.Statistics:11
    __countHistoOptPotY_canBeChanged__ = true; // Variables.Statistics:12
    __bDoHistoOptPot_canBeChanged__ = true; // Variables.Statistics:13
    __kHistoOptPotX_canBeChanged__ = true; // Variables.Statistics:14
    __kHistoOptPotY_canBeChanged__ = true; // Variables.Statistics:15
    __particleXYexample_canBeChanged__ = true; // Variables.Statistics:16
    __particleXYexample2_canBeChanged__ = true; // Variables.Statistics:17
    __cte_f_exclusion_canBeChanged__ = true; // Variables.Potentials:1
    __cte_diffusion_canBeChanged__ = true; // Variables.Potentials:2
    __bAOmodel_canBeChanged__ = true; // Variables.Potentials:3
    __Rg_canBeChanged__ = true; // Variables.Potentials:4
    __cteAOennp_canBeChanged__ = true; // Variables.Potentials:5
    __A0_canBeChanged__ = true; // Variables.Potentials:6
    __A_canBeChanged__ = true; // Variables.Potentials:7
    __B_canBeChanged__ = true; // Variables.Potentials:8
    __bUseExclusionForce_canBeChanged__ = true; // Variables.Potentials:9
    __bUseHSn12_canBeChanged__ = true; // Variables.Potentials:10
    __bUseHSn36_canBeChanged__ = true; // Variables.Potentials:11
    __bUseHSHeyes_canBeChanged__ = true; // Variables.Potentials:12
    __cteAHSn12_canBeChanged__ = true; // Variables.Potentials:13
    __cteAHSn36_canBeChanged__ = true; // Variables.Potentials:14
    __ctekHSHeyes_canBeChanged__ = true; // Variables.Potentials:15
    __bUseElecAtracPot_canBeChanged__ = true; // Variables.Potentials:16
    __Zelec_canBeChanged__ = true; // Variables.Potentials:17
    __lambdaelec_canBeChanged__ = true; // Variables.Potentials:18
    __kappainvelec_canBeChanged__ = true; // Variables.Potentials:19
    __qelec_canBeChanged__ = true; // Variables.Potentials:20
    __k_optics_y_canBeChanged__ = true; // Variables.Potentials:21
    __k_optics_x_canBeChanged__ = true; // Variables.Potentials:22
    __cabeceraEstadisticas_canBeChanged__ = true; // Variables.Labels:1
    __sLabel_canBeChanged__ = true; // Variables.Labels:2
    __MSG_OPEN_FILE_canBeChanged__ = true; // Variables.Labels:3
    __MSG_CLOSE_FILE_canBeChanged__ = true; // Variables.Labels:4
    __MSG_WRITE_FILE_canBeChanged__ = true; // Variables.Labels:5
    __MSG_WRITE_FILE_ERROR_canBeChanged__ = true; // Variables.Labels:6
    __MSG_SAVING_ARRAY_canBeChanged__ = true; // Variables.Labels:7
    __MSG_CLEARING_ARRAY_canBeChanged__ = true; // Variables.Labels:8
    __TEXT_INPUT_FILE_canBeChanged__ = true; // Variables.Labels:9
    __TEXT_INPUT_TIMETOTAL_canBeChanged__ = true; // Variables.Labels:10
    __TEXT_INPUT_DT_canBeChanged__ = true; // Variables.Labels:11
    __TEXT_INPUT_SEP_canBeChanged__ = true; // Variables.Labels:12
    __TEXT_INPUT_N_canBeChanged__ = true; // Variables.Labels:13
    __TEXT_INPUT_RDIAM_canBeChanged__ = true; // Variables.Labels:14
    __TEXT_INPUT_DIAM_canBeChanged__ = true; // Variables.Labels:15
    __TEXT_INPUT_CAL_canBeChanged__ = true; // Variables.Labels:16
    __TEXT_INPUT_CONC_canBeChanged__ = true; // Variables.Labels:17
    __TEXT_INPUT_T_canBeChanged__ = true; // Variables.Labels:18
    __TEXT_INPUT_VISCO_canBeChanged__ = true; // Variables.Labels:19
    __TEXT_INPUT_DIFF_canBeChanged__ = true; // Variables.Labels:20
    __TEXT_INPUT_RDIFF_canBeChanged__ = true; // Variables.Labels:21
    __TEXT_INPUT_BOUNDARIES_canBeChanged__ = true; // Variables.Labels:22
    __TEXT_INPUT_WALLS_canBeChanged__ = true; // Variables.Labels:23
    __TEXT_INPUT_CTE_canBeChanged__ = true; // Variables.Labels:24
    __TEXT_INPUT_CYCLIC_canBeChanged__ = true; // Variables.Labels:25
    __TEXT_INPUT_DISKFORCE_canBeChanged__ = true; // Variables.Labels:26
    __TEXT_INPUT_EXCLUSION_canBeChanged__ = true; // Variables.Labels:27
    __TEXT_INPUT_R12_canBeChanged__ = true; // Variables.Labels:28
    __TEXT_INPUT_R36_canBeChanged__ = true; // Variables.Labels:29
    __TEXT_INPUT_HEYES_canBeChanged__ = true; // Variables.Labels:30
    __TEXT_INPUT_DTINTXT_canBeChanged__ = true; // Variables.Labels:31
    __TEXT_INPUT_OPTICAL_canBeChanged__ = true; // Variables.Labels:32
    __TEXT_INPUT_KX_canBeChanged__ = true; // Variables.Labels:33
    __TEXT_INPUT_KY_canBeChanged__ = true; // Variables.Labels:34
    __TEXT_INPUT_AO_canBeChanged__ = true; // Variables.Labels:35
    __TEXT_INPUT_RG_canBeChanged__ = true; // Variables.Labels:36
    __TEXT_INPUT_LONGAOCTE_canBeChanged__ = true; // Variables.Labels:37
    __TEXT_INPUT_ELECPOT_canBeChanged__ = true; // Variables.Labels:38
    __TEXT_INPUT_Z_canBeChanged__ = true; // Variables.Labels:39
    __TEXT_INPUT_LAMBDA_canBeChanged__ = true; // Variables.Labels:40
    __TEXT_INPUT_KAPPA_canBeChanged__ = true; // Variables.Labels:41
    __TEXT_INPUT_Q_canBeChanged__ = true; // Variables.Labels:42
    __MSG_WRITE_INPUT_FILE_canBeChanged__ = true; // Variables.Labels:43
    super.reset();
  }

} // End of class Brownian_disks_lab_v1_1View

