/*
 * Class : Brownian_disks_lab_v1_1Applet.java
 *  Generated using  *  Easy Java/Javascript Simulations Version 5.3, build 180211. Visit http://www.um.es/fem/Ejs
 */ 

package Brownian_Disks_Lab.Brownian_disks_lab_v1_1_pkg;

import org.colos.ejs.library._EjsConstants;

import java.util.*;
import java.text.*;
import java.lang.StringBuffer;
import java.math.*;
import java.nio.charset.StandardCharsets;
import java.nio.file.*;
import java.io.*;
// Imports suggested by Model Elements:
// End of imports from Model Elements

public class Brownian_disks_lab_v1_1Applet extends org.colos.ejs.library.LauncherApplet {

  static {
    org.opensourcephysics.display.OSPRuntime.loadTranslatorTool = false;
    org.opensourcephysics.display.OSPRuntime.loadExportTool = false;
  }

  public void init () {
    super.init();
    org.opensourcephysics.tools.ResourceLoader.addAppletSearchPath("/Brownian_Disks_Lab/");
    org.opensourcephysics.tools.ResourceLoader.addSearchPath(getCodeBase()+"Brownian_Disks_Lab/"); // This is for relative files
    org.opensourcephysics.tools.ResourceLoader.addSearchPath("Brownian_Disks_Lab/"); // This is for relative files, too
    //org.colos.ejs.library.Simulation.setPathToLibrary(getCodeBase()); // This is for classes (such as EjsMatlab) which needs to know where the library is
    if (getParentFrame()!=null) {
      _model = new Brownian_disks_lab_v1_1 ("drawingFrame2",getParentFrame(),getCodeBase(),this,(String[])null,true);
      _simulation = _model._getSimulation();
      _view = _model._getView();
    }
    else {
      _model = new Brownian_disks_lab_v1_1 (null,null,getCodeBase(),this,(String[])null,true);
      _simulation = _model._getSimulation();
      _view = _model._getView();
    }
    _simulation.initMoodle();
  }
  public void _reset() { ((Brownian_disks_lab_v1_1)_model)._reset(); }
  public void _initialize() { ((Brownian_disks_lab_v1_1)_model)._initialize(); }
  public void stop() { _model.getSimulation().onExit(); }
} // End of class Brownian_disks_lab_v1_1Applet

